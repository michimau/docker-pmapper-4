<?php

// TAV :
$_sl['Apply theme'] = 'Appliquer le thème';
$_sl['Apply view'] = 'Appliquer la vue';

?>