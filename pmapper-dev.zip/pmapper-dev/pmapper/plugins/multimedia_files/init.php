<?php
// prevent XSS
if (isset($_REQUEST['_SESSION'])) exit();

if (!isset($_SESSION)) {
	require_once('../../incphp/pmsession.php');
}

require_once(dirname(__FILE__) . '/../common/groupsAndLayers.php');

$groups = $_SESSION['grouplist'];
$lyersWithMediaAttibutes = array();

// init each group with multimedia attributes, extensions, ...
foreach ($groups as $grp) {
	$msLayers = getLayersByGroupOrLayerName($map, $grp->groupName);
	foreach ($msLayers as $msLayer) {
		// MULTIMEDIA_FIELDS "tex2||jpf, tex||gif"
		$metaDataMultimediaAttributes =  $msLayer->getMetaData('MULTIMEDIA_FIELDS');

		if (strlen($metaDataMultimediaAttributes) > 0) {
			// comma separated attributes
			$mediaAttributes = explode(',', $metaDataMultimediaAttributes);

			$mediaGrp = array();
			$mediaGrp['name'] = $grp->groupName;
			$mediaGrp['fields'] = array();

			foreach ($mediaAttributes as $mediaAttr) {
				// extensions separated with "||"
				$mediaAttrTmp = explode('||', $mediaAttr);
				$mediaAttr = trim($mediaAttrTmp[0]);
				$mediaExt = trim($mediaAttrTmp[1]);

				$mediaGrp['fields'][] = $mediaAttr;
				$mediaGrp['extensions'][] = $mediaExt;
			}

			$lyersWithMediaAttibutes[$mediaGrp['name']] = $mediaGrp;
		}
	}
}

// layers with multimedia fields: for JS reading
$_SESSION['pluginsConfig']['multimedia_files']['layers'] = $lyersWithMediaAttibutes;
?>