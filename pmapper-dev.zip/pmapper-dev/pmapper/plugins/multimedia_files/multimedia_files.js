/******************************************************************************
*
* Purpose: Display Multimedia Files
* Author:  Jaouad Bennasser, SIRAP
*
******************************************************************************
*
* Copyright (c) 2013 SIRAP
*
* This is free software; you can redistribute it and/or move
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version. See the COPYING file.
*
* This software is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with p.mapper; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
******************************************************************************/

$.extend(PM.Plugin,
	{
		MultimediaFiles:
		{
			pathRoot: '',
			subdir:'',
			autoSubdir: 0,

			// layers with "special" attributes, and default extension if specified
			// example for countries:
			// {"countries": {"name": "countries", "attrs": [{"field": "ISOCODE", "extension": "jpeg", "header": "ISO Code"}]}}
			layersMediaInfos: {},

			init: function() {
				if (typeof(PM.ini.pluginsConfig.multimedia_files) != 'undefined') {
					var pluginConfig = PM.ini.pluginsConfig.multimedia_files;
					if (typeof(pluginConfig.pathRoot) != 'undefined') {
						this.pathRoot = pluginConfig.pathRoot;
					}
					if (typeof(pluginConfig.subdir) != 'undefined') {
						this.subdir = pluginConfig.subdir;
					}
					if (typeof(pluginConfig.autoSubdir) != 'undefined') {
						this.autoSubdir = parseInt(pluginConfig.autoSubdir);
					}
					this.layersMediaInfos = [];
					if (typeof(pluginConfig.layers) != 'undefined') {
						if (typeof(pluginConfig.layers) == 'object') {
							var layers = {};
							$.each(pluginConfig.layers, function() {
								var attrs = [];
								numAtt = Math.max(this.fields.length, this.extensions.length);
								for (var iAtt = 0 ; iAtt < numAtt ; iAtt++) {
									attrs[iAtt]=  {
										field: this.fields[iAtt] ? this.fields[iAtt] : '',
										extension: this.extensions[iAtt] ? this.extensions[iAtt] : '',
										header: ''
									};
								}
								var layerName = this.name;
								layers[layerName] = {"name": layerName, "attrs": attrs};
							});

							// search for header
							$.each(layers, function(layerName, def) {
								var attrs = def.attrs;
								$.each(attrs, function(iMediaAtt, mediaDef) {
									mediaField = mediaDef.field;
									var mediaAttFound = false;
					        		$.each(PM.grouplist, function() {
					        			if (this.groupName && this.layerList) {
					        				$.each(this.layerList, function() {
					        					if (this.glayerName == layerName) {
				        							$.each(this.selFields, function(iLayerField, layerField) {
				        								if (mediaField == layerField) {
				        									var mediaAttHeader = PM.grouplist[layerName].selHeaders[iLayerField];
				        									layers[layerName].attrs[iMediaAtt].header = mediaAttHeader;
				        									mediaAttFound = true;
				        								}
							        					if (mediaAttFound) {
							        						return false;
							        					}
				        							});
					        					}
					        					if (mediaAttFound) {
					        						return false;
					        					}
					        				});
					        			}
			        					if (mediaAttFound) {
			        						return false;
			        					}
					        		});
								});
							});

							this.layersMediaInfos = layers;
						}
					}
				}
			},

			/**
			 * return {"name":"countries","headers":["ISOCODE"],"extensions":["jpeg"]}
			 */
			getMultimediaDefinitions: function(layerName) {
				var defs = false;
				$.each(this.layersMediaInfos, function() {
					if (this['name'] == layerName) {
						defs = this;
						return false;
					}
				});
				return defs;
			},

			/**
			 * Parse values and write "img" HTML tag if needed
			 */
			extendQueryLayersValues: function(queryLayers, tplName) {
				if (queryLayers) {
					var nbLayers = queryLayers.length;
					for (var iLayer = 0 ; iLayer < nbLayers ; iLayer++) {
						var layerName = '';
						var currentLayer = queryLayers[iLayer];
						if (typeof(currentLayer.values[0]) != 'undefined') {
							layerName = currentLayer.values[0][0].shplink[0];
						}

						var layerDef = this.getMultimediaDefinitions(layerName);
						if (layerDef) {
							$.each(layerDef.attrs, function(iAttr, attr) {
								var attrHeaderPos = $.inArray(attr.header, currentLayer.stdheader);
								if (attrHeaderPos != -1) {
									// parcours des valeurs pour faire le remplacement du nom de l'image par le bout de html
									$.each(currentLayer.values, function(iVal, val) {
										var objValues = val;

										var attrVal = val[attrHeaderPos];
										if (attrVal) {
											var htmlStr = PM.Plugin.MultimediaFiles.generateHTML(attrVal, layerName, attr);
											var isHyperlink = PM.Plugin.MultimediaFiles.isHyperlink(attrVal);

											if (isHyperlink) {
												val[attrHeaderPos].hyperlink[3] = htmlStr;
											} else {
												val[attrHeaderPos] = val[attrHeaderPos].replace(attrVal, htmlStr);
											}
										}
									});
								}
							});
						}
					}
				}
				return queryLayers;
			},

			/**
			 * search for extension in a file name
			 * if not found, search for default extension
			 */
			getFileExtension: function (inputFile, defaultExtension) {
				var fileExt = '';

				// extension in the file name
				var fileExt = this._getFileExtension(inputFile);
				// not found => search for default extension
				if (fileExt == '' && defaultExtension != '') {
					inputFile = inputFile + '.' + defaultExtension;
					fileExt = this._getFileExtension(inputFile);
				}

				return fileExt;
			},

			/**
			 * Search for extension in a file name
			 */
			_getFileExtension: function (inputFile) {
				var fileExt = '';

				if (inputFile) {
					var pattern =  /(?:\.([^.]+))?$/;
					var matches = pattern.exec(inputFile);
					// matches[0] : extension with '.'
					// matches[1] : extension without '.'
					if (typeof(matches[1]) != 'undefined') {
						fileExt = matches[1];
						fileExt = fileExt.toLowerCase();
					}
				}

				return fileExt;
			},

			getFilePath: function (attrVal, layerName) {
				var filePath = '';

				if (this.pathRoot) {
					filePath += '/' + this.pathRoot;
				} else {
					filePath += PM_PLUGIN_LOCATION + '/..';
				}
				if (this.subdir) {
					filePath += '/' + this.subdir;
				}
				if (this.autoSubdir) {
					filePath += '/' + layerName;
				}

				filePath += '/' + attrVal;

				return filePath;
			},

			generateHTML: function(attrVal, layerName, attr) {
				var htmlStr = '';
				var isHyperlink = this.isHyperlink(attrVal);

				if (isHyperlink) {
					if (attrVal && typeof(attrVal) == 'object' && attrVal.hyperlink) {
						attrVal = attrVal.hyperlink[2];
					} else {
						attrVal = '';
					}
				}

				if (attrVal) {
					attrVal = attrVal.trim();
					var fileExt = this.getFileExtension(attrVal, attr.extension);
					var filePath = this.getFilePath(attrVal, layerName);

					switch (fileExt) {
						case 'jpg':
						case 'jpeg':
						case 'png':
						case 'gif':
						case 'bmp':
						case 'tif':
						case 'tiff':
							var imgSrc = '';

							var isUrl = attrVal.search(/^https?:\/\//);
							if (isUrl < 0) {
								imgSrc = filePath + '.' + fileExt;
							} else {
								imgSrc = attrVal;
							}

							var htmlStrTmp = '<img src="' + imgSrc + '" alt="' + fileExt + '" class="mediafile" />';
							if (!isHyperlink) {
								htmlStr += '<a href="' + imgSrc + '" target="_blank">';
							}
							htmlStr += htmlStrTmp;
							if (!isHyperlink) {
								htmlStr += '</a>';
							}
							break;

						case 'mp3': // Le format mp3 (étant soumis à un brevet et des droits) ne fonctionne que pour IE, Google et Microsoft
						case 'ogg': // Pour faire fonctionner la balise audio sur Firefox, il faut utiliser le format ogg (codec Vorbis) libre de droit
						case 'mid':
						case 'wav':
							htmlStr += '<audio controls>';
							htmlStr += '<source src="' + filePath + '" />';
							htmlStr += '</audio>';
							break;

						case 'ogv':
						case 'mp4':
						case 'wmv':
							htmlStr += '<video controls="controls" class="mediafile">';
							htmlStr += '<source src="' + filePath + '" />';
							htmlStr += '</video>';
							break;

						default:
							htmlStr += fileExt;
							break;
					}
				}

				return htmlStr;
			},

			isHyperlink: function(attrVal) {
				var ret = false;
				if (attrVal && typeof(attrVal) == 'object') {
					if (attrVal.hyperlink) {
						ret = true;
					} else {
						ret = false;
					}
				}
				return ret;
			}
		}
	}
);
