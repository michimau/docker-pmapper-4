<?php
$_sl['User saved!'] = 'Utente salvato!';
$_sl['User erased!'] = 'Utente cancellato!';
$_sl['Users'] = 'Utenti';
$_sl['Username'] = 'Utente';
$_sl['Login'] = 'Accedi';
$_sl['Logout'] = 'Esci';
$_sl['Auth Admin'] = 'Amministrazione utenti';
$_sl['Here is possibile administrate the user'] = 'Qui è possibile amministrare gli utenti';
$_sl['Sorry an error was occured, during save/delete data!'] = 'Spiacente ma si è verificato un errore durante il salvataggio dei dati';
$_sl['Add new User'] = 'Aggiungi un nuovo utente';
$_sl['edit'] = 'Modifica';
$_sl['todel'] = 'Elimina';
$_sl['Action'] = 'Azioni';
$_sl['username'] = 'Utenti';
$_sl['role'] = 'Ruolo';
$_sl['configs'] = 'Profili';
$_sl['Select configs and set the default'] = 'Seleziona i profili e imposta quello di default';
$_sl['Save'] = 'Salva';
$_sl['Users list'] = 'Lista utenti';
$_sl['Insert new user'] = 'Inserisci nuovo utente';
$_sl['Edit user'] = 'Modifica utente';
$_sl['Do you want delete user'] = 'Vuoi cancellare utente';

?>
