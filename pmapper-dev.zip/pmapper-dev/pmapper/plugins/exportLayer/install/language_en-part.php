<?php

// exportLayer
$_sl['expLayer_title'] = 'Export layer';
$_sl['expLayer_filterTitle'] = 'Filters selection';
$_sl['expLayer_filter'] = 'Filter';
$_sl['expLayer_nbObj'] = 'Object';
$_sl['expLayer_btnExport'] = 'Export';
$_sl['expLayer_btnCancel'] = 'Cancel';
$_sl['expLayer_waitingCancel'] = 'Waiting for cancel';
$_sl['expLayer_exportCanceled'] = 'Export canceled';
$_sl['expLayer_exportInProgress'] = 'Export in progress';
$_sl['expLayer_errTimeout'] = 'Timeout';
$_sl['expLayer_errMemory'] = 'insufficient memory';
$_sl['expLayer_error'] = 'An error occurred during the export';
$_sl['expLayer_errFilter'] = 'No filter selected';

?>