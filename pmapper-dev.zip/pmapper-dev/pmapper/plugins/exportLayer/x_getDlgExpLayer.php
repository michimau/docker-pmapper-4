<?php
require_once('../../incphp/group.php');
require_once('../../incphp/pmsession.php');
require_once("../../incphp/common.php");
require_once('../../incphp/globals.php');

// prevent XSS
if (isset($_REQUEST['PM_INCPHP'])) exit();

require_once(dirname(__FILE__) . '/../common/groupsAndLayers.php');
require_once(dirname(__FILE__) . '/../common/easyMDB2.inc.php');

$layer = isset($_REQUEST['layer']) ? $_REQUEST['layer'] : '';

			
header("Content-type: text/html; charset=$defCharset");
?>
<html>
<head>
</head>
<body>
	<div id="expLayerDlg">
		<div class="expLayerTitle"><?php echo _p("expLayer_title") ?></div>
		<div class="expLayerForm">
			<form target="_blank">
				<div id='expLayerProgressBar' class="expLayerParam">
					<div class="bar">
						<div class="progress"></div>
						<div class="progressText">50%</div>
					</div>
				</div>
				<div id="expLayerBtn" class="expLayerParam">
					<input type="button" name="export" value="<?php echo _p('expLayer_btnExport') ?>" onclick="PM.Plugin.ExportLayer.exportLayer()"/>
					<input type="button" name="cancel" value="<?php echo _p('expLayer_btnCancel') ?>" onclick="PM.Plugin.ExportLayer.cancelExport()"/>
					<div><?php echo _p("expLayer_waitingCancel") ?></div>
				</div>
				<div id="expLayerResult"></div>
				
				<input type="hidden" name="layerName" value="<?php echo $layer ?>" onclick="PM.Plugin.ExportLayer.exportLayer()"/>
			 </form>
		 </div>
	 </div>
</body>
</html>