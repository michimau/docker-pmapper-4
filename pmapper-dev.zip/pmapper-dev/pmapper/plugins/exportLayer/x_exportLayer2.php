<?php

require_once('../../incphp/group.php');
require_once('../../incphp/pmsession.php');
require_once('../../incphp/common.php');
require_once('../../incphp/globals.php');

require_once('exportLayer.inc.php');

// prevent XSS
if (isset($_REQUEST['PM_INCPHP'])) exit();

$ret['bOk'] = false;
$action = isset($_REQUEST['action']) ? $action = $_REQUEST['action'] : false;
$iniFile = isset($_SESSION['exportLayer']['iniFile']) ? $_SESSION['exportLayer']['iniFile'] : '';

switch ($action) {
	case 'cancelExport':
		if ($iniFile) {
			cancelExport($iniFile);
			$ret['bOk'] = true;
		}
		break;
	case 'closeExport':
		if (isset($_SESSION['exportLayer'])) {
			if (file_exists($iniFile)) {
				unlink($iniFile);
			}
			unset($_SESSION['exportLayer']);
			$ret['bOk'] = true;
		}
		break;
	case 'isExportInProgress':
		$ret['inProgress'] = false;
		$ret['bOk'] = true;
		
		if (isset($_SESSION['exportLayer']['exportInProgress'])) {
			if ($_SESSION['exportLayer']['exportInProgress']) {
				$ret['inProgress'] = true;
			}
		}
		
		break;
	case 'getProgress':
		$ret['progress'] = 0;
		if ($iniFile) {
			$ret['progress'] = getProgress($iniFile);
			$ret['bOk'] = true;
		}
		break;
	default:
		break;
}

$retStr = json_encode($ret);

header("Content-Type: text/plain; charset=$defCharset");
echo $retStr;

?>