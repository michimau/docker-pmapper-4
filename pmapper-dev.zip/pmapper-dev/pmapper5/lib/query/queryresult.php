<?php

/**
 * Parent class for parsing of query result  
 *
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 *
 * @package query
 * 
 */

class QueryResult
{
    /**
     * Constructor
     * @param array $result
     */
    public function __construct($result)
    {
        $this->result = $result;
        $this->pointBuffer = $_SESSION['pointBuffer'];
        $this->shapeQueryBuffer = $_SESSION['shapeQueryBuffer'];
        
        $nf = $_SESSION['numberFormat'];
        if ($nf['thousandsSep'] == "||") $nf['thousandsSep'] = " ";
        $this->numberFormat = $nf;
    }
    
    /**
     * Get result list as JSON string
     * @return string
     */
    public function getAsJson()
    {
        $resultArray = $this->parseResult();
        return json_encode($resultArray);
    }
    
    /**
     * Get result list as PHP array
     * @return array
     */
    public function getAsArray()
    {
        $resultArray = $this->parseResult();
        return $resultArray;
    }
    
    /**
    * Parse result and create output array with string converted to UTF-8
    * @return array
    */
    public function parseResult()
    {
        $parsed = array();
        foreach($this->result as $groupResult) {
            $grpResult = array();
            $encoding = $groupResult['encoding'];
    
            foreach ($groupResult as $key => $grpval) {
                $values = array();
                if ($key == "layerList") {
                    $grpResult['values'] = $this->parseLayerList($grpval);
                } else {
                    $grpResult[$key] = $grpval;
                }
            }
            $groupBounds = $grpResult['groupBounds'];
            //error_log($groupBounds[0]);
            if ($groupBounds[0] == $groupBounds[2]) {
                $grpResult['groupBounds'] = $this->modifyGroupBounds($groupBounds);
            }
            $parsed[] = $grpResult;
        }
        return $parsed;
    }
    
    
    protected function modifyGroupBounds($shpBounds)
    {
        $buf = $this->pointBuffer;        // set buffer depending on dimensions of your coordinate system
        $shpBounds[0] -= $buf;
        $shpBounds[1] -= $buf;
        $shpBounds[2] += $buf;
        $shpBounds[3] += $buf;

        return $shpBounds;
    }
    
        
}


?>