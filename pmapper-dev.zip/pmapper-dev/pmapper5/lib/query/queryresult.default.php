<?php

/**
 * Class for default parsing of query result  
 *
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 *
 * @package query
 * 
 */
class QueryResultDefault extends QueryResult
{
    /**
     * Constructor
     * @param array $result
     */
    public function __construct($result)
    {
        parent::__construct($result);
    }
    
    
    /**
     * Parse the layer list and aggregate values
     * @param array $layerListIn
     * @return array
     */
    protected function parseLayerList($layerListIn)
    {
        $values = array();
        foreach ($layerListIn as $rLayer) {
            foreach ($rLayer['resultList'] as $recIn) {
                $recOut = array();
                $shapeBounds = $this->getShapeBounds($recIn['@pm_shapebounds'], $rLayer['params']);
                $recOut[] = array('shplink' => array($rLayer['params']['name'], $recIn['@pm_shapeindex'], $shapeBounds ));
                foreach ($recIn as $fld => $val) {
                    if (substr($fld, 0, 3) != "@pm") {
                        $fldValue = $this->printFieldValue($fld, $val, $rLayer['params']);
                        $recOut[] = $fldValue;
                    }
                }
                $values[] = $recOut;
            }
            
            // --- duplicate record for one2many joins  ---
        }
    
        return $values;
    }
    
    
    /**
     * Return field value in UTF-8, taking into account hyperlink definitions
     * @param string $layerName
     * @param string $fldName
     * @param string $fldValue
     * @param string $encoding
     * @param array $hyperFieldList
     * @return mixed
     */
    function printFieldValue( $fldName, $fldValue, $layerParams)
    {
        $layerName = $layerParams['name'];
        $encoding = $layerParams['encoding'];
        $hyperFields = $layerParams['hyperFields'];
        $fieldsNumberFormat = $layerParams['fieldsNumberFormat'];
        //pm_logDebug(3, $layerParams, "Parameters for layerParams \nfile: queryresult.default.php->printFieldValue() \n");
        //pm_logDebug(3, $this->numberFormat, "Parameters for this->numberFormat \nfile: queryresult.default.php->printFieldValue() \n");
        
        // Change format for decimal field values
        if ($fieldsNumberFormat) {
            if (array_key_exists($fldName, $fieldsNumberFormat)) {
                $nf = $fieldsNumberFormat[$fldName]; 
                $fldValue = number_format($fldValue, $nf['decimals'], $nf['decimalPoint'], $nf['thousandsSep']);
            }
        } elseif ($nf = $this->numberFormat) {
            if (is_numeric($fldValue)) {
            	//error_log($fldValue);
                if (preg_match('/\./', $fldValue)) {
            		$fldValue = number_format($fldValue, $nf['decimals'], $nf['decimalPoint'], $nf['thousandsSep']);
            	}
            }
        }
        
        // Encode all strings in UTF-8 
        if ($encoding) {
            if ($encoding != "UTF-8") {
                $fldValue = iconv($encoding, "UTF-8", $fldValue);
            }
        } else {
            $fldValue = utf8_encode($fldValue);
        }

        // Check for hyperlinks
        if ($hyperFields) {
            if (array_key_exists($fldName, $hyperFields)) {
                $alias = $hyperFields[$fldName]['alias'] ? _p($hyperFields[$fldName]['alias']) : $fldValue;
                $outVal = array("hyperlink" => array($layerName, $fldName, $fldValue, $alias) );
           } else {
                $outVal = $fldValue;
           }
        // NO hyperlink so just print normal output
        } else {
            $outVal = $fldValue;
        }
        return $outVal;
    }
    
    /**
     * Get the shape boundaries taking into account Buffer settings
     * @param array $shpBounds
     * @param array $layerParams
     */
    protected function getShapeBounds($shpBounds, $layerParams)
    {
        // Buffer for zoom extent
        if ($layerParams['type'] == 0) {
            $buf = $layerParams['pointBuffer'] ? $layerParams['pointBuffer'] : $this->pointBuffer;        // set buffer depending on dimensions of your coordinate system
        } else {
            if ($this->shapeQueryBuffer > 0) {
                $buf = $this->shapeQueryBuffer * ((($shpBounds[2] - $shpBounds[0]) + ($shpBounds[3] - $shpBounds[1])) / 2);
            } else {
                $buf = 0;
            }
        }
        //error_log("before:" . join(",", $shpBounds));
        if ($buf > 0) {
            $shpBounds[0] -= $buf;
            $shpBounds[1] -= $buf;
            $shpBounds[2] += $buf;
            $shpBounds[3] += $buf;
        }
        //error_log("after:" . join(",", $shpBounds));
        return join(",", $shpBounds);
    }
        
        
        
        
}


?>