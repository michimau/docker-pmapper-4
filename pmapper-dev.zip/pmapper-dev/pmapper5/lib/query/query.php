<?php


/**
 * Main class for Query
 *
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 *
 * @package query
 *
 */

class Query 
{ 
	/**
	 * request parameters
	 * @var array
	 */
	protected $params;
	
	/**
	 * Point/rectangle x/y list
	 * @var array
	 */
	protected $xyList;
	
	/**
	* MS Groups for querying
	* @var array
	*/
	protected $querygroups;
	
	/**
	 * Map projection as EPSG code
	 * @var string
	 */
	protected $crs;
	
	/**
	 * Result of query, set via executing processQuery()
	 * @var array
	 */
	protected $resultTotal;
	
	protected $resultindexes = NULL;
	protected $resulttileindexes = NULL;

	
    
	/**
	 * Class constructor
	 * @param mapObj $map
	 * @param array $params
	 */
    public function __construct($map, $params)
    {
        $this->map = $map;
        $this->params = $params;
        
        if (isset($params['mode'])) {
            $this->mode = $params['mode'];
        } else {
            $this->mode = "attribute";
        }
      
        $this->querygroups = explode(",", $params['groups']);
        
        if (isset($params['queryxy'])) {
            $this->xyList = explode(",", $params["queryxy"]);
        }
        //pm_logDebug(3, $this->querygroups, "querygroups query.php->__construct");
 
        $this->highlightSelected = $_SESSION['highlightSelected'];
        $this->limitResult = $_SESSION['limitResult'];
        $this->autoZoom = $_SESSION['autoZoom'];
        $this->zoomAll = $_SESSION['zoomAll'];
        $this->grouplist = $_SESSION['grouplist'];

        $_SESSION['mode'] = $this->mode;
        
    }

    /**
     * Run the queries
     */
    public function processQuery()
    {
        $this->prepareQuery($this->params);
        $this->resultTotal = $this->execQuery();
        //return json_encode($this->resultTotal);
    }
    
    /**
     * Prepare queries for correct results in Mapserver
     */
    protected function prepareQuery($params)
    {
        $this->map->setProjection("init=" . strtolower($params['crs']) );
        
        // Set $this->map->extent to values of current map extent
        // otherwise values of TOLERANCE in map file are not interpreted correctly
        $mapExt = explode(",", $params['mapext']);
        $this->map->setExtent($mapExt[0], $mapExt[1], $mapExt[2], $mapExt[3]);

        // Patch from Alessandro Pasotti for fixing problems with result returned
        $this->map->setSize($params['mapwidth'], $params['mapheight']);
        $this->map->preparequery();
    }
  


    /**
     * Execute the MapScript queryBy... methods and return results as multidimension array
     * @return array
     */
    protected function execQuery()
    {
        $msVersion = ms_GetVersionInt();
        
		for ($i = 0; $i < $this->map->numlayers; $i++){
	    	$qLayer = $this->map->getLayer($i);
	        if ($qLayer->getMetaData('PM_RESULT_DATASUBSTITION') != '') {
	            $oldData[$i] = $qLayer->data;
	         	$qLayer->set('data', $qLayer->getMetaData('PM_RESULT_DATASUBSTITION'));
	        }
	    }
        
	    if ($this->mode == "point") {
	        $qPoint = ms_newPointObj();
	        $qPoint->setXY($this->xyList[0], $this->xyList[1]);
	    } elseif ($this->mode == "rect") {
	        $qRect = ms_newRectObj();
	        $qRect->setExtent($this->xyList[0], $this->xyList[1], $this->xyList[2], $this->xyList[3]); 
	    } elseif ($this->mode == "shape") {
	        $qShape = ms_shapeObjFromWkt($this->params['shpwkt']);
	    } elseif ($this->mode == "attribute") {
	        $searchParams = $this->getAttributeQueryParams();
	        $qLayerType = $searchParams['layerType'];
	        $fldName    = $searchParams['firstFld'];
	        $qStr       = $searchParams['qStr'];
	        $glList = PMCommon::returnGroupGlayer($searchParams['layerName']);
            $gGroupName = $glList[0]->getGroupName();
	        $this->querygroups = array($gGroupName);
	    }
	    
	    // Loop through msLayers of msGroups
	    $resultTotal = array();
	    $resultIndexes = array();
	    foreach ($this->grouplist as $i=>$grp) {
	        if (in_array($grp->getGroupName(), $this->querygroups)) {
    	        $resultGroup = array();
    	        $glayerList = $grp->getLayers();
    	        $grpBounds = array('minx'=>999999999, 'miny'=>999999999, 'maxx'=>-999999999, 'maxy'=>-999999999);
    	        $grpNumResults = 0;
    	        foreach ($glayerList as $gLayer) {
    	            $layerName = $gLayer->getLayerName();
    	            $resultFields = $gLayer->getResFields();
    	            $qLayer = $this->map->getLayerByName($layerName);
    	            $qLayerConnectionType = $qLayer->connectiontype;
    	            $qLayerResultIndexes = array();
    	            
    	            // use layers with complex queries that are too long to select results
    	            // cause maxscaledenom is not used...
    	            $dataSubstitution = false;
    	            if ($qLayer->getMetaData('PM_RESULT_DATASUBSTITION') != '') {
    	                $dataSubstitution = true;
    	                $oldData = $qLayer->data;
    	                $qLayer->set('data', $qLayer->getMetaData('PM_RESULT_DATASUBSTITION'));
    	            }
    	            
    	            $projList = $this->checkProjection($qLayer);
    	            
    	            if ($this->mode == "point") {
    	                @$qLayer->queryByPoint($qPoint, MS_MULTIPLE, -1);
    	            } elseif ($this->mode == "rect") {
    	                @$qLayer->queryByRect($qRect);
    	            } elseif ($this->mode == "shape") {
    	                @$qLayer->queryByShape($qShape);
    	            } elseif ($this->mode == "attribute") {
    	                $qStr = $this->getAttributeQueryString($qLayer, $qStr);
    	                if ($qLayerConnectionType == MS_ORACLESPATIAL) $fldName = NULL;

    	                @$qLayer->queryByAttributes($fldName, $qStr, MS_MULTIPLE);
    	                
    	            }
    	            
    	            // get records from query result
    	            $tiledShape = $qLayerConnectionType == MS_TILED_SHAPEFILE ? true : false;
    	            $qLayer->open();
    	            $numResults = $qLayer->getNumResults();
    	            
    	            if ($this->limitResult) {
    	                $limit = (int)$this->limitResult;
    	                if ( ($grpNumResults + $numResults) > $limit) {    
    	                    $numResults = $limit - $grpNumResults;
    	                    $grpNumResults = $this->limitResult;
    	                } else {
    	                    $grpNumResults += $numResults;
    	                }
    	            } else {
    	                $grpNumResults += $numResults;
    	            }
    	            
    	            $resultLayer = array('params' => array(
        	            					 'name'=> $layerName,
        	                                 'hyperFields' => $gLayer->getHyperFields(),
        	                                 'joinList' => $gLayer->getTableJoin(),
        	                                 'encoding' => $gLayer->getLayerEncoding(),
        	                                 'fieldsNumberFormat' => $gLayer->getFieldsNumberFormat(),
    	            						 'pointBuffer' => $gLayer->getPointBuffer(),
    	            						 'type' => $qLayer->type
        	                              ),
    	            					 'resultList' => array()
    	            );
    	            
    	            for ($iRes=0; $iRes < $numResults; $iRes++) {
    	                $qRes = $qLayer->getResult($iRes);
    	                if ($msVersion >= 60000) {
    	                    $qShape = $qLayer->getShape($qRes);
    	                } else {
    	                    $qShape = $qLayer->getShape($qRes->tileindex, $qRes->shapeindex);
    	                }
    	                
    	                // Restrict result record to fields defined in RESULT_FIELDS, using defined order
    	                $rec = array();
    	                $recIn = $qShape->values;                        
                        foreach ($resultFields as $fld) {
                            if (isset($recIn[$fld])) {
                                $rec[$fld] = $recIn[$fld];
                            }
                        }
                        
    	                
    	                $bounds = $qShape->bounds;
    	                if ($projList) {
    	                    $bounds->project($projList['layer'], $projList['map']);
    	                }
    	                $shpBounds = array($bounds->minx, $bounds->miny, $bounds->maxx, $bounds->maxy);
    	                $rec['@pm_shapebounds'] = $shpBounds;
    	                
    	                $qShpIdx = $qShape->index;
    	                if ($tiledShape && $qShape->tileindex != -1) {
    	                    $qShpIdx = "$qShape->tileindex@$qShpIdx";
    	                }
    	                $rec['@pm_shapeindex'] = $qShpIdx;
    	                $resultLayer['resultList'][] = $rec;
    	                
    	                $grpBounds['minx'] = min($grpBounds['minx'], $bounds->minx);
    	                $grpBounds['miny'] = min($grpBounds['miny'], $bounds->miny);
    	                $grpBounds['maxx'] = max($grpBounds['maxx'], $bounds->maxx);
    	                $grpBounds['maxy'] = max($grpBounds['maxy'], $bounds->maxy);
    	                
    	                // Add indexes to list for result highlighting
    	                if ($this->qLayer->connectiontype == MS_POSTGIS || $this->qLayer->connectiontype == MS_ORACLESPATIAL) {
    	                    $layerDbProperties = $this->glayer->getLayerDbProperties();
    	                    $uniqueField = $layerDbProperties['unique_field'];
    	                    $shapeIndex = $qShape->values[$uniqueField];
    	                } else {
    	                    $shapeIndex = $qShpIdx;
    	                }
    	                $qLayerResultIndexes[] = $shapeIndex;
    	                
    	            }
    	            $qLayer->close();
    	            if ($numResults > 0) {
    	                $resultIndexes[$layerName] = $qLayerResultIndexes;
    	            }
    	            
    	            // reset data tag if substituted
    	            if ($dataSubstitution) {
    	                $qLayer->set('data', $oldData);
    	            }
    	            $resultGroup['layerList'][] = $resultLayer;
    	             
    	        }
    	        if ($grpNumResults > 0) {
    	            
    	            $resultGroup['groupBounds'] = array_values($grpBounds);
        	        $resultGroup['numResults'] = $grpNumResults;
        	        $resultGroup['name'] = $grp->getGroupName();
        	        $resultGroup['description'] = $grp->getDescription();
        	        
        	        $slink = $gLayer->getLayerType() != 3 ? "@" : "#";
        	        $header = $grp->getResHeaders();
        	        array_unshift($header, $slink);
        	        $stdheader = $grp->getResStdHeaders();
        	        array_unshift($stdheader, $slink);
        	        $resultGroup['header'] = $header;
        	        $resultGroup['stdheader'] = $stdheader;
        	        $resultTotal[] = $resultGroup;
    	        }
	        }
	    }
	    
	    $_SESSION['resultIndexes'] = $resultIndexes;
	    
	    return $resultTotal;
    }
    
    /**
     * 
     * Enter description here ...
     */
    public function getResultTotal()
    {
        return $this->resultTotal;
    }
    
    
    
    /**
     * Check if map and layer have difefrent projections
     * @param array $qLayer
     * @return mixed
     */
    protected function checkProjection($qLayer)
    {
        $mapProjStr = $this->map->getProjection();
        $qLayerProjStr = $qLayer->getProjection();
        if ($mapProjStr && $qLayerProjStr && $mapProjStr != $qLayerProjStr) {
            $projList['map'] = ms_newprojectionobj($mapProjStr);
            $projList['layer'] = ms_newprojectionobj($qLayerProjStr);
            return $projList;
        } else {
            return false;
        }
    }
    
    
    /**
     * Get parameters for attribute query (=search) 
     * @return array
     */
    protected function getAttributeQueryParams()
    {
        $searchArray = array();
        $searchitem = $this->params['searchitem'];
        foreach ($this->params as $key=>$val) {
            if ($key != "findlist" && $key != "searchitem") {
                $searchArray[$key] = urldecode($val); //utf8_encode($val);
            }
        }
        $search = new XML_search($this->map, $_SESSION['PM_SEARCH_CONFIGFILE']);
        $searchParams = $search->getSearchParameters($this->map, $searchitem, $searchArray);
    
        pm_logDebug(2, $searchArray, "Parameters for searchArray \nfile: query.php->getAttributeQueryParams \n");
        pm_logDebug(2, $searchParams, "Parameters for searchParams \nfile: query.php->getAttributeQueryParams");
        
        return $searchParams;
    }
    
    
    
    protected function getAttributeQueryString($qLayer, $qStr)
    {
        $qLayerConnectionType = $qLayer->connectiontype;
        if ($layFilter = $qLayer->getFilterString()) {
            if ($qLayerConnectionType == MS_POSTGIS || $qLayerConnectionType == MS_ORACLESPATIAL) {
                $qStr = str_replace('"', '', $layFilter) . " AND $qStr";
            } else {
                $mapLayerFilterItem = $qLayer->filteritem;
                if ($layFilter[0] == '/') {
                    $operator = '=~';
                } else {
                    $operator = '=';
                }
                $qStr = "(\"[$mapLayerFilterItem]\" $operator $layFilter AND ($qStr) )";
            }
            pm_logDebug(3, $qStr, "query string including FILTER -- query.php->execQuery");
        }    
        
        return $qStr;
    }
    
    
    /**
     *  PROCESS ZOOM INFO AND SET RESULTLAYERS
     */
    function q_printZoomParameters()
    {
        
        $zp = "{";
        
        // Get the maximum extent for more than 1 layer if 'autoZoom' or button 'zoomAll' selcted in config 
        //print_r($this->Extents);
        $allExtStr = "";
        if ($this->zoomFull && $this->numResultsTotal > 0) {
            if (is_array($this->Extents) ) {
	        	if (count($this->Extents) < 2) {
	        		$allExtStr = join("+", $this->Extents[0]);
	            } else {
	                $minx = $this->Extents[0][0];
	                $miny = $this->Extents[0][1];
	                $maxx = $this->Extents[0][2];
	                $maxy = $this->Extents[0][3];
	        
	                for($i=1; $i<count($this->Extents); $i++) {
	                    $minx = min($minx, $this->Extents[$i][0]);
	                    $miny = min($miny, $this->Extents[$i][1]);
	                    $maxx = max($maxx, $this->Extents[$i][2]);
	                    $maxy = max($maxy, $this->Extents[$i][3]);
	                }
	                $allExtStr = $minx .'+'. $miny .'+'. $maxx .'+'. $maxy;
	            }
            }
        }
        
        
        $zp .= "\"allextent\": \"$allExtStr\", ";
        
        // Add 'Zoom To All' button if 'zoomAll' selcted in config
        if ($this->doZoomAll && $this->numResultsTotal > 1) {
            $zp .= "\"zoomall\": true, ";
        } else {
            $zp .= "\"zoomall\": false, ";
        }
        
        
        
        // Message for more records found than limit set in ini file
        if ($this->numResultsTotal == $this->limitResult) {
            
        }
        
        // Autozoom to selected fatures if 'autoZoom' selcted in config
        if ($this->mode != "query"  && $this->doAutoZoom && $this->numResultsTotal > 0) {
            $zp .= "\"autozoom\": \"auto\", ";
        // Re-load map frame to highlight selected features
        } elseif ($this->mode != "query"  && $this->highlightSelected) {
            $zp .= "\"autozoom\": \"highlight\", ";
        } else {
            $zp .= "\"autozoom\": false, ";
        }
        
        $zp .= "\"infoWin\": \"". $_SESSION['infoWin'] ."\"";
        
        $zp .= "}";
        
        // Register resultlayers for highlight in case of nquery (selection)
        if ($this->mode != "query"  &&  $this->mode != "iquery" && $this->highlightSelected && $this->numResultsTotal > 0) {
            $_SESSION["resultlayers"] = $this->resultlayers;
        }
        
        //$this->allResStr .= $zStr;
        return $zp;

    }
    
    


} // END CLASS




?>