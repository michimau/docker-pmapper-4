<?php

/******************************************************************************
 *
 * Purpose: export query results as XLS document
 * Author:  Armin Burger
 *
 ******************************************************************************
 *
 * Copyright (c) 2003-2007 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/

/**
* Class for QueryByPoint
*
* @author Armin Burger
* @copyright Copyright (c) 2003-2012 Armin Burger
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
* @package query
*
*/

class QueryByPoint
{
    
    /**
     * Init function
     * @param msMapObj $map
     * @param array $xyList
     */
    public function __construct($map, $xyList)
    {
        //error_log($xyList[0]);
        $x_geo = $xyList[0];
        $y_geo = $xyList[1];
        $XY_geo = ms_newPointObj();
        $XY_geo->setXY($x_geo, $y_geo);
        $searchArea = -1;   // ===> USE TOLERANCE IN MAP FILE FOR EACH LAYER <===
        
        // Use '@' to avoid warning if query found nothing
        $map->queryByPoint($XY_geo, MS_MULTIPLE, $searchArea);
    }
   
}

?>