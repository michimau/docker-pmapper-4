<?php

/**
* Class for raw parsing of query result. 
*
* @author Armin Burger
* @copyright Copyright (c) 2003-2012 Armin Burger
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
* @package query
*
*/


class QueryResultRaw extends QueryResult
{
    /**
     * Constructor
     * @param array $result
     */
    public function __construct($result)
    {
        parent::__construct($result);
    }
    
    protected function parseLayerList($layerListIn)
    {
        $layerListOut = array();
        foreach ($layerListIn as $rLayer) {
            $layerOut = array();
            $encoding = $rLayer['params']['encoding'];
            $recOut = array();
            foreach ($rLayer['resultList'] as $recIn) {
                foreach ($recIn as $fld => $val) {
                    if (is_array($val)) {
                        $recOut[$fld] = $val;
                    } else {
                        if ($encoding) {
                            if ($encoding != "UTF-8") {
                                $val = iconv($encoding, "UTF-8", $val);
                            }
                        } else {
                            $val = utf8_encode($val);
                        }
                        $recOut[$fld] = $val;
                    }
                }
                $layerOut['resultList'][] = $recOut;
            }
            $layerOut['layerparams'] = $rLayer['params'];

        }
        $layerListOut[] = $layerOut;
        
        return $layerListOut;
    }
    
    
}


?>