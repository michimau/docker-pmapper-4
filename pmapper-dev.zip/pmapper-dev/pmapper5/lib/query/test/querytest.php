<?php


/**
* Main class for Query
*
* @author Armin Burger
* @copyright Copyright (c) 2003-2012 Armin Burger
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
* @package query
*
*/

class Query 
{ 
	/**
	 * request parameters
	 * @var array
	 */
	protected $params;
	
	/**
	 * Point/rectangle x/y list
	 * @var array
	 */
	protected $xyList;
	
	/**
	* MS Groups for querying
	* @var array
	*/
	protected $querygroups;
	
	/**
	 * Map projection as EPSG code
	 * @var string
	 */
	protected $crs;
	
	protected $resultindexes = NULL;
	protected $resulttileindexes = NULL;

    
	/**
	 * Class constructor
	 * @param mapObj $map
	 * @param array $params
	 */
    public function __construct($map, $params)
    {
        $this->map = $map;
        $this->params = $params;
        
        if (isset($params['mode'])) {
            $this->mode = $params['mode'];
        } else {
            $this->mode = "attribute";
        }
        
        $this->querygroups = explode(",", $params['groups']);
        $this->scale = $params['scale'];
        $this->crs = strtolower($params['crs']);
        
        if (isset($params['queryxy'])) {
            $this->xyList = explode(",", $params["queryxy"]);
        }
        //pm_logDebug(3, $this->querygroups, "querygroups query.php->__construct");
 
        $this->highlightSelected = $_SESSION['highlightSelected'];
        $this->limitResult = $_SESSION['limitResult'];
        $this->autoZoom = $_SESSION['autoZoom'];
        $this->zoomAll = $_SESSION['zoomAll'];
        $this->grouplist = $_SESSION['grouplist'];

        $_SESSION['mode'] = $this->mode;
        
        // RESTRICT QUERY TO VISIBLE LAYERS IN THE SCOPE OF CURRENT SCALE
        if ($this->mode != "attribute") {
            PMCommon::setGroups($this->map, $this->querygroups, $this->scale, 0, 1);
        }
    }

    /**
     * Run the queries
     */
    public function processQuery()
    {
        $this->prepareQuery();
        $resultTotal = $this->execMapQuery();
        return json_encode($resultTotal);
        
    }
    
    /**
     * Prepare queries for correct results in Mapserver
     */
    protected function prepareQuery()
    {
        $this->map->setProjection("init=$this->crs");
        
        // Set $this->map->extent to values of current map extent
        // otherwise values of TOLERANCE in map file are not interpreted correctly
        $mapExt = explode(",", $this->params['mapext']);
        $this->map->setExtent($mapExt[0], $mapExt[1], $mapExt[2], $mapExt[3]);

        // Patch from Alessandro Pasotti for fixing problems with result returned
        $this->map->setSize($this->params['mapwidth'], $this->params['mapheight']);
        $this->map->preparequery();
    }
  


    /**
     * Execute the MapScript queryBy... methods and return results as multidimension array
     * @return array
     */
    protected function execMapQuery()
    {
        $msVersion = ms_GetVersionInt();
        
		for ($i = 0; $i < $this->map->numlayers; $i++){
	    	$qLayer = $this->map->getLayer($i);
	        if ($qLayer->getMetaData('PM_RESULT_DATASUBSTITION') != '') {
	            $oldData[$i] = $qLayer->data;
	         	$qLayer->set('data', $qLayer->getMetaData('PM_RESULT_DATASUBSTITION'));
	        }
	    }
        
	    if ($this->mode == "point") {
	        $qPoint = ms_newPointObj();
	        $qPoint->setXY($this->xyList[0], $this->xyList[1]);
	    } elseif ($this->mode == "rect") {
	        $qRect = ms_newRectObj();
	        $qRect->setExtent($this->xyList[0], $this->xyList[1], $this->xyList[2], $this->xyList[3]); 
	    } elseif ($this->mode == "shape") {
	        $qShape = ms_shapeObjFromWkt($this->params['shpwkt']);
	    }
	        
	    // Loop through msLayers of msGroups
	    $resultTotal = array();
	    foreach ($this->grouplist as $i=>$grp) {
	        if (in_array($grp->getGroupName(), $this->querygroups)) {
    	        $resultGroup = array();
    	        $glayerList = $grp->getLayers();
    	        $grpBounds = array('minx'=>999999999, 'miny'=>999999999, 'maxx'=>-999999999, 'maxy'=>-999999999);
    	        $grpNumResults = 0;
    	        foreach ($glayerList as $gLayer) {
    	            $qLayer = $this->map->getLayerByName($gLayer->getLayerName());
    	            
    	            // use layers with complex queries that are too long to select results
    	            // cause maxscaledenom is not used...
    	            $dataSubstitution = false;
    	            if ($qLayer->getMetaData('PM_RESULT_DATASUBSTITION') != '') {
    	                $dataSubstitution = true;
    	                $oldData = $qLayer->data;
    	                $qLayer->set('data', $qLayer->getMetaData('PM_RESULT_DATASUBSTITION'));
    	            }
    	            
    	            $projList = $this->checkProjection($qLayer);
    	            
    	            if ($this->mode == "point") {
    	                @$qLayer->queryByPoint($qPoint, MS_MULTIPLE, -1);
    	            } elseif ($this->mode == "rect") {
    	                @$qLayer->queryByRect($qRect);
    	            } elseif ($this->mode == "shape") {
    	                @$qLayer->queryByRect($qShape);
    	            } elseif ($this->mode == "attribute") {
    	                $params = $this->getAttributeQueryParams();
    	            }
    	            
    	            // get records from query result
    	            $tiledShape = $qLayer->connectiontype == MS_TILED_SHAPEFILE ? true : false;
    	            $qLayer->open();
    	            $numResults = $qLayer->getNumResults();
    	            $grpNumResults += $numResults;
    	            $resultLayer = array();
    	            for ($iRes=0; $iRes < $numResults; $iRes++) {
    	                $qRes = $qLayer->getResult($iRes);
    	                if ($msVersion >= 60000) {
    	                    $qShape = $qLayer->getShape($qRes);
    	                } else {
    	                    $qShape = $qLayer->getShape($qRes->tileindex,$qRes->shapeindex);
    	                }
    	                $rec = $qShape->values;
    	                $bounds = $qShape->bounds;
    	                if ($projList) {
    	                    $bounds->project($projList['layer'], $projList['map']);
    	                }
    	                $shpBounds = array($bounds->minx, $bounds->miny, $bounds->maxx, $bounds->maxy);
    	                $rec['_pmshapebounds_'] = $shpBounds;
    	                
    	                $qShpIdx = $qShape->index;
    	                if ($tiledShape && $qShape->tileindex != -1) {
    	                    $qShpIdx = "$qShape->tileindex@$qShpIdx";
    	                }
    	                $rec['_pmshapeindex_'] = $qShpIdx;
    	                $resultGroup['resultList'][] = $rec;
    	                
    	                $grpBounds['minx'] = min($grpBounds['minx'], $bounds->minx);
    	                $grpBounds['miny'] = min($grpBounds['miny'], $bounds->miny);
    	                $grpBounds['maxx'] = max($grpBounds['maxx'], $bounds->maxx);
    	                $grpBounds['maxy'] = max($grpBounds['maxy'], $bounds->maxy);
    	            }
    	            $qLayer->close();
    	            
    	            // reset data tag if substituted
    	            if ($dataSubstitution) {
    	                $qLayer->set('data', $oldData);
    	            }
    	             
    	        }
    	        if ($grpNumResults > 0) {
        	        $resultGroup['groupBounds'] = array_values($grpBounds);
        	        $resultGroup['numResults'] = $grpNumResults;
        	        $resultGroup['name'] = $grp->getGroupName();
        	        $resultGroup['description'] = $grp->getDescription();
        	        $resultGroup['encoding'] = $gLayer->getLayerEncoding();
        	        $resultTotal[] = $resultGroup;
    	        }
	        }
	    }
	    
	    return $resultTotal;
    }
    
    
    /**
     * Check if map and layer have difefrent projections
     * @param array $qLayer
     */
    protected function checkProjection($qLayer)
    {
        $mapProjStr = $this->map->getProjection();
        $qLayerProjStr = $qLayer->getProjection();
        if ($mapProjStr && $qLayerProjStr && $mapProjStr != $qLayerProjStr) {
            $projList['map'] = ms_newprojectionobj($mapProjStr);
            $projList['layer'] = ms_newprojectionobj($qLayerProjStr);
            return $projList;
        } else {
            return false;
        }
    }
    
    
    /**
     * 
     * Enter description here ...
     * @return multitype:multitype: unknown Ambigous <>
     */
    protected function getAttributeQueryParams()
    {
        // Definition of search parameters with external methods
        $aparamList = array();
        if (isset($this->params['externalSearchDefinition'])) {
            $aparamList['qLayerName'] = $this->params['layerName'];
            $aparamList['qLayerType'] = $this->params['layerType'];
            $aparamList['fldName']    = $this->params['fldName'];
            $aparamList['qStr']       = $this->params['qStr'];
            pm_logDebug(3, $this->params, "Parameters for REQUEST array \nfile: query.php->q_execAttributeQuery \n");
        
            // Default using search.xml definitions
        } else {
            $searchArray = array();
            $searchitem = $this->params['searchitem'];
            foreach ($this->params as $key=>$val) {
                if ($key != "findlist" && $key != "searchitem") {
                    $searchArray[$key] = urldecode($val); //utf8_encode($val);
                }
            }
            $search = new XML_search($this->map, $_SESSION['PM_SEARCH_CONFIGFILE']);
            $searchParams = $search->getSearchParameters($this->map, $searchitem, $searchArray);
            $aparamList['qLayerName'] = $searchParams['layerName'];
            $aparamList['qLayerType'] = $searchParams['layerType'];
            $aparamList['fldName']    = $searchParams['firstFld'];
            $aparamList['qStr']       = $searchParams['qStr'];
        
            pm_logDebug(2, $searchArray, "Parameters for searchArray \nfile: query.php->q_execAttributeQuery \n");
            pm_logDebug(2, $searchParams, "Parameters for searchParams \nfile: query.php->q_execAttributeQuery");
        }
        
        return $aparamList;
    }
    
    /**
     * PRINT RESULTS FOR GROUP
     */
    function printGroups()
    {
        $this->numResultsTotal = 0;
        $resStr = "[ [";
        
        // Write results for all query groups
        $c = 0;
        
        foreach ($this->grouplist as $c=>$grp){
            if (in_array($grp->getGroupName(), $this->querygroups, TRUE)) {
        
                $this->selHeaders = $grp->getResHeaders();
                $this->selStdHeaders = $grp->getResStdHeaders();
                $glayerList = $grp->getLayers();
        
                $this->grpNumResults = 0;
                $lp = 1;  
                
                // Process all layers for group 
                $this->layersResStr = "";
                $glayerListCount = count($glayerList);
                $this->lc = 0;
                foreach ($glayerList as $l) {
                    $this->glayer = $l;
                    $layType = $this->printLayer();      //@@@@@@// 
                    
                    // Add comma separator if more than one layer per group adds result row
                    if ($this->query && $layType != 4) {
                        if ($this->query->getLayNumResults() > 0 ) {
                            $this->lc++;
                        }
                    }
                    
                    // Unset query variable (otherwise duplicated values in some cases)
                    //unset($this->query);
                    $this->query = NULL;   ## changed from unset to setting to NULL
                }
                
                if ($this->grpNumResults > 0) {
                    //error_log($this->grpNumResults);
                    if ($c > 0) $this->allResStr .= ", ";
                    $this->numResultsTotal += $this->grpNumResults;
                    $this->printGrpResString($grp);
                    //$c++;
                }
                
            }
        }
        
        $zp = $this->printZoomParameters();
        
        $this->allResStr .= "], $zp ]";

    }
 
 
    function printGrpResString($grp)
    {
        $grpName = $grp->getGroupName();
        $grpDesc = $grp->getDescription();
        
        $grpResStr  = "{\"name\": \"$grpName\", \"description\": \"$grpDesc\", \"numresults\": $this->grpNumResults, ";
        $grpResStr .= $this->fieldHeaderStr;
        $grpResStr .= $this->layersResStr;
        $grpResStr .= "]} ";

        return $grpResStr;
    }

 
    /**
     * PRINT RESULTS GROUP LAYER
     */
    function printLayer()
    {
        $this->qLayer = $this->map->getLayer($this->glayer->getLayerIdx());
        $resFldList = $this->glayer->getResFields();
        $qLayerType = $this->qLayer->type;
        $qLayerConnType = $this->qLayer->connectiontype;
        $this->qLayerName = $this->qLayer->name;
        //error_log("lay  " .$this->qLayerName);

        // Exclude WMS and annotation layers and layers with no result fields defined
        if ($qLayerConnType != 7  &&  $qLayerType != 4  && (isset($resFldList[0]) && $resFldList[0] != '0')) {
            $XYLayerProperties = $this->glayer->getXYLayerProperties();
            
            $this->q_printStandardLayer();  //@@@@@@//

            
            if ($this->query) {
                $this->fieldHeaderStr = $this->query->getFieldHeaderStr($this->selHeaders, $this->selStdHeaders);
                $this->colspan = count($this->selHeaders) + 1;
            }
            
            
        // WMS layer
        //} elseif ($qLayerType == 3 && $qLayerConnType == 7 ) {
        } elseif ($qLayerConnType == 7 ) {
            //error_log('pippo');
            $this->fieldHeaderStr = "";
            $this->q_printWMSLayer();           //@@@@@@//

        }
        
        if ($this->query && $qLayerType != 4) {
            //if ($this->qLayer->getNumResults() > 0) {
            
            if ($this->query->getLayNumResults() > 0) {
                $sep = $this->lc > 0 ? ", " : "";
                $this->layersResStr .= $sep . $this->query->getResultString(); 
                $this->grpNumResults += $this->query->getLayNumResults();
            }
        }
        
        return $qLayerType;

    }
 
 
    /**
     * PRINT RESULTS FOR STANDARD LAYER
     */    
    function q_printStandardLayer()
    {   
        if ($this->qLayer->getNumResults() > 0) {
                                            
            $this->query = new DQuery($this->map, $this->qLayer, $this->glayer, $this->zoomFull);
            
            // For Select function (nquery): get indexes of result shapes and max extent of all shapes
            if ($this->mode == "nquery") {
                $this->resultlayers[$this->qLayerName] = $this->query->returnResultindexes();
                $resulttilelayers[$this->qLayerName] = $this->query->returnResultTileindexes();
                $_SESSION['resulttilelayers'] = $resulttilelayers;
                $this->Extents[] = $this->query->returnMaxExtent();
            } 
        }
    }
    
    
    
    /**
     * PRINT RESULTS FOR WMS LAYER
     */
    function q_printWMSLayer()
    {
        // Set map width, height and extent for use in WMS query
        $this->map->set("width", $this->mapwidth);
        $this->map->set("height", $this->mapheight);
        $this->map->setextent($this->minx_geo, $this->miny_geo, $this->maxx_geo, $this->maxy_geo);
        
        // Run query and print put results
        $this->query = new WMSQuery($grp, $this->qLayer, $this->x_pix, $this->y_pix );
        $fieldHeaderStr = $this->query->getFieldHeaderStr($this->selHeaders, $this->selStdHeaders);
        $this->colspan = $this->query->colspan;
    }
    
    
    /**
     *  PROCESS ZOOM INFO AND SET RESULTLAYERS
     */
    function q_printZoomParameters()
    {
        
        $zp = "{";
        
        // Get the maximum extent for more than 1 layer if 'autoZoom' or button 'zoomAll' selcted in config 
        //print_r($this->Extents);
        $allExtStr = "";
        if ($this->zoomFull && $this->numResultsTotal > 0) {
            if (is_array($this->Extents) ) {
	        	if (count($this->Extents) < 2) {
	        		$allExtStr = join("+", $this->Extents[0]);
	            } else {
	                $minx = $this->Extents[0][0];
	                $miny = $this->Extents[0][1];
	                $maxx = $this->Extents[0][2];
	                $maxy = $this->Extents[0][3];
	        
	                for($i=1; $i<count($this->Extents); $i++) {
	                    $minx = min($minx, $this->Extents[$i][0]);
	                    $miny = min($miny, $this->Extents[$i][1]);
	                    $maxx = max($maxx, $this->Extents[$i][2]);
	                    $maxy = max($maxy, $this->Extents[$i][3]);
	                }
	                $allExtStr = $minx .'+'. $miny .'+'. $maxx .'+'. $maxy;
	            }
            }
        }
        
        
        $zp .= "\"allextent\": \"$allExtStr\", ";
        
        // Add 'Zoom To All' button if 'zoomAll' selcted in config
        if ($this->doZoomAll && $this->numResultsTotal > 1) {
            $zp .= "\"zoomall\": true, ";
        } else {
            $zp .= "\"zoomall\": false, ";
        }
        
        
        
        // Message for more records found than limit set in ini file
        if ($this->numResultsTotal == $this->limitResult) {
            
        }
        
        // Autozoom to selected fatures if 'autoZoom' selcted in config
        if ($this->mode != "query"  && $this->doAutoZoom && $this->numResultsTotal > 0) {
            $zp .= "\"autozoom\": \"auto\", ";
        // Re-load map frame to highlight selected features
        } elseif ($this->mode != "query"  && $this->highlightSelected) {
            $zp .= "\"autozoom\": \"highlight\", ";
        } else {
            $zp .= "\"autozoom\": false, ";
        }
        
        $zp .= "\"infoWin\": \"". $_SESSION['infoWin'] ."\"";
        
        $zp .= "}";
        
        // Register resultlayers for highlight in case of nquery (selection)
        if ($this->mode != "query"  &&  $this->mode != "iquery" && $this->highlightSelected && $this->numResultsTotal > 0) {
            $_SESSION["resultlayers"] = $this->resultlayers;
        }
        
        //$this->allResStr .= $zStr;
        return $zp;

    }
    
    

    
    
    /** 
     * RETURNS THE RESULT STRING (FROM VARABLE $qStr)
     */
    function getResultString()
    {
        return $this->qStr;
    }
    
    
    /** 
     * RETURNS THE NUMBER OF RECORDS OF THE QUERY RESULT FOR A LAYER
     */
    function getLayNumResults()
    {
        return $this->numResults;
    }
    
    
    // Abstract methods: returnNumResults
    function setNumResults(){}
    
    
    function returnResultindexes()
    {
        return $this->resultindexes;
    }
    
    function returnResultTileindexes()
    {
        return $this->resulttileindexes;
    }
    
    
    
    /** 
     * Return maximum extent for all shapes found in query
     * used for NQUERY
     */
    function returnMaxExtent() 
    {
        $bufX = 0.05 *($this->mExtMaxx - $this->mExtMinx);
        $bufY = 0.05 *($this->mExtMaxy - $this->mExtMiny);
        $ExtMinx = $this->mExtMinx - $bufX;
        $ExtMiny = $this->mExtMiny - $bufY;
        $ExtMaxx = $this->mExtMaxx + $bufX;
        $ExtMaxy = $this->mExtMaxy + $bufY;
        
        if ($ExtMinx == $ExtMaxx || $ExtMiny == $ExtMaxy) {
            $ExtMinx = $ExtMinx - (abs($bufX * $ExtMinx));
            $ExtMiny = $ExtMiny - (abs($bufY * $ExtMiny));
            $ExtMaxx = $ExtMaxx + (abs($bufX * $ExtMaxx));
            $ExtMaxy = $ExtMaxy + (abs($bufY * $ExtMaxy));
        }

        $maxExtent = array($ExtMinx, $ExtMiny, $ExtMaxx, $ExtMaxy);
        
        return $maxExtent;
    }


   
    
    /**
     * RESULT TABLE: FIELD HEADER
     * Print the table header for every single group/layer
     */
    function getFieldHeaderStr($selHeaders, $selStdHeaders)
    {
        $slink = $this->qLayerType != 3 ? "@" : "#";
        
        // TABLE HEADER: ATTRIBUTE NAMES...
        $h = "\"header\": [\"$slink\"";
        $sh = "\"stdheader\": [\"$slink\"";
        
        for ($iField=0; $iField < sizeof($selHeaders); $iField++) {
            $h .= ",\"" . $selHeaders[$iField] . "\"";
            $sh .= ",\"" . $selStdHeaders[$iField] . "\"";
        }
        
        $h .= "]";
        $sh .= "]";
        
        return "$h, $sh, \"values\": [ ";
    }
    
    
    /**
     * RESULT TABLE: FIELD VALUES
     * Print all field values (except shapeindex) for single layer
     */
    function printFieldValues($fldName, $fldValue)
    {
        // Change format for decimal field values
        /*
        if (is_numeric($fldValue)) {
            if (preg_match('/\./', $fldValue)) {
                $fldValue = number_format($fldValue, 2, ',', '');
            }
        } 
        */
        
        // !!!! ENCODE ALL STRINGS IN UTF-8 !!!!
        if ($this->layerEncoding) {
            if ($this->layerEncoding != "UTF-8") {
                $fldValue = iconv($this->layerEncoding, "UTF-8", $fldValue);
            }
        } else {
            $fldValue = utf8_encode($fldValue);
        }
        
        // Escape double quotes & backslashes; replace carriage return 
        //$fldValue=preg_replace("/\r?\n/", "\\n", addslashes($fldValue));
        $fldValue=preg_replace(array('/\r?\n/', '/\\\/', '/"/'), array('\\n', '\\\\\\', '\\"'), $fldValue);
        
        
        $valStr = ", ";
    
        $hyperFieldList = $this->glayer->getHyperFields();
        // Check for hyperlinks
        if (count($hyperFieldList) > 0) {
            $hyperFieldsValues = $hyperFieldList[0];
            $hyperFieldsAlias = $hyperFieldList[1];
            if (in_array($fldName, $hyperFieldsValues) && $fldValue) {
                $valStr .= "{\"hyperlink\": [\"$this->qLayerName\",\"$fldName\",\"$fldValue\",\"";
                //$valStr .= "{\"hyperlink\": [\"$this->qLayerName\",\"$fldName\",\"" . addslashes($fldValue) . "\",\"";
                // Print ALIAS if defined
                if (array_key_exists($fldName, $hyperFieldsAlias)) {
                    $valStr .= $hyperFieldsAlias[$fldName];
                // else field VALUE
                } else {
                    $valStr .= $fldValue;
                }
                
                $valStr .= "\"]}";
           } else {
                $valStr .= "\"$fldValue\"";
           }
           
        // NO hyperlink so just print normal output
        } else {
            $valStr .= "\"$fldValue\"";
        }
        
        return $valStr;
    }
    
    
    
    /**
     * Connect to DB with jointable, return connection handler
     */ 
    function dbConnect($dsn)
    {
        $dbh = DB::connect($dsn);
        if (DB::isError($dbh)) {
            #die ($dbh->getMessage());
            PMCommon::db_logErrors($dbh);
            return NULL;
        } else {
            return $dbh;
        }
    }



    /**
     * SEARCH VIA ATTRIBUTES
     */
    function q_execAttributeQuery()
    {
        // Definition of search parameters with external methods
        if (isset($params['externalSearchDefinition'])) {
            $this->qLayerName = $params['layerName'];
            $this->qLayerType = $params['layerType'];
            $fldName          = $params['fldName'];
            $this->qStr       = $params['qStr'];
            pm_logDebug(3, $params, "Parameters for REQUEST array \nfile: query.php->q_execAttributeQuery \n");
            
        // Default using search.xml definitions
        } else {
            $searchitem = $params['searchitem'];
            foreach ($params as $key=>$val) {
                if ($key != "findlist" && $key != "searchitem") {
                    $searchArray[$key] = urldecode($val); //utf8_encode($val);
                }
            } 
            
            $search = new XML_search($this->map, $_SESSION['PM_SEARCH_CONFIGFILE']);
            $searchParams = $search->getSearchParameters($this->map, $searchitem, $searchArray);
            $this->qLayerName = $searchParams['layerName'];
            $this->qLayerType = $searchParams['layerType'];
            $fldName          = $searchParams['firstFld'];
            $this->qStr       = $searchParams['qStr'];
            
            pm_logDebug(2, $searchArray, "Parameters for searchArray \nfile: query.php->q_execAttributeQuery \n");
            pm_logDebug(2, $searchParams, "Parameters for searchParams \nfile: query.php->q_execAttributeQuery");
        }
        
        // Return layer type
        $this->qLayer = $this->map->getLayerByName($this->qLayerName);
        //$this->qLayerType = $this->qLayer->connectiontype;
        
        // Get group and glayer objects
        $GroupGlayer = PMCommon::returnGroupGlayer($this->qLayerName);
        $this->grp = $GroupGlayer[0];
        $this->glayer = $GroupGlayer[1];
        $this->XYLayerProperties = $this->glayer->getXYLayerProperties();
        
        $this->layerEncoding = $this->glayer->getLayerEncoding();

        if ($this->qLayerType == "shape" || $this->qLayerType == "ms" || $this->qLayerType == "oracle") {
            if ($layFilter = $this->qLayer->getFilterString()) {
				$mapLayerFilterItem = $this->qLayer->filteritem;
				if ($layFilter[0] == '/') {
					$operator = '=~';
				} else {
					$operator = '=';
				}
				$this->qStr = "(\"[$mapLayerFilterItem]\" $operator $layFilter AND ($this->qStr) )";
                pm_logDebug(3, $this->qStr, "query string including FILTER -- query.php->q_execAttributeQuery");
            }
            if ($this->qLayerType == "oracle") {
                 @$this->qLayer->queryByAttributes(null, $this->qStr, MS_MULTIPLE);
            } else {
                 @$this->qLayer->queryByAttributes($fldName, $this->qStr, MS_MULTIPLE);
            }
        }
    }
    
    /**
     * Print search
     */
    function q_printAttributeQuery()
    {
        $selHeaders = $this->grp->getResHeaders();
        $selStdHeaders = $this->grp->getResStdHeaders();
        $this->colspan = count($selHeaders) + 1;
        
        // PROCESS QUERY DEPENDING ON LAYER TYPE
        if ($this->qLayerType == "postgis") {
            $this->query = new PGQuery($this->map, $this->qLayer, $this->glayer, $this->qStr, $this->zoomFull);
        } else {
            // Normal Layer
            if (!$this->XYLayerProperties) {
                $this->query = new DQuery($this->map, $this->qLayer, $this->glayer, $this->zoomFull);
            } else {
                //echo $this->qStr;
                $this->query = new XYQuery($this->map, $this->qLayer, $this->glayer, $this->qStr, 1, $this->zoomFull);
            }
        }
        
        
        $this->layersResStr .= $this->query->getResultString();
        $this->numResultsTotal += $this->query->getLayNumResults();
        $this->fieldHeaderStr = $this->query->getFieldHeaderStr($selHeaders, $selStdHeaders);
        if ($this->numResultsTotal > 0) {
            $this->resultlayers[$this->qLayerName] = $this->query->returnResultindexes();
            $resulttilelayers[$this->qLayerName] = $this->query->returnResultTileindexes();
            $_SESSION['resulttilelayers'] = $resulttilelayers;
        }
        $this->Extents[] = $this->query->returnMaxExtent();
        
        $this->allResStr = "[ [";
        
        if ($this->numResultsTotal > 0) {
            $this->grpNumResults = $this->numResultsTotal;
            $this->printGrpResString($this->grp);
        }
        $zp = $this->q_printZoomParameters();
        
        $this->allResStr .= "], $zp ]";

        //echo "total : $this->numResultsTotal ";
            
    }

    /**
     * decode from utf
     */
    function q_strDecode($inval)
    {
        // DECODE QUERY STRING FROM UTF-8 
        if ($this->layerEncoding) {
            if ($this->layerEncoding != "UTF-8") {
                return iconv("UTF-8", $this->layerEncoding, $inval);
            } else {
                return $inval;
            }
        } else {
            return utf8_decode($inval);
        }
    }





} // END CLASS




?>