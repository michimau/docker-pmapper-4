<?php

require_once("../globals.php");
require_once("../common.php");
require_once("querytest.php");

$params['mode'] = 'rect';
$params['queryxy'] = "747655.72875,5861190.1137939,1510803.019043,6575417.7059912";
$params['format'] = "raw";
$params['mapext'] = "-3087648.601953,4344679.472827,7087648.601953,10655320.527173";
$params['scale'] = 27734017;
$params['mapwidth'] = 1040;
$params['mapheight'] = 645;
$params['groups'] = "cities10000eu";
$params['crs'] = "EPSG:900913";

// Run QUERY
$mapQuery = new Query($map, $params);
$queryResult = $mapQuery->processQuery();


//$queryResult  = "{}";


echo "{\"queryResult\":$queryResult}";


?>