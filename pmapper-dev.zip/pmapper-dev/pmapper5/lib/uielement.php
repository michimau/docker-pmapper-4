<?php

/**
* Class for UI elements
* Legacy functions from p.mapper 4; consider replacing with newer JS UI elements
*
* @author Armin Burger
* @copyright Copyright (c) 2003-2012 Armin Burger
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
* @package uielement
*/
 

class UiElement
{

    
   /**
    * TOC and Legend container
    */
    public static function toolMenu($menu, $menuid, $menuname)
    {    
        $html  = "<div id=\"tool$menuid\">";
        $html .= "<a id=\"pm_". $menuid ."_start\" class=\"pm-menu-button\"   onclick=\"pmMenu_toggle('pm_$menuid');\">" . _p($menuname) . "<img src=\"images/menudown.gif\" alt=\"\" /></a>\n";
        $html .= "<ul id=\"pm_" . $menuid . "\" class=\"pm-menu\" >";
        foreach ($menu as $m => $ma) {
            $html .= "<li id=\"pmenu_" . $ma[1] . "\">" . $ma[0] . "</li>\n";      
        }
        $html .= "</ul>";
        $html .= "</div>";
        
        return $html;  
    }
    
    
    /**
    * Tool links
    */
    public static function toolLinks($menu)
    {    
        $html  = "<div id=\"toolLinkContainer\"><ul class=\"pm-tool-links\">";
        foreach ($menu as $m => $ma) {
            $html .= "<li>";
            $html .= "<a id=\"plink_$m\" href=\"javascript:{$ma[1]}()\">\n";
            $html .= "<img style=\"background:transparent url(images/menus/{$ma[2]}) no-repeat;height:16px;width:16px\" src=\"images/transparent.png\" alt=\"$m\" />";
            $html .= "<span>{$ma[0]}</span></a></li>\n";
        }
        $html .= "</ul></div>";
        
        return $html;  
    }
    
    
   /**
    * TOC and Legend container
    */
    public static function tocContainer($userAgent)
    {
        $html = "<div id=\"tocContainer\">
              <form id=\"layerform\" method=\"get\" action=\"\">    
                <div id=\"toc\"       class=\"TOC\" style=\"" . ($userAgent == "mozilla" ? "height:100%" : "height:auto") ."; \"></div>
                <div id=\"toclegend\" class=\"TOC\" style=\"" . ($userAgent == "mozilla" ? "height:100%" : "height:auto") . "; display:none;\"></div>
              </form>
            </div>
        ";
        return $html;
    }
    
    
    /**
     * Create tabs for TOC/Legend
     */
    public static function tocTabs($tablist, $enable=false)
    {
        $html = "";
        if ($_SESSION['layerAutoRefresh'] == 0) {
            $html .= "<div id=\"autoRefreshButton\"></div>";
        }
        if ($_SESSION['legendStyle'] == "swap" || $enable) { 
            $html .= "  <div id=\"tocTabs\">\n       <ul class=\"tocTabs\">\n";
            foreach($tablist as $k => $v) {
                $html .= "         <li><a href=\"javascript:" . $v[1] . "()\"  id=\"tab_$k\">" . $v[0] . "</a></li>\n";                
            }
            $html .= "       </ul> \n     </div>\n";
        } else {
            $html .= "";
        }
        return $html;
    }
    
    
    
   /**
    * Search form 
    * requires to add JS function 'PM.Search.setSearchOptions()' to document ready call
    */
    public static function searchContainer($style)
    {
        $html  = "<div id=\"pmSearchContainer\">";
        $html .= "<form id=\"pmSearchForm\" action=\"blank.html\" onsubmit=\"PM.Search.submitSearch()\" onkeypress=\"return PM.Search.disableEnterKey(event)\">";
        $html .= "<table width=\"100%\" class=\"pm-searchcont pm-toolframe\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
        $html .= "<tr>";  
        $html .= "<td id=\"pmSearchOptions\" class=\"pm-searchoptions\" style=\"padding:0px 8px\"></td>";  
        if ($style == "block") $html .= "</tr><tr>";    
        $html .= "<td id=\"pmSearchItems\" class=\"pm-search-$style\"></td>";
        $html .= "</tr>";  
        $html .= "</table>";
        $html .= "</form>";
        $html .= "</div>";
        
        return $html;
    }
    
   /**
    * Scaleform with scale options
    */
    public static function scaleForm()
    {
        $html = "<div id=\"scaleArea\" class=\"TOOLFRAME\">
                <form id=\"scaleform\"  action=\"javascript:PM.Map.zoom2scale($('#scaleinput').val());javascript:PM.Form.scaleMouseOut(true)\">
                    <div id=\"scaleArea2\" class=\"rowdiv\" >
                        <div class=\"celldiv\">" . _p("Scale") . " 1:  </div>
                        <div class=\"celldiv\">
                            <div> <input type=\"text\" id=\"scaleinput\" name=\"scale\" size=\"9\" value=\"\" onkeyup=\"PM.Form.scaleMouseOut()\" onblur=\"PM.Form.scaleMouseOut(true)\" onclick=\"PM.Form.initScaleSelect()\" /></div>
                            <div id=\"scaleSuggest\" onmouseover=\"PM.Form.setScaleMO()\" onmouseout=\"setTimeout('PM.Form.scaleMouseOut()', 1000)\"></div>
                        </div>
                    </div>
                </form>
            </div>
        ";
        return $html;
    }
    
    
    
   /**
    * Header in ui-north
    */
    public static function pmHeader()
    {
        $pmLogoUrl = array_key_exists('pmLogoUrl', $_SESSION) ? $_SESSION['pmLogoUrl'] : "http://www.pmapper.net";
        $pmLogoTitle = array_key_exists('pmLogoTitle', $_SESSION) ? $_SESSION['pmLogoTitle'] : "p.mapper homepage";
        $pmLogoSrc = array_key_exists('pmLogoSrc', $_SESSION) ? $_SESSION['pmLogoSrc'] : "img/logos/logo-black.png";
        $pmVersion = array_key_exists('version', $_SESSION) ? ", v" . $_SESSION['version'] : "";
        $pmHeading = array_key_exists('pmHeading', $_SESSION) ? $_SESSION['pmHeading'] : "<a href=\"http://mapserver.gis.umn.edu\" id=\"mshref_1\" title=\"UMN MapServer homepage\" onclick=\"this.target = '_new';\">MapServer</a>&nbsp; 
                            <a href=\"http://www.dmsolutions.ca\" id=\"dmsol_href\" title=\"DM Solutions homepage\" onclick=\"this.target = '_new';\">PHP/MapScript</a>&nbsp; 
                            Framework$pmVersion";
        
        $html = "<div class=\"pm-header\"><div><a href=\"$pmLogoUrl\" 
                    title=\"$pmLogoTitle\" onclick=\"this.target = '_blank';\">
                    <img class=\"pm-logo-img\" src=\"$pmLogoSrc\" alt=\"logo\" /></a>    
                    </div>
                    <div class=\"HEADING1\">$pmHeading</div>
                </div>
        ";
        return $html;
    }
    
   /**
    * Footer in ui-south
    */
    public static function pmFooter()
    {
        $html = "<div class=\"pm-footer\">
                <div style=\"float:right;\">
                    <a href=\"http://validator.w3.org/check?uri=referer\"><img
                        src=\"img/logos/valid-xhtml10-small-blue.png\"
                        alt=\"XHTML 1.0 Strict\"  /></a>
                </div>
                <div style=\"float:right;\"><a href=\"http://mapserver.gis.umn.edu\" id=\"mapserver_href_2\" onclick=\"this.target = '_blank';\">
                    <img src=\"img/logos/mapserver-small.png\" title=\"UMN MapServer homepage\" alt=\"MapServer\" /></a>
                </div>
                <div style=\"float:right;\"><a href=\"http://www.pmapper.net\"  title=\"p.mapper homepage\" onclick=\"this.target = '_blank';\">
                    <img src=\"img/logos/pmapper.png\" title=\"p.mapper\" alt=\"p.mapper\" /></a></div>
            </div>
        ";
        return $html;
    }
    
   /**
    * Coordinates display
    */
    public static function displayCoordinates()
    {
        $html = "<div id=\"showcoords\" class=\"showcoords1\"><div id=\"xcoord\"></div><div id=\"ycoord\" ></div></div>";
        return $html;
    }
    


}



?>
