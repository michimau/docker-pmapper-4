<?php

/**
 * Class for creation of Google XYZ schema tiles 
 *
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License. See the COPYING file.
 *
 * @package map
 * 
 */
class MapTile extends PMap
{
    
    /** Default expiration time in seconds for cache  */
    protected $tileCacheExpirationDefault = 259200; // = 3600 * 24 * 3 = 3 days
    
    
    /**
     * Constructor. 
     *
     * @param mapObj $map 
     * @param array $params key-value pairs from REQUEST global var
     * @return void
     */
    public function __construct($map, $params)
    {
        parent::__construct($map, $params);
    }
    
    /**
     * Create the map image tile and stream to browser
     */
    public function create()
    {
        $this->imgFormatExt = $this->setImgFormat();
        
        if (isset($this->params['tileCache'])) {
            $z = $this->params['z'];
            $x = $this->params['x'];
            $y = $this->params['y'];
            
            $cacheMaxLevel = isset($this->params['cacheMaxLevel']) ? $this->params['cacheMaxLevel'] : null; 

            if ($cacheMaxLevel && $z > $cacheMaxLevel) {
                 $this->createMapImage();
            } else {
                $tileCacheRoot = $_SESSION['tileCacheRoot'];
                $tileCacheDir = "$tileCacheRoot/$z/$x/$y";
                $imgExtension = $this->imgFormatExt;
                $groups = join("__", $this->getGroups());
                $tileBaseName =  "$groups.$imgExtension";
                $imagePath = "$tileCacheDir/$tileBaseName";
                
                if (file_exists($imagePath)) {
                    $contenType = "image/$imgExtension"; 
                    $this->returnCacheImage($imagePath, $contenType);
                } else {
                    $this->createMapImage($tileCacheDir, $imagePath);
                }
            } 
        } else {
            $this->createMapImage();
        }
    }
    
    /**
     * Read image from tiuloe cache and return as stream
     * @param string $imagePath full path to image file 
     * @param string $contenType header content type
     */
    protected function returnCacheImage($imagePath, $contenType)
    {
        header('Content-Type:'. $contenType);
        readfile($imagePath);
    }
    
    
    /**
     * Create the map tile image. 
     * If $tileCacheDir is null directly stream image to browser. 
     * If $tileCacheDir not null save tile image as file to tilecache and read content to stream to browser
     * @param string $tileCacheDir directory for saving tiles, defaults to null 
     * @param string $imagePath full path to image file, defaults to null
     */
    protected function createMapImage($tileCacheDir=null, $imagePath=null)
    {
        $this->processMap();
        
        $googleProjDef = "+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext +towgs84=0,0,0,0,0,0,0  +no_defs";
        $this->map->setProjection($googleProjDef);
        @$this->map->setsize(256, 256);  // @ required due to some strange behaviour of MS that applies a query
        
        $ext = $this->getBbox();
        $this->map->setExtent($ext['xmin'], $ext['ymin'], $ext['xmax'], $ext['ymax']);
        
        // Adjust the extents inwards by 1/2 pixel so they are from
        // center-of-pixel to center-of-pixel, instead of edge-to-edge.
        // This is the way mapserver does it. 
        // Code fragments taken from  MapServer maptile.c => msTileSetExtent 
        // (c) 1996-2005 Regents of the University of Minnesota.
        $me = $this->map->extent;
        $dx = ($me->maxx - $me->minx) / $this->map->width;
        $dy = ($me->maxy - $me->miny) / $this->map->height;
        $this->map->setExtent($ext['xmin'] + $dx*0.5, $ext['ymin'] + $dy*0.5, $ext['xmax'] - $dx*0.5, $ext['ymax'] -$dy*0.5);
        
        $tileImg = $this->map->draw();
        
        // Set headers for MIME type and cache control
        $offset = isset($this->params['cacheExpiration']) ? $this->params['cacheExpiration'] : (isset($_SESSION['tileCacheExpiration']) ? $_SESSION['tileCacheExpiration'] : $this->tileCacheExpirationDefault) ;

        header("Expires: " . gmdate("D, d M Y H:i:s", time() + $offset) . " GMT");
        header("Content-type: image/" . $this->imgFormatExt);
        
        if ($tileCacheDir) {
            if (!file_exists($tileCacheDir)) {
                mkdir($tileCacheDir, 0777, true);
            }
            // Save image to disk and read back
            $tileImg->saveImage($imagePath);
            readfile($imagePath);
        } else {
            // Stream image directly to client
            $tileImg->saveImage(null);
        }
    }

    /**
     * Get the bounding box in Google projection coordinates for the tile absed on xyz request values
     * based on MapServer maptile.c => msTileSetExtent, (c) 1996-2005 Regents of the University of Minnesota.
     * @return array tile extent in x/y coordinates
     */
    protected function getBbox()
    {
        define("SPHEREMERC_GROUND_SIZE", (20037508.34*2));    // 20037508.342789244
        $ext = array();
        
        $x = $this->params['x'];
        $y = $this->params['y'];
        $zoom =  $this->params['z'];

        $zoomfactor = pow(2.0, $zoom);
        $tilesize = SPHEREMERC_GROUND_SIZE / $zoomfactor;
        $ext['xmin'] = ($x * $tilesize) - (SPHEREMERC_GROUND_SIZE / 2.0);
        $ext['xmax'] = (($x + 1) * $tilesize) - (SPHEREMERC_GROUND_SIZE / 2.0);
        $ext['ymin'] = (SPHEREMERC_GROUND_SIZE / 2.0) - (($y + 1) * $tilesize);
        $ext['ymax'] = (SPHEREMERC_GROUND_SIZE / 2.0) - ($y * $tilesize);
        
        return $ext;
    }
    
    
    
}


?>