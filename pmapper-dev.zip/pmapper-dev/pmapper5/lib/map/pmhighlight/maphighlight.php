<?php
/**
* Class for creation of Google XYZ schema tiles
*
* @author Armin Burger
* @copyright Copyright (c) 2003-2012 Armin Burger
* @license http://opensource.org/licenses/gpl-license.php GNU Public License. See the COPYING file.
*
* @package map
*
*/
class MapHighlight extends PMap
{

    /**
     * Constructor.
     *
     * @param mapObj $map
     * @param array $params key-value pairs from REQUEST global var
     * @return void
     */
    public function __construct($map, $params)
    {
        parent::__construct($map, $params);
    }
      
    
    
    /**
    * Main function to launch all methgods in right order
    */
    public function processMap()
    {
        $this->checkResultLayers();
        $this->imgFormatExt = $this->map->outputformat->extension;
    }
    
    
    /**
    * Check if there are resultlayers to add
    */
    protected function checkResultLayers()
    {
        // ADD RESULTLAYER: MARKING SHAPE(S) AND ADD AS IN NEW CREATED LAYER
        if (isset($_REQUEST["resultlayer"])) {
            $resultlayerStr = $_REQUEST["resultlayer"];
            if ($resultlayerStr == "remove") {
                unset($_SESSION['resultlayers']);
                unset($resultlayers);
            } else {
                $resultlayer = explode(" ", $resultlayerStr);
                $reslayname = $resultlayer[0];
                $shpindexes = explode("|", $resultlayer[1]);
                $resultlayers[$reslayname] = $shpindexes;
                $this->addResultLayer($reslayname, $shpindexes);
                $_SESSION["resultlayers"] = $resultlayers;
            }
        } elseif (isset($_SESSION["resultIndexes"])) {
            if ($_SESSION["resultIndexes"]) {
                $resultlayers = $_SESSION["resultIndexes"];
                foreach ($resultlayers as $reslayer => $shpindexes) {
                    $this->addResultLayer($reslayer, $shpindexes);
                }
            }
        }
    }
    
    
    /**
     * Adds a new layer to the map for highlighting feature
     * @param string $reslayer result layer name
     * @param array $shpindexes
     */
    protected function addResultLayer($reslayer, $shpindexes)
    {
        //error_log("added layer: $reslayer");
        $qLayer = $this->map->getLayerByName($reslayer);
        $qlayType = $qLayer->type;
        $layNum = count($this->map->getAllLayerNames());
    
    
        // Test if layer has the same projection as map
        $mapProjStr = $this->map->getProjection();
        $qLayerProjStr = $qLayer->getProjection();
    
        $changeLayProj = false;
        if ($mapProjStr && $qLayerProjStr && $mapProjStr != $qLayerProjStr) {
            $changeLayProj = true;
            $mapProjObj = ms_newprojectionobj($mapProjStr);
            $qLayerProjObj = ms_newprojectionobj($qLayerProjStr);
        }
    
        // New result layer
        if ($_SESSION['PM_TPL_MAP_FILE']) {
            // load from template map file
            $hlDynLayer = 0;
            $hlMap = ms_newMapObj($_SESSION['PM_TPL_MAP_FILE']);
            $hlMapLayer = $hlMap->getLayerByName("highlight_$qlayType");
            $hlMapLayer->set("name", "pmapper_reslayer");
            $newResLayer = ms_newLayerObj($this->map, $hlMapLayer);
    
        } else {
            // create dynamically
            $hlDynLayer = 1;
            $newResLayer = ms_newLayerObj($this->map);
            $newResLayer->set("name", "pmapper_reslayer");
            if ($qlayType == 0) {
                $newResLayer->set("type", 0);  // Point for point layer
            } elseif ($qlayType == 1 || $qlayType == 2) {
                $newResLayer->set("type", 1);  // Line for line && polygon layers
            }
            //##$newResLayer->set("type", $qlayType);  // Take always same layer type as layer itself
        }
    
        // Add selected shape to new layer
        if ($qLayer->connectiontype == MS_POSTGIS) {
            $newResLayer->set("connection", $qLayer->connection);
            if (method_exists($newResLayer, "setConnectionType")) {
                $newResLayer->setConnectionType($qLayer->connectiontype);
            } else {
                $newResLayer->set("connectiontype", $qLayer->connectiontype);
            }
            $data = $qLayer->data;
            // use layers with complex queries that are too long to select results
            // cause maxscaledenom is not used...
            if ($qLayer->getMetaData("PM_RESULT_DATASUBSTITION") != "") {
                $data = $qLayer->getMetaData("PM_RESULT_DATASUBSTITION");
            }
    
            $newResLayer->set("data", $data);
            if ($qLayerProjStr) $newResLayer->setProjection($qLayerProjStr);
    
            $glList = PMCommon::returnGroupGlayer($reslayer);
            $glayer = $glList[1];
            $layerDbProperties = $glayer->getLayerDbProperties();
            $uniqueField = $layerDbProperties['unique_field'];
            $idFilter = $uniqueField . ' IN (' . (implode(",", $shpindexes)) . ')';
            $newResLayer->setFilter($idFilter);
            //# 'normal' layers
        } else {
            // Add selected shape to new layer
    
            // Modified by Thomas RAFFIN (SIRAP)
            // use layers with complex queries that are too long to select results
            // cause maxscaledenom is not used...
            $olddata = false;
            if ($qLayer->getMetaData("PM_RESULT_DATASUBSTITION") != "") {
                $olddata = $qLayer->data;
                $qLayer->set("data", $qLayer->getMetaData("PM_RESULT_DATASUBSTITION"));
            }
    
            $qLayer->open();
            foreach ($shpindexes as $resShpIdx) {
                if (preg_match("/@/", $resShpIdx)) {
                    $idxList = explode("@", $resShpIdx);
                    $resTileShpIdx = $idxList[0];
                    $resShpIdx = $idxList[1];
                } else {
                    $resTileShpIdx = -1;
                }
                $resShape = PMCommon::resultGetShape($qLayer, null, $resShpIdx, $resTileShpIdx);  // changed for compatibility with PG layers and MS >= 5.6
    
                // Change projection to map projection if necessary
                if ($changeLayProj) {
                    // If error appears here for Postgis layers, then DATA is not defined properly as:
                    // "the_geom from (select the_geom, oid, xyz from layer) AS new USING UNIQUE oid USING SRID=4258"
                    if ($resShape) {
                        $resShape->project($qLayerProjObj, $mapProjObj);
                    }
                }
                if ($resShape) {
                    $newResLayer->addFeature($resShape);
                }
            }
    
            $qLayer->close();
    
            // Modified by Thomas RAFFIN (SIRAP)
            // use layers with complex queries that are too long to select results
            // cause maxscaledenom is not used...
            // reset data tag
            if ($olddata) {
                $qLayer->set("data", $olddata);
            }
            
            //$this->map->removeLayer($qLayer->index);  // deactivated, probably not needed any more
            
        }
    
        $newResLayer->set("status", MS_ON);
        $newResLayerIdx = $newResLayer->index;
    
        if ($hlDynLayer) {
            // SELECTION COLOR
            $iniClrStr = trim($_SESSION["highlightColor"]);
            $iniClrList = preg_split('/[\s,]+/', $iniClrStr);
            $iniClr0 = $iniClrList[0];
            $iniClr1 = $iniClrList[1];
            $iniClr2 = $iniClrList[2];
    
            // CREATE NEW CLASS
            $resClass = ms_newClassObj($newResLayer);
            $clStyle = ms_newStyleObj($resClass);
            $clStyle->color->setRGB($iniClr0, $iniClr1, $iniClr2);
            $clStyle->set("symbolname", "circle");
            $symSize = ($qlayType < 1 ? 10 : 5);
            $clStyle->set("size", $symSize);
        }
    
        // Move layer to top (is it working???)  // deactivated, probably not needed any more
        //while ($newResLayerIdx < ($layNum-1)) {
            //$this->map->moveLayerUp($newResLayerIdx);
        //}
    }
    
    
    
}

?>