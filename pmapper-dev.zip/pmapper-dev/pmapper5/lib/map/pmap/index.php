<?php
// enable short caching
session_cache_limiter('public');
session_cache_expire(240);


require_once "../../group.php";
require_once "../../pmsession.php";

// Check if PHP session still exists
if (!isset($_SESSION['session_alive'])) {
   header("HTTP/1.0 400 Bad Request");
   return false;
}
   

require_once "../../globals.php";
require_once "../../common.php";
require_once "../pmap.php";


$mapReq = new PMap($map, $_REQUEST);
$mapReq->create();

?>