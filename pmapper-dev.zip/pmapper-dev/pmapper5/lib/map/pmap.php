<?php

/**
 * Class for creation of map images 
 *
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 *
 * @package map
 * 
 */

class PMap
{
    /** 
     * @var mapObj
     */
    protected $map;
    
    /** 
     * key-value pairs, usually from REQUEST global var 
     * @var array 
     */
    protected $params;
    
    /** 
     * MapServer groups
     * @var array 
     */
    protected $groups;
    
    /**
    * Map resolution; especially required for correct scale setting together with OL
    * @var int
    */
    protected $mapResolution = 72;
    
    /**
     * Image format extension needed for mime type
     * @var string
     */
    protected $imgFormatExt;
    
    
    /**
     * Constructor. 
     *
     * @param mapObj $map 
     * @param array $params key-value pairs from $_REQUEST global var
     */
    public function __construct($map, $params)
    {
        $this->map = $map;
        $this->params = $params;
    }
    
    /**
     * Main function to launch all methgods in right order
     */
    public function processMap()
    {
        $this->addCustomLayers();
        $this->groups = $this->getGroups();
        $activeGroups = PMCommon::setGroups($this->map, $this->groups, 0, 1);
    }
    
    
    /**
     * Create map image and return stream 
     *
     * @return imageObj image stream 
     */
    public function create()
    {
        $this->map->set("resolution", $this->mapResolution);
        
        $crs = strtolower($this->params['crs']);
        if (isset($crs)) {
            $this->map->setProjection("init=$crs");
        }
        
        $this->processMap();
        $this->imgFormatExt = $this->setImgFormat();
        
        //error_log($this->params['height']);
        $width = $this->params['width'];
        $height = $this->params['height'];
        $_SESSION["mapwidth"] = $width;
        $_SESSION["mapheight"] = $height;
        @$this->map->setsize($width, $height);
        
        $bbox = $this->params['bbox'];
        $ext = explode(",", $bbox);
        $this->map->setExtent($ext[0], $ext[1], $ext[2], $ext[3]);
        
        $this->draw();
    }
    
    /**
     * Draw the map and return image stream
     */
    protected function draw()
    {
        $mapImg = $this->map->draw();
        // Set headers for MIME type
        header("Content-type: image/" . $this->imgFormatExt);
        // Stream image to client
        $mapImg->saveImage(null);
    }
    
        
    
    /**
     * Add custom layers (URL layer)
     */
    protected function addCustomLayers()
    {
        include_once("urllayer.php");
        //$this->pmap_addWMSGroups();
        if (isset($_SESSION['url_points'])) {
            if (count($_SESSION['url_points']) > 0) {
                $urlLayer = new UrlLayer($this->map);
            }
        }
    }
    

    /**
     * Returns grops for display
     * @return array
     */
    protected function getGroups() 
    {
        if (isset($this->params["groups"])) {
            $groups = explode(",", $this->params["groups"]);
        } elseif (isset($_SESSION["groups"]) && count($_SESSION["groups"]) > 0) {
            $groups = $_SESSION["groups"];
        } else {
            $groups = $_SESSION["defGroups"];
        }
        return $groups;
    }

    
    /**
     * * Set image format according to settings
     * if alternative format is defined for some layers
     * and if one of these layers is active, then use altImgFormat
     * @param bool $print
     */
    protected function  setImgFormat($print=false)
    {
        if (isset($this->params['imgformat'])) {
            $this->map->selectOutputFormat($this->params['imgformat']);
        } else {
            $altImgFormatLayers = $_SESSION['altImgFormatLayers'];
            $altImgFormat = $_SESSION['altImgFormat'];
            $useAltImgFormat = 0;
            if ($altImgFormatLayers && $altImgFormat) {
                foreach ($altImgFormatLayers as $ai) {
                    $mapLay = @$this->map->getLayerByName($ai);
                    if ($mapLay) {
                        if ((in_array($mapLay->name, $this->groups) || in_array($mapLay->group, $this->groups)) && PMCommon::checkScale($this->map, $mapLay, $this->map->scaledenom)) {
                            $useAltImgFormat = 1;
                            break;
                        }
                    }
                }
            }
            
            if (!$print) {
                if ($useAltImgFormat) {
                    $this->map->selectOutputFormat($_SESSION["altImgFormat"]);
                } else {
                    $this->map->selectOutputFormat($_SESSION["imgFormat"]);
                }
            } else {
                if ($useAltImgFormat) {
                    $this->map->selectOutputFormat($_SESSION["printAltImgFormat"]);
                } else {
                    $this->map->selectOutputFormat($_SESSION["printImgFormat"]);
                }
            }
        }
        
        $selectedFormat = $this->map->outputformat;
        return $selectedFormat->extension;
    }
    
    

    
    /**
     * Set map resolution in DPI
     * @param int $dpi
     */
    public function setMapResolution($dpi)
    {
         $this->mapResolution = $dpi;   
    }
    


}


?>
