<script type="text/javascript">

 var PM_XAJAX_LOCATION  = 'lib/xajax/';
 var PM_INCPHP_LOCATION = '<?php $_SESSION['PM_INCPHP'] ?>';
 var PM_PLUGIN_LOCATION = 'plugins'; //'<?php $PM_PLUGIN_LOCATION ?>';

 PM.SID = '<?php echo SID ?>';    
 PM.sessionName = '<?php echo session_name() ?>'; 
 PM.sessionId = '<?php echo session_id() ?>';
 PM.gLanguage = '<?php echo $gLanguage ?>';
 PM.config = '<?php echo trim($config) ?>';
 PM.tocStyle = '<?php echo $_SESSION["tocStyle"] ?>';
 PM.legendStyle = '<?php echo $_SESSION["legendStyle"] ?>';
 PM.infoWin = '<?php echo $_SESSION["infoWin"] ?>';
 PM.layerAutoRefresh = <?php echo ($_SESSION['layerAutoRefresh']) ?>;

 
 PM.pluginTocInit = [<?php if (count($plugin_jsTocInitList) > 0) echo ("'" . implode("','", $plugin_jsTocInitList) . "'"); ?>];
 <?php
    // only load configuration for activated plugins
    $ini['pluginsConfig'] = $_SESSION['pluginsConfig'];
    
    // add allGroups if not defined in XML config
    if (!$ini['map']['allGroups']) $ini['map']['allGroups']['group'] = $_SESSION['allGroups'];
    
    // set ini defGroups to session setting (necessary for URL passed parameter "dg") 
    $ini['map']['defGroups']['group'] =  $_SESSION['defGroups'];

 ?>
 
 PM.ini = <?php echo json_encode($ini) ?> ;
 
 <?php echo PMCommon::writeJSArrays() ?>
 

// Query layers: modify query results in js
PM.modifyQueryResultsFunctions = [<?php if (count($plugin_jsModifyQueryResultsFunctions) > 0) echo ("'" . implode("','", $plugin_jsModifyQueryResultsFunctions) . "'"); ?>];

</script>
