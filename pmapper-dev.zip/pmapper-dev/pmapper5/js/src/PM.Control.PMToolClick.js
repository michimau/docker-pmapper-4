OpenLayers.Control.PMToolClick = OpenLayers.Class(OpenLayers.Control, {                
    defaultHandlerOptions: {
        'single': true,
        'double': false,
        'pixelTolerance': 0,
        'stopSingle': false,
        'stopDouble': true
    },

    /**
     * Property: type
     * {OpenLayers.Control.TYPE}
     */
    type: OpenLayers.Control.TYPE_TOOL,
    
    initialize: function(options) {
        this.handlerOptions = OpenLayers.Util.extend(
            {}, this.defaultHandlerOptions
        );
        OpenLayers.Control.prototype.initialize.apply(
            this, arguments
        ); 
        this.handler = new OpenLayers.Handler.Click(
            this, {
                'click': this.onClick
            }, this.handlerOptions
        );
    }, 

    onClick: function(e) {
        var xyMap = map.getLonLatFromViewPortPx(e.xy);
        var mouseXY = xyMap.lon + ',' + xyMap.lat ;
        this.execute(mouseXY);
    },
    
    execute: function(mouseXY) {
        console.log(mouseXY);
    },
    
    CLASS_NAME: "OpenLayers.Control.PMToolClick"

});
