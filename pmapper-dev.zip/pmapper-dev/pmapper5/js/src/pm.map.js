
/******************************************************************************
 *
 * Purpose: functions related to map handling 
 * Author:  Armin Burger
 *
 ******************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/

$.extend(PM.Map,
{
    

	getNumZoomLevelsFromMap: false,
	
	resizeTimer: null,
    
    resizeTimeoutThreshold: 300,
    
    /**
     * Initialize function
     */
    init: function() {
        var mapOptions = {controls: [], allOverlays: true};
        OpenLayers.Util.extend(mapOptions, PM.mapOptions);
        
        // Only for tiled display, apply restricted minimum zoom for correct setting of slider
        if (mapOptions.restrictedZoomLevel) {
            //mapOptions.restrictedMinZoom = 19 - mapOptions.restrictedZoomLevel;
        }
        map = new OpenLayers.Map('map', mapOptions);
    },
    
    
    /**
     * Set PHP session vars for projection and max extent
     * Needs to be called again after any change to these parameters
     */
    setSessionParams: function() {
        PM.setSessionVar('mapMaxExtent', '[' + map.maxExtent.toBBOX() +']', true, null);
        PM.setSessionVar('mapProjection', map.getProjection(), false, null);
    },
    
    
    /**
     * Resize the map zone in dependency to the parent element
     * called by 'onresize' event of ui element containing the map
     */
    resizeMapContainer: function() {
        this.updateMapContainer();
        // avoid multiple resize events by setting time outs
        clearTimeout(this.resizeTimer);
        this.resizeTimer = setTimeout('PM.Map.updateMapSize()', this.resizeTimeoutThreshold);     
    },
    
    /**
     * Update container where map is located
     */
    updateMapContainer: function() {
        var mapDiv = $('#map');
        var mapParent = mapDiv.parent();
        mapDiv.css( {width:mapParent.width(), height:mapParent.height()} );
    },
    
    /**
     * Update size of OL map object
     */
    updateMapSize: function() {
        map.updateSize();
    },
    
    /**
     * Get all active MS groups
     * @returns {Array}
     */
    getActiveMsGroups: function() {
    	var msGroupsActive = [];
    	var mapLayers = map.layers;
    	for (var i=mapLayers.length-1; i>=0; i--) {
    		if (mapLayers[i].msGroupsActive) {
    			$.merge(msGroupsActive, mapLayers[i].msGroupsActive);
    		}
    	}
    	//console.log('msGroupsActive', msGroupsActive);
    	return msGroupsActive;
    },
    
    /**
     * Get all active MS groups and standard OL layers
     * @returns {Array}
     */
    getActiveGroups: function() {
    	var groupsActive = [];
    	var mapLayers = map.layers;
    	for (var i=mapLayers.length-1; i>=0; i--) {
    		var mapLayer = mapLayers[i];
    		if (mapLayer.msGroups) {
	    		if (mapLayer.msGroupsActive) {
	    			$.merge(groupsActive, mapLayer.msGroupsActive);
	    		}
    		} else {
    			if (mapLayer.getVisibility()) {
    				if (mapLayer.id != 'pmResultHighlight') {
    					groupsActive.push(mapLayer.id);
    				}
    			}
    		}
    	}
    	//console.log('msGroupsActive', msGroupsActive);
    	return groupsActive;
    },
    
    
    /**
     * Get all MS groups and standard OL layers
     * @returns {Array}
     */
    getAllGroups: function() {
    	var allGroups = [];
    	var mapLayers = map.layers;
    	for (var i=mapLayers.length-1; i>=0; i--) {
    		var mapLayer = mapLayers[i];
    		if (mapLayer.msGroups) {
	    		$.merge(allGroups, mapLayer.msGroups);
    		} else {
				if (mapLayer.id != 'pmResultHighlight') {
					allGroups.push(mapLayer.id);
				}
    		}
    	}
    	//console.log('msGroupsActive', msGroupsActive);
    	return allGroups;
    },
    
    
    /**
     * Zoom to extent, called e.g. from result table
     * @param layer
     * @param idx
     * @param extStr
     * @param zoomfull
     */
    zoom2extent: function(layer, idx, extStr, zoomfull) {
    	var ext = extStr.split(",");
    	map.zoomToExtent( new OpenLayers.Bounds(ext[0], ext[1], ext[2], ext[3]), true );
    },
    
    
    /**
     * Zoom to initial extent, 
     * read extent from URL ("me") if defined; if not, take maxExtent
     */
    zoomToInitialExtent: function() {
    	var initExtent, me;
    	if (me = PM.Util.getUrlParameter('me') ) {
    		var ext = me.split(",");
    		var initExtent = new OpenLayers.Bounds(ext[0], ext[1], ext[2], ext[3]);
    	} else {
    		var initExtent = map.maxExtent;  
    	}
    	
    	map.zoomToExtent(initExtent);  
    },
    
    /** Zoom to max extent, 
    * read extent from URL ("me") if defined; if not, take maxExtent
    */
    zoomToMaxExtent: function() {
   	    map.zoomToExtent(map.maxExtent);  
    },
    
    /**
     * Zopom to selected features 
     * uses saved extent from var "PM.extentSelectedFeatures"
     */
    zoomToSelected: function() {
    	if (PM.extentSelectedFeatures) {
    		this.zoom2extent(0, 0, PM.extentSelectedFeatures.join(","), 1);
    	}
    },
    
    
    /**
     * Clear and set invisible highlight layer and remove selections from map
     */
    clearHighlight: function() {
	    PM.setSessionVar('resultIndexes', null, false, null);
		var hlTheme = map.getLayer("pmResultHighlight");
		hlTheme.setVisibility(false);
		hlTheme.clearGrid();
		PM.extentSelectedFeatures = null;
    }
    
    
});