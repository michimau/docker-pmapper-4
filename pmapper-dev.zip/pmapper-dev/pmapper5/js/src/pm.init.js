/******************************************************************************
 *
 * Purpose: initialize all JS objects
 * Author:  Armin Burger
 *
 ******************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/

$.extend(PM.Init,
{
    
    /**
     * Initialize map and launch all other init methods
     * Read map options from js_config.php->PM.mapOptions
     */    
    main: function() {
        // Map and themes
    	PM.Map.init();
        PM.OL.Theme.init();
        
        PM.Map.zoomToInitialExtent(); 
        //map.zoomToMaxExtent();
        
        // run all other init functions
        PM.OL.Control.init();
        this.panZoomBarHover();
        
        // set PHP session variables for map
        PM.Map.setSessionParams();
        
        // run timer event to keep session alive
        this.keepSessionAlive();
        
        // Check for context menu definition and add menus
        PM.UI.contextMenus();
        
    },
            
    
    /**
     * HOVER effect for slider area
     * initialized in pm_init()
     */
    panZoomBarHover: function() {
        $('#pmPanZoomBarContainer').hover(
            function(){ $(this).addClass("pm-panzoombar-over").removeClass("pm-panzoombar-out"); },
            function(){ $(this).addClass("pm-panzoombar-out").removeClass("pm-panzoombar-over"); }
        ).trigger('mouseout');
    },
    
    
    /**
     * Keep PHP session alive by updating session var 'session_alive'
     * Required to avoid session time out and subsequent rejected map creation
     */
    keepSessionAlive: function() {
    	$(document).everyTime(this.sessionTimer, function(i) {
    		//console.log(i);
    		PM.setSessionVar('session_alive', 1, false, null);
    	}, 0);
    }
    


});