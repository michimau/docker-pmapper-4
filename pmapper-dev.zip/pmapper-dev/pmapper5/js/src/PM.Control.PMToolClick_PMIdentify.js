OpenLayers.Control.PMIdentify = OpenLayers.Class(OpenLayers.Control.PMToolClick, {
    execute: function(mouseXY) {
        //console.log(mouseXY);
        //PM.Query.initialize('point', mouseXY);
        var query = new PM.Query('point', mouseXY);
    },

    CLASS_NAME: "OpenLayers.Control.PMIdentify"
});


