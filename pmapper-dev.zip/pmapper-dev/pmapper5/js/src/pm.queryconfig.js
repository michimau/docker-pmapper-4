
/*****************************************************************************
 *
 * Purpose: Configuration for queries
 * Author:  Armin Burger
 *
 *****************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/
	

$.extend(PM.QueryConfig, {
	   
    /** default options for query result dialog */
    resultDlgOptions: {width:500, height:250, resizeable:true, newsize:false, container:'pmQueryContainer', name:"query"},
    
    /** result format used for query */
    resultFormat: 'default',
    
    
    /** Pre-rendering of query results */    
    preRenderedQResult: false,
    
    /** Display iQuery result in default window*/
    iQueryResultDefaultDisplay: true,
    
    /** Limit search to current map extent */
    searchLimitToCurrentMapExtent: false,
    

    
    /**
     * Default template for query
     */
    queryTpl: 
    { 
        "table":
           {"queryHeader": "<div>",
            "queryFooter": "</div>",
            "layers": 
                {"#default":
                   {"layerHeader":"<div class=\"pm-info-layerheader\">_p(Layer): ${description}</div><table class=\"sortable\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\">",
                    "theaderTop": "<tr>",
                    "theader": "<th>@</th>",
                    "theaderBottom": "</tr>",
                    "tvaluesTop": "<tr>",
                    "tvalues":
                        {"shplink": "<td class=\"zoomlink\"><a href=\"javascript:PM.Map.zoom2extent('$[0]','$[1]','$[2]','$[3]')\"><img src=\"img/zoomto.gif\" alt=\"zoomto\"></a></td>",
                         "hyperlink": "<td><a href=\"javascript:PM.Custom.openHyperlink('$[0]','$[1]','$[2]')\">$[3]</a></td>",
                         "#default": "<td>$</td>"
                        },
                    "tvaluesBottom": "</tr>",
                    "layerFooter":"</table>"
                   }
                },
            "zoomall": 
                {"top": "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><tr>",
                 "center": "<td class=\"zoomlink\"><a href=\"javascript:PM.Map.zoom2extent(0,0,'${allextent}',1)\"><img src=\"img/zoomtoall.gif\"alt=\"za\"></a></td>",
                 "bottom": "<td class=\"TDAL\">_p(Zoom to Selected Features)</td></tr></table>"
                },

            "callbackfunction": null
                
           },
           
        "tree":
           {"queryHeader": "<div><ul>",
            "queryFooter": "</div></ul>",
            "layers": 
                {"#default":
                   {"layerHeader":"<li><span>${description}</span><ul>",
                    "theaderTop": false,
                    "theader": false,
                    "theaderBottom": false,
                    "tvaluesTop": '<li><span>$1</span><ul>',
                    "tvalues":
                        {"shplink": "<li><a href=\"javascript:PM.Map.zoom2extent('$[0]','$[1]','$[2]','$[3]')\"><img src=\"img/zoomtiny.gif\" alt=\"zoomto\"> _p(Zoom)</a></li>",
                         "hyperlink": "<li>@: <a href=\"javascript:PM.Custom.openHyperlink('$[0]','$[1]','$[2]')\">$[3]</a></li>",
                         "#default": "<li>@: $</li>"
                        },
                    "tvaluesBottom": '</ul></li>',
                    "layerFooter":"</ul></li>"
                   }
                },
            "zoomall": 
                {"top": "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><tr>",
                 "center": "<td class=\"zoomlink\"><a href=\"javascript:PM.Map.zoom2extent(0,0,'${allextent}',1)\"><img src=\"img/zoomtoall.gif\"alt=\"za\"></a></td>",
                 "bottom": "<td class=\"TDAL\">_p(Zoom to Selected Features)</td></tr></table>"
                },

            "callbackfunction": false
                
           },
           
        "iquery":
           {"queryHeader": "<div>",
            "queryFooter": "</div>",
            "layers": 
                {"#default":
                   {"layerHeader":"<table class=\"pm-iquery\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><th colspan=\"2\" class=\"pm-iquery-header\">${description}</th></tr>",
                    "theaderTop": false,
                    "theader": false,
                    "theaderBottom": false,
                    "tvaluesTop": false,
                    "tvalues":
                        {"shplink": false,
                         "hyperlink": "<tr><th>@</th><td>$[3]</td></tr>",
                         "#default": "<tr><th>@</th><td>$</td></tr>"
                        },
                    "tvaluesBottom": false,
                    "layerFooter":"</table>"
                   }
                },
            "nozoomparams": true
           }
    }
    
});
