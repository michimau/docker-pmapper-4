
/*****************************************************************************
 *
 * Purpose: Query class
 * Author:  Armin Burger
 *
 *****************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/


	
PM.Query = PM.Class( {
	
    iquery_timer: null,
    timeW: -1,
    timeA: 2,
    timer_c: 0,
    timer_t: null,
    timer_to: null,

    
    /** 
     * Pre-rendering of query results 
     * ==> To be checked if still needed....
     */    
    preRenderedQResult: false,   
    
    /** path to PHP query   */
    queryUrl: 'lib/query',
    
    /** Type of query params     */
    queryXYName: 'queryxy',
    
    pmQueryType: 'identify',
    
    
    /**
     * Start identify (query) or select (nquery) 
     * @param type
     * @param xy
     */
    initialize: function(type, xy) {
    	var msGroups = this.getActiveMsGroups();
        var queryParams = PM.Util.getMapParams(true);
        queryParams['mode'] = type;
        queryParams[this.queryXYName] = xy;
        queryParams['groups'] = msGroups.join(',');
        queryParams['format'] = PM.QueryConfig.resultFormat;
        
        if (type != 'point') {
            PM.Map.zoomselected = '1';
        }
        
        this.execute(this.queryUrl, queryParams);
    },

	/**
	 * Get query results and display them by parsing the JSON result string 
	 * @param queryUrl
	 * @param queryParams
	 */
    execute: function(queryUrl, queryParams) {
        var self = this; 
        $.ajax({
            type: "GET",
            url: queryUrl,
            data: queryParams,
            dataType: "json",
            context: this,
            success: function(response){
                //var queryResult = response; //.queryResult;
                this.showResult(response.queryResult);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (window.console) console.log('P.MAPPER AJAX error', errorThrown);
            }
        });
    },
    
    /**
     * Get the active MS groups of the map
     * @returns {Array} activeMsGroups
     */
    getActiveMsGroups: function(){
    	return PM.Map.getActiveMsGroups();
    },
    
    
    /**
     * Parse JSON result string with parseJSON()
     * and insert resulting HTML into queryresult DIV
     * run post-processing scripts
     * @param resultSet
     */
    showResult: function(resultSet) {
    	var self = this;
    	var resultLayout = PM.QueryConfig.resultLayout;
    	var queryResultContainer = infoWin;
        var infoWin = 'dynwin';
        
        //console.log(resultSet);
        if (infoWin == 'dynwin') {
            PM.Dlg.create(PM.QueryConfig.resultDlgOptions, _p('Result'), false);
            $('#pmQueryContainer_MSG').addClass('pm-info').addClass('jqmdQueryMSG');
            queryResultContainer = 'pmQueryContainer_MSG';
        } 
        if (!self.preRenderedQResult) {
            if (resultSet.length < 1) {
                $('#' + queryResultContainer).html(this.returnNoResultHtml());
            } else {
                // call main result parser
                var callbackfn = self.parseResult(resultSet, resultLayout, queryResultContainer);

                if (resultLayout == 'table') {
                    self.resultFormatTable();
                } else if (resultLayout == 'tree') {
                    $('#' + queryResultContainer).treeview(PM.QueryConfig.treeStyle);
                }
                
                eval(callbackfn);
            }
        } else {
            $('#' + queryResultContainer).html(resultSet);
        }
        
        // Add highlighting to map
        var hlTheme = map.getLayer("pmResultHighlight");
        if ($.inArray(self.pmQueryType, PM.ini.query.highlight) > -1) {
        	//hlTheme.clearGrid();
        	var rd = hlTheme.redraw();
        	hlTheme.setVisibility(true);
        } else {
        	//hlTheme.setVisibility(false);
        	//hlTheme.clearGrid();
        }
    },
    
    /**
     * Apply special table formatting
     * default is 'sortables'
     */
    resultFormatTable: function() {
    	sortables_init();
    },
    
    /**
     * Collect HTML string for result output
     */     
    html: {
        h: "",
        append: function(t) {
            if (t) {
                this.h += t;
            } else {
                this.h;
            }
        },
        
        text: function() {
            return this.h;
        },
        
        reset: function() {
            this.h = "";
        }
    },
    
    /**
     * Parse query result JSON string with selected template
     * add result to container and return callbackfunction
     * @param jsonRes
     * @param tplName
     * @param container
     * @returns
     */
    parseResult: function(jsonRes, tplName, container) {
        var self = this;
        var groupBounds;
        var queryLayers = jsonRes; //[0]; 
        //var zoomParams = jsonRes[1]; 
        var tpl = PM.QueryConfig.queryTpl[tplName];
        
        var h = this.html;
        h.reset();
        h.append(this.parseLocale(tpl.queryHeader));
        
        
        // Parse each layer from result set
        $.each(queryLayers, function(idx, val) {
            //console.log('layer', idx, val);
        	groupBounds = this.groupBounds;
        	var layTpl = tpl.layers['#default'];
            
            if (tpl.layers[this.name]) {
                $.extend(true, layTpl, tpl.layers[this.name]);
            }
            
            var rHeader = this.header;
            var customFields = [];
            var skipShpLink = false;
            var noShpLink = false;
            h.append(self.parseVal(layTpl.layerHeader, this));
            //console.log(this.header);
            
            
            h.append(layTpl.theaderTop);
            // Parse result header 
            $.each(this.stdheader, function(i) {
                if (this == '#') noShpLink = true;  // RASTER data
                var fld = this;
                $.each(layTpl.tvalues, function(k,v) {
                    if (k == fld) {
                        customFields[i] = k;
                    }
                    if (k == "shplink" && v == false) {
                        skipShpLink = true;
                    }
                });
            });
            
            $.each(rHeader, function(i) {
                if (!(skipShpLink && this == '@') && this != "#" && layTpl.theader) { 
                    h.append(layTpl.theader.replace(/\@/, this));
                } 
            });
            h.append(layTpl.theaderBottom);
            
            // Parse field values
            $.each(this.values, function() {
                h.append(self.parseValTop(layTpl.tvaluesTop, this));
                
                $.each(this, function(i) {
                    //alert(this);
                    if (customFields[i]) {
                        if (this.shplink) {
                            h.append(self.parseLink(layTpl.tvalues[customFields[i]], this.shplink).replace(/@/, rHeader[i]));
                        } else if (this.hyperlink) {
                            h.append(self.parseLink(layTpl.tvalues[customFields[i]], this.hyperlink).replace(/@/, rHeader[i]));
                        } else {
                            if (!(noShpLink && i == 0))
                                h.append(layTpl.tvalues[customFields[i]].replace(/\$/, this)
                                                                        .replace(/@/, rHeader[i])
                                );
                        }
                    } else if (this.shplink) {
                        if (layTpl.tvalues.shplink) {
                            h.append(self.parseLink(layTpl.tvalues.shplink, this.shplink).replace(/@/, rHeader[i]));
                        }
                    } else if (this.hyperlink) {
                       h.append(self.parseLink(layTpl.tvalues.hyperlink, this.hyperlink).replace(/@/, rHeader[i]));
                    } else {
                        if (!(noShpLink && i == 0)) 
                            h.append(layTpl.tvalues['#default'].replace(/\$/, this)
                                                               .replace(/@/, rHeader[i])
                            );
                    }
                });
                
                h.append(layTpl.tvaluesBottom);
            });
            

            h.append(self.parseVal(layTpl.layerFooter, this));
        });
        //console.log("groupBounds", groupBounds);
        h.append(tpl.queryFooter);
        if (!tpl.nozoomparams) h.append(this.returnZoomParamsHtml(groupBounds, tpl.zoomall));

        if (container) {
            $('#' + container).html(h.text());
            return tpl.callbackfunction;
        } else {
            return h.text();
        }
    },
    
    /**
     * Parse value of result header
     * parse _p(...) and ${...} 
     */
    parseVal: function(v, list) {        
        if (!v) return false;
        var v = this.parseLocale(v);
        var m = v.match(/\$\{(\w+)\}/g);
        if (m) {
            $.each(m, function() {
                var key = this.slice(2,-1);
                var rVal = list[key];
                var reg2 = new RegExp('\\$\\{' + key + '\\}', 'g');
                v = v.replace(reg2, rVal);
            });
            return v;
        } else {
            return v;
        }
    },
    
    /**
     * Parse shapelink and hyperlink fields 
     * search for _p() and $[]
     * @param t
     * @param linkList
     * @returns {String}
     */
    parseLink: function(t, linkList) {
        var t = this.parseLocale(t);
        var m = t.match(/\$\[\d\]/g);
        $.each(m, function(i) {
            var j = this.substr(2,1);
            var p = new RegExp('\\$\\[' + j + '\\]', 'g');

            t = t.replace(p, linkList[j]);
            mm = t.match(p);
        });
        return t;
    },
    
    /**
     * Replace $1..10 with value of result index 
     * @param vt
     * @param vlist
     * @returns {String}
     */
    parseValTop: function(vt, vlist) {        
        if (!vt) return false;
        var m = vt.match(/\$[0-9]/g);
        if (m) {
            
            //$.each(m, function(i) {
                //alert(m[i].substr(1,1));
                var val = vlist[m[0].substr(1,1)];
                //alert(val);
                if (typeof val == 'object') val = val.hyperlink[2];
            //});
        }
        
        return vt.replace(/\$[0-9]/, val);
    },
    
    /**
     * Search for locale string and return translated string
     * @param v
     * @returns {String}
     */
    parseLocale: function(v) {
        var p = v.match(/_p\([^\(]*\)/);
        if (p) {
            var locStr = _p(p[0].slice(3, -1));
            v = v.replace(/_p\([^\(]*\)/, locStr);
        }
        
        return v;
    },
    
    /**
     * Create the HTML/JS for 'zoomall' and 'autozoom' settings
     * @param allextent
     * @param tpl
     * @returns {String}
     */
    returnZoomParamsHtml: function(allextent, tpl) {
    	var self = this;
    	
    	var autoZoomList = $.isArray(PM.ini.query.autoZoom) ? PM.ini.query.autoZoom : [PM.ini.query.autoZoom];
        var zoomAllList = $.isArray(PM.ini.query.zoomAll) ? PM.ini.query.zoomAll : [PM.ini.query.zoomAll];
        var autozoom = PM.Util.inArray(self.pmQueryType, autoZoomList);
        var zoomall = PM.Util.inArray(self.pmQueryType, zoomAllList);
        
        if (allextent) PM.extentSelectedFeatures = allextent;
        
        var html = '';
        if (zoomall && tpl.zoomall != false) {
            $.each(tpl, function(k, v) {
                html += self.parseVal(v, {'allextent': allextent.join(",")})
            });
        }
        
        if (autozoom) {
        	PM.Map.zoom2extent(0, 0, allextent.join(","), 1);
        }
        
        var qrlLen = PM.Custom.queryResultAddList.length;
        for (var i=0; i<qrlLen ; i++) {
            html += eval(PM.Custom.queryResultAddList[i]);
        }

        return html;
    },


    /**
     * Return HTML for no results found in query
     * @param infoWin
     * @returns {String}
     */
    returnNoResultHtml: function(infoWin) {
        var h = '<table class="restable" cellspacing="0" cellpadding="0">';
        h += '<td>' + _p('No records found') + '</td>'; 
        h += '</tr></table>';
        return h;
    },
    
    
    CLASS_NAME: "PM.Query"
    
});


/**
 * Class for Select By Rect
 */
PM.QuerySelect = PM.Class(PM.Query, {
	
	pmQueryType: 'select',
	
	getActiveMsGroups: function(){
		//var selGroup = PM.UI.QuerySelectBox.selectedItem; 
		var selGroup = $('#pmQuerySelectBox option:selected').val();
    	return [selGroup];
    },
    
	CLASS_NAME: "PM.QuerySelect"
	    
});


/**
 * Class for Query/Select By Shape
 */
PM.QueryShape = PM.Class(PM.QuerySelect, {
	
	pmQueryType: 'select', 
	
	queryXYName: 'shpwkt',
    
	CLASS_NAME: "PM.QueryByShape"
	    
});


/**
 * Class for Search (query By Attribute)
 */
PM.QueryAttribute = PM.Class(PM.Query, {
    
	pmQueryType: 'search', 
	
	/**
	 * Initialize search (attribute query)
	 * @param type
	 * @param msGroups
	 * @param skvp
	 */
    initialize: function(type, msGroups, skvp) {
        var msGroups = this.getActiveMsGroups();
        var queryParams = PM.Util.getMapParams(true);
        if (! PM.QueryConfig.searchLimitToCurrentMapExtent) {
        	queryParams['mapext'] = map.getMaxExtent().toBBOX();
        }
        queryParams['mode'] = type;
        queryParams['groups'] = msGroups;
        queryParams['format'] = PM.QueryConfig.resultFormat;
        
        var queryParamsKvp = PM.Util.params2kvp(queryParams) + '&' + skvp;
        
        this.execute(this.queryUrl, queryParamsKvp);
    }
});


/**
 * Class for iQuery (Tool Tips)
 */
PM.QueryIQuery = PM.Class(PM.Query, {
	
	pmQueryType: 'iquery', 
	
	getActiveMsGroups: function(){
		//var selGroup = PM.UI.QuerySelectBox.selectedItem;
    	var selGroup = $('#pmQuerySelectBox option:selected').val();
    	return [selGroup];
    },
    
    
    /**
     * Display result in DIV and postion it correctly
     * @param 
     */
    showResult: function(queryResult) {
    	// Show in deafult query window if not defined differently
    	if (PM.QueryConfig.iQueryResultDefaultDisplay) {
    		PM.Query.prototype.showResult.apply(this, arguments);
    	} else {
    	
	    	//console.log(queryResult);
	    	var self = this;
			var iQL = $('#iqueryContainer');
			// alert(iQL.height());
			if (queryResult) {
				var IQueryResult = self.parseResult(queryResult, 'iquery', false);
			} else {
				return false;
			}
			var mapCont = $('#map');
	
			if (PM.autoIdentifyFollowMouse){
				// border limits
				var limitRG = mapCont.iwidth() - iQL.iwidth() - 4; // Right
				var limitLF = 0;                // Left
				var limitTP = 0;                // Top
				var limitDN = mapCont.iheight() - iQL.iheight() - 4;    // Down
				var moveX = PM.ZoomBox.moveX;
				var moveY = PM.ZoomBox.moveY;
	
				//gap between mouse pointer and iqueryLayer:
				var gap = 10;
	
				// right:
				if (moveX >= limitRG){
					iQL.left(moveX - iQL.iwidth() - gap + 'px');
				} else {
					iQL.left(moveX + gap +'px');
				}
	
				// down:
				if (moveY >= limitDN){
					iQL.top(moveY - iQL.iheight() - gap + 'px');
				} else {
					iQL.top(moveY + gap +'px');          
				}
	
				if (IQueryResult) {
					//iQL.css({height:0});
					iQL.html(IQueryResult).showv().show();
					if (this.timeW != -1) this.timer_to = setTimeout("hideIQL()",this.timeW);
				} else {
					iQL.html('').height(0).hidev().hide();
					clearTimeout(this.timer_t);
					clearTimeout(this.iquery_timer);
				}
				// no follow, display on fixed position
			} else {
				if (IQueryResult) {
					iQL.html(IQueryResult).show();
				} else {
					iQL.html('').hide();
				}
			}
    	}
    },
    
    
	CLASS_NAME: "PM.QueryIQuery"
	    
});
