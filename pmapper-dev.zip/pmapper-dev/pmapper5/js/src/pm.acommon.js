
/******************************************************************************
 *
 * Purpose: common JS util functions, setting defaults
 * Author:  Armin Burger
 *
 ******************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/

/**
 * Locales function to get locale string
 */
function _p(str) {
    if (PM.Locales.list[str]) {
        return PM.Locales.list[str];
    } else {
        return str;
    }
}



/**
 * Global PMap object; 
 * stores main status variables set via incphp/js_init.php
 */
var PM = {
	toolBar: false,
	controls: [],
	scale: null,
    useCustomCursor: true,
    scaleSelectList: null,
    useInternalCursors: false,
    suggestLaunchSearch: true,
    contextMenuList: false,
    overviewMapOptions: null,
    
    _p: function(str) {
        if (PM.Locales.list[str]) {
            return PM.Locales.list[str];
        } else {
            return str;
        }
    },
    
    Class: OpenLayers.Class,
    Custom: {
        queryResultAddList: []
    },
    Form: {},
    Init: {
    	sessionTimer: "1800s"
    },
    Layout: {},
    Locales: {list:[]},
    Map: {
    	mutualDisableList: null,
    },
    OL: {
        Control: {},
        Theme: {}
    },
    Plugin: {},
    Print: {},
    QueryConfig: {
    	resultLayout: 'table',
        treeStyle: {treeview: {collapsed: true, unique: true}},
        iqueryFollowMouse: false
    },
    Search: {},
    Toc: {
    	categoriesClosed: [],
    	treeviewStyle: {collapsed:true, persist:false},
    	treeviewDefaultGroupLegendOpen: true,
    	showMinMaxButtons: false,
        legendIconPath: "img/legend/"
    },
    UI: {},
    Util: {}
};




/**
 * Generic number functions
 */
Number.prototype.roundTo=function(precision){return parseFloat(parseFloat(this).toFixed(precision));}



/**
 * DOM generic functions
 */
function objL(obj) {	
    return parseInt(obj.style.left || obj.offsetLeft);
}

function objT(obj) {
    return parseInt(obj.style.top || obj.offsetTop);
}

function objW(obj) {
	return parseInt( obj.style.width || obj.clientWidth );
}

function objH(obj) {		
    return parseInt( obj.style.height || obj.clientHeight);    
}

function hideObj(obj) {
    obj.style.visibility = 'hidden';
}

function showObj(obj) {
    obj.style.visibility = 'visible';
}





