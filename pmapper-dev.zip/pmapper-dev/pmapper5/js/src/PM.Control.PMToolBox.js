/* Copyright (c) 2006-2008 MetaCarta, Inc., published under the Clear BSD
 * license.  See http://svn.openlayers.org/trunk/openlayers/license.txt for the
 * full text of the license. */

/**
 * @requires OpenLayers/Control.js
 * @requires OpenLayers/Handler/Box.js
 */

/**
 * Class: OpenLayers.Control.SelectBox
 * The SelectBox control enables selection of image footprints on map
 * the mouse.
 *
 * Inherits from:
 *  - <OpenLayers.Control>
 */
OpenLayers.Control.PMToolBox = OpenLayers.Class(OpenLayers.Control, {
    defaultHandlerOptions: {
        'single': true,
        'double': false,
        'stopSingle': false,
        'stopDouble': true
    },
    
    /**
     * Property: type
     * {OpenLayers.Control.TYPE}
     */
    type: OpenLayers.Control.TYPE_TOOL,

    /**
     * Property: out
     * {Boolean} Should the control be used for zooming out?
     */
    out: false, 

    /**
     * Property: alwaysZoom
     * {Boolean} Always zoom in/out, when box drawed 
     */
    alwaysZoom: false,
    
    
    /**
     * Method: draw
     */    
    draw: function(evt) {
        this.handler = new OpenLayers.Handler.Box( this,
                            {done: this.onDraw}, {keyMask: this.keyMask} );
    },

    /**
     * Method: selectBox
     * collects user selectbox extents and cerates WKT
     * then calls CID.Query.selectImgRecords passing the WKT
     *
     * Parameters:
     * position - {<OpenLayers.Bounds>} or {<OpenLayers.Pixel>}
     */
    onDraw: function (position) {
        var isClick;
    	if (position instanceof OpenLayers.Bounds) {
            var minXYmap = this.map.getLonLatFromPixel(
                        new OpenLayers.Pixel(position.left, position.bottom));
            var maxXYmap = this.map.getLonLatFromPixel(
                        new OpenLayers.Pixel(position.right, position.top));
            var mouseXY = minXYmap.lon + ',' + minXYmap.lat + ',' + maxXYmap.lon + ',' + maxXYmap.lat;
            isClick = false;
            
        } else { // it's a pixel
            var xyMap = this.map.getLonLatFromPixel(
                        new OpenLayers.Pixel(position.x, position.y));
            var mouseXY = xyMap.lon + ',' + xyMap.lat ;
            isClick = true;
        }

        this.execute(mouseXY, isClick);
    },
    
    execute: function(mouseXY, isClick) {
        console.log(mouseXY);
    },

    CLASS_NAME: "OpenLayers.Control.PMToolBox"
});