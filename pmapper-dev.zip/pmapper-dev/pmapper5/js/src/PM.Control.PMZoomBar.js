/* Copyright (c) 2006-2011 by OpenLayers Contributors (see authors.txt for 
 * full list of contributors). Published under the Clear BSD license.  
 * See http://svn.openlayers.org/trunk/openlayers/license.txt for the
 * full text of the license. */


/**
 * @requires OpenLayers/Control/PanZoom.js
 */

/**
 * Class: OpenLayers.Control.PMZoomBar
 * Modifications of default OL PanZoomBar for p.mapper for positioning
 *
 * Inherits from:
 *  - <OpenLayers.Control.PanZoom>
 */

//OpenLayers.Control.PanZoom.X = 40;
 
OpenLayers.Control.PMZoomBar = OpenLayers.Class(OpenLayers.Control.PanZoomBar, {

    initialize: function(options) {
        this.position = new OpenLayers.Pixel(OpenLayers.Control.PanZoom.X,
                                             OpenLayers.Control.PanZoom.Y);
        OpenLayers.Control.prototype.initialize.apply(this, arguments);
    },
    
    CLASS_NAME: "OpenLayers.Control.PanZoomBar"
});
