/*****************************************************************************
 *
 * Purpose: p.mapper type of XYZ layer
 * Author:  Armin Burger
 *
 *****************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/
 
/**
 * @requires OpenLayers/Layer/PMTile.js
 */


/**
 * Class: OpenLayers.Layer.PMTile
 * This layer defaults to Spherical Mercator.
 * 
 * Inherits from:
 *  - <OpenLayers.Layer.XYZ>
 */
OpenLayers.Layer.PMTile = OpenLayers.Class(OpenLayers.Layer.XYZ, {
    
    sphericalMercator: true,
    
    msGroups: null,
    
    msGroupsActive: null,
    
    tileCache: null,
    
    cacheExpiration: null,
    
    cacheMaxLevel: null,
    
    preventCaching: false,
    
    description: null,
    
    highlight: null,
    
    mapUrl: "lib/map/pmtile?",
    
    initialize: function(name, options) {
        //console.log('PMTile options', options);
        var newArguments = [];
        newArguments.push(name, null, options);
        OpenLayers.Layer.XYZ.prototype.initialize.apply(this, newArguments);
    },
    

    getURL: function (bounds) {
        var addParams = { groups: this.msGroupsActive,
                          imgformat: this.imgFormat,
                          tileCache: this.tileCache ,
                          cacheExpiration: this.cacheExpiration,
                          cacheMaxLevel: this.cacheMaxLevel
                        };
        var addParamsString = OpenLayers.Util.getParameterString(addParams);
        
        var url = this.mapUrl + PM.SID + '&mode=tile&x=${x}&y=${y}&z=${z}&' + addParamsString + this.getUrlParamsAdditional(); //'&groups=' + this.msGroups.join();
        if (this.highlight) url += '&highlight=' + this.highlight;
        var xyz = this.getXYZ(bounds);
        //console.log(OpenLayers.String.format(url, xyz));
        return OpenLayers.String.format(url, xyz);
    },
    
    
    getUrlParamsAdditional: function() {
        if (this.preventCaching == 'true') { 
            return this.getTimestampParams();
        } else {
            return "";
        }
    },
    
    
    getTimestampParams: function() {
        var now = parseInt(new Date().getTime() / 100);
        return '&timestamp=' + now;
    },
    
    
    clone: function(obj) {
        if (obj == null) {
            obj = new OpenLayers.Layer.PMTile(
                this.name, this.url, this.getOptions());
        }
        obj = OpenLayers.Layer.XYZ.prototype.clone.apply(this, [obj]);
        return obj;
    },
    
    setMsGroups: function(groups) {
        this.msGroups = groups;
    },
    
    wrapDateLine: true,
    CLASS_NAME: "OpenLayers.Layer.PMTile"
});