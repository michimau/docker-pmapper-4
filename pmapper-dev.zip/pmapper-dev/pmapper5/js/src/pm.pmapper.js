
/******************************************************************************
 *
 * Purpose: generic p.mapper functions (init, open popup dialogs) 
 * Author:  Armin Burger
 *
 ******************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/

$.extend(PM,
{
    /**
     * Change the color of a button on<->off
     */
    changeButtonClr: function(myObj, myAction) {
        switch (myAction) {
            case 'over':
                myObj.className = 'pm-button-on';
                break;
                
            case 'out':
                myObj.className = 'pm-button-off';
                break;
        }
    },

    /**
     * return root path of application
     */
    getRootPath: function() {
        var theLoc = document.location.href;
        var theLastPos = theLoc.lastIndexOf('/');
        var RootPath = theLoc.substr(0,theLastPos) + '/';
        
        return RootPath;
    },


    /**
     * Round to a specified decimal
     */
    roundN: function(numin, rf) {
        return ( Math.round(numin * Math.pow(10, rf)) / Math.pow(10, rf) );
    },
    
    /**
     * Show Ajax indicator, 
     * if x/y coordinates provided displayed at mouse click x/y 
     */
    ajaxIndicatorShow: function(x, y) {
        if (x) {
            $('#pmIndicatorContainer').css({top: parseInt(y) + 'px', left: parseInt(x) + 'px'}).show();
        } else {
            $('#pmIndicatorContainer').css({top:'5px', right:'5px'}).show();
        }
    },

    /**
     * Hide Ajax indicator, 
     */
    ajaxIndicatorHide: function() {
        $('#pmIndicatorContainer').hide();
    },
    
    /**
     * Get the session variable as JSON string
     */
    getSessionVar: function(sessionvar, callfunction) {
        $.ajax({
            url: PM_XAJAX_LOCATION + '/x_getsessionvar.php?' + PM.SID + '&sessionvar=' + sessionvar,
            dataType: "json",
            success: function(response){
                eval(callfunction);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (window.console) console.log(errorThrown);
            } 
        });  
    },
    
    /**
     * Set the session variable via JSON string
     */
    setSessionVar: function(sessionvar, val, complex, callfunction) {
        var requrl = PM_XAJAX_LOCATION + '/x_setsessionvar.php?' + PM.SID + '&sessionvar=' + sessionvar + '&val=' + val;
        if (complex) requrl += '&complex=true';
    	$.ajax({
            url: requrl,
            type: "POST",
            dataType: "json",
            success: function(response){
            	//console.log('setsessionvar', response);
                eval(callfunction);
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (window.console) console.log(errorThrown);
            } 
        });  
    },
    
    
    /**
     * DIALOGS
     */
    Dlg: {
        
        /** Define if dialog should be transparent on move/resize*/
        transparentOnMoveResize: true,
        /** Opacity if enabled for dialog move/resize */
        moveResizeOpacity: 0.9,
        /** default options for help dialog */
        helpDlgOptions: {width:350, height:500, left:100, top:50, resizeable:true, newsize:true, container:'pmDlgContainer', name:"help"},
        /** default options for download dialog */
        downloadDlgOptions: {width:270, height:250, left:200, top:200, resizeable:false, newsize:true, container:'pmDlgContainer', name:"download"},
        /** default options for print dialog */
        printDlgOptions: {width:350, height:290, left:200, top:200, resizeable:true, newsize:true, container:'pmDlgContainer', name:"print"},
        /** Enable dialog roll up by double click on window bar or using mousewheel*/
        enableRollup: true,
        /** Dlg properties used for rollup */
        dlgProperties: {},
        
            
        /**
         * Create dialog - compatibility function with older plugins
         * @param options
         * @param title
         * @param url
         * @returns dialog
         */
        createDnRDlg: function(options, title, url) {
            return PM.Dlg.create(options, title, url);
        },
            
        /**
         * Create jqDnR Dialog (jquery.jqmodal_full.js)
         * @param options
         * @param title
         * @param url
         * @returns containerMsg
         */
        create: function(options, title, url) {
            var setOldSize = false;
            if (this.dlgProperties[options.name]) {
                if (this.dlgProperties[options.name].up) {
                    setOldSize = true;
                    this.dlgProperties[options.name].up = false;
                }
            } 
            
            var container = options.container;
            var containerMsg = $('#' + container + '_MSG');
            var dlg = '<div style="height: 100%">';
            dlg += '<div id="' + container + '_TC" class="jqmdTC dragHandle">' + _p(title) + '</div>';
            dlg += '<div id="' + container + '_MSG" class="jqmdMSG"></div>';
            dlg += '<div id="' + container + '_BC" class="jqmdBC" ';
            if (options.resizeable) {
                dlg += '><img src="css/dialog/resize.gif" alt="resize" class="resizeHandle" />';
            } else {
                dlg += 'style="height:0px; border:none">';
            }
            dlg += '</div>';
            dlg += '<input type="image" src="css/dialog/close.gif" onclick="$(this).parent().parent().hide(); $(\'#' + container + '_MSG\').html(\'\')" class="jqmdClose jqmClose" />';
            dlg += '</div>';

            var dynwin = $('#' + container);
            // Modified by Thomas RAFFIN (SIRAP)
            // dialog containers auto insertion
            // --> auto create dynwin if doesn't exist 
            // --> put in front of the others (auto calculate z-index)
            if (dynwin.length == 0) {
            	$('<div>').attr('id', container).addClass('jqmDialog').appendTo('body').hide();
            	dynwin = $('#' + container);
            }
        	var maxzindex = 99;
        	$('.jqmDialog').each(function() {
        		if ( ($(this).css('display') != 'none') && ($(this).attr('id') != container) ) {
        			var zindex = parseInt($(this).css('z-index'));
        			if (maxzindex <= zindex) {
        				maxzindex = zindex+1;
        			}
        		}
        	});
        	dynwin.css('z-index', '' + maxzindex); 
            
            var newsize = dynwin.is(':empty') || options.newsize;
            dynwin.html(dlg)
                .jqm({autofire: false, overlay: 0})
                .jqDrag('div.dragHandle');
            if (this.enableRollup) dynwin.find('div.dragHandle').bind("dblclick", function(){PM.Dlg.dlgWinRollup(options.name, $(this))}).mousewheel(function(e){ PM.Dlg.dlgWinRollup(options.name, $(this))});;
            
            if (newsize) dynwin.height(options.height).width(options.width);
            if (options.left) dynwin.css({left:options.left, top:options.top});
            if (setOldSize) dynwin.height(this.dlgProperties[options.name].height);
            if (options.resizeable) dynwin.jqResize('img.resizeHandle');
            //if (url) containerMsg.load(url);
            if (url) $('#' + container + '_MSG').load(url);

            dynwin.show();
            this.adaptDWin(dynwin);
            
            return containerMsg;
        },

        adaptDWin: function(container) {
            var cn = container.attr('id');
            var newMSGh = parseInt($('#' + cn).css('height')) - parseInt($('#' + cn +'_TC').outerHeight()) - parseInt($('#' + cn + '_BC').outerHeight()) ; 
            $('#' + cn + '_MSG').css({height: newMSGh});
        },
        
        /**
         * Roll up dialog and hide the contents, only window bar remains visible
         * @param dlgName
         * @param dlgHandle
         */
        dlgWinRollup: function(dlgName, dlgHandle) {
            var dlgContainer = dlgHandle.parent().parent(); 
            if (dlgContainer.height() > dlgHandle.height()) {
                this.dlgProperties[dlgName] = {height:dlgContainer.height(), width:dlgContainer.width()};
                this.dlgProperties[dlgName].up = true;
                dlgContainer.height(dlgHandle.height());
            } else {
                dlgContainer.height(this.dlgProperties[dlgName].height);
                this.dlgProperties[dlgName].up = false;
            }
            
            dlgContainer.find('.jqmdMSG, .jqmdBC').each(function() {
                $(this).toggle();
            });
        },
        
        /**
         * Open help dialog 
         */
        openHelp: function() {
            this.create(this.helpDlgOptions, _p('Help'), 'help.phtml?'+PM.SID);
        },

        /**
         * DOWNLOAD dialog
         * get image with higher resolution for paste in othet programs
         */
        openDownload: function() {
            this.create(this.downloadDlgOptions, _p('Download'), 'downloaddlg.phtml?'+PM.SID );
        },

        /**
         * Open popup dialaog for adding POI 
         */
        openPoi: function(imgxy) {
            var coordsList = imgxy.split('+');
            var mpoint = PM.ZoomBox.getGeoCoords(coordsList[0], coordsList[1], false);
            
            // Round values (function 'roundN()' in 'measure.js')
            var rfactor = 5;
            var px = isNaN(mpoint.x) ? '' : PM.roundN(mpoint.x, rfactor);
            var py = isNaN(mpoint.y) ? '' : PM.roundN(mpoint.y, rfactor);
            
            var inserttxt = prompt(_p('Add location description'), '');
            if (inserttxt) {
                var digitizeurl = PM_XAJAX_LOCATION + 'x_poi.php?' +PM.SID + '&up=' + px + '@@' + py + '@@' + inserttxt; //escape(inserttxt);
                //alert(digitizeurl);
                PM.Map.addPOI(digitizeurl);
            }
        },

        //
        // PRINT functions
        // 
        /**
         * Open the printing dialog
         */
        openPrint: function() {
           this.create(this.printDlgOptions, _p('Print Settings'), 'printdlg.phtml?'+PM.SID);
        },

        /**
         * Show advanced settings in print dialog
         */
        printShowAdvanced: function() {
            $('#pmDlgContainer div.pm-printdlg-advanced').show();
            $('#pmPrintdlgButtonAdvanced').hide();
            $('#pmPrintdlgButtonNormal').show();
			var height = ($.browser.msie && (parseInt($.browser.version) <= 7.0)) ? $('#pmPrintdlg').height() : $('#pmPrintdlg').innerHeight();
			$('#pmDlgContainer').height(parseInt(height) + 60);
            this.adaptDWin($('#pmDlgContainer'));
        },

        /**
         * Show advanced settings in print dialog
         */
        printHideAdvanced: function() {
            $('#pmDlgContainer div.pm-printdlg-advanced').hide();
            $('#pmPrintdlgButtonNormal').hide();
            $('#pmPrintdlgButtonAdvanced').show();
			var height = ($.browser.msie && (parseInt($.browser.version) <= 7.0)) ? $('#pmPrintdlg').height() : $('#pmPrintdlg').innerHeight();
			$('#pmDlgContainer').height(parseInt(height) + 60);
            this.adaptDWin($('#pmDlgContainer'));
        }
    },
    
    
    Print: {
    	submitPrintDlg: function() {
    		
    		
    	}
    	
    }

});


