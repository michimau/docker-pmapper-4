/**
 * Class for select function (queryByRect)
 */

OpenLayers.Control.PMSelect = OpenLayers.Class(OpenLayers.Control.PMToolBox, {
    
    execute: function(mouseXY, isClick) {
        //console.log(mouseXY);
        var mode = isClick ? "point" : "rect";
        var query = new PM.QuerySelect(mode, mouseXY);
    },
    
    activate: function() {
        //console.log("activated");
        PM.UI.QuerySelectBox.show();
        return OpenLayers.Control.prototype.activate.apply(this, arguments);
    },
    
    deactivate: function() {                                                    
    	//console.log("DE-activated");
    	PM.UI.QuerySelectBox.hide();
    	return OpenLayers.Control.prototype.deactivate.apply(this, arguments);
    },
    

    CLASS_NAME: "OpenLayers.Control.PMSelect"
});