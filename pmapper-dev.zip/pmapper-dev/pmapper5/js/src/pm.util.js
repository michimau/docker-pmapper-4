
/*****************************************************************************
 *
 * Purpose: Utility functions 
 * Author:  Armin Burger
 *
 *****************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/

$.extend(PM.Util,
{
    
	/**
	 * Get parameters for various map requests
	 * @param sid , define if PHP session id shall be included
	 * @returns {Array}
	 */
	getMapParams: function(sid) {
    	var params = {};
    	var mapSize = map.getSize();
        params['mapext'] = map.getExtent().toBBOX();
        params['scale'] = parseInt(map.getScale());
        params['mapwidth'] = mapSize.w;
        params['mapheight'] =  mapSize.h;
        params['crs'] = map.getProjection();
        if (sid) {
        	params[PM.sessionName] = PM.sessionId;
        }
    	
        return params;
    },
    
    /**
     * Convert object (dictionary) to KVP string
     * @param params
     * @returns {String}
     */
    params2kvp: function(params) {
    	var kvp = "";
    	$.each(params, function(k, v) {
    		kvp += "&" + k + "=" + v;
    	});
    	return kvp;
    },
    
    getUrlParameter: function(name) {
        return decodeURIComponent((RegExp('[?|&]' + name + '=' + '(.+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20')) || null;
    },
    
    getUrlParameters: function() {
    	var qs = document.location.search.split("+").join(" ");
		var params = {},
		    tokens,
		    re = /[?&]?([^=]+)=([^&]*)/g;
		
		while (tokens = re.exec(qs)) {
		    params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
		}
		
		return params;
    },
    
    inArray: function(element, array) {
    	var ret = $.inArray(element, array) > -1 ? true : false;
    	return ret;
    }

    

});