/** 
 * Static class for managing the OL controls
 * 
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * 
 * @package OL
 * @static 
 */


$.extend(PM.OL.Control,
{
    
    /**
     * Initialize all types of controls and add them to map
     */
    init: function() {
        
    	// Add Toolbar panel
        this.addPanel(PM.toolBar);
        
        // Init controls
        this.addAllControls();
        
        // Init ov map
        if (PM.overviewMapOptions) {
        	this.addOverviewMap();
        }
    },
        
    
    /**
     * Create all controls defined in js_config.php -> PM.controls and add them to the map
     */
    addAllControls: function() {
        $.each(PM.controls, function() {
            var ctrlParams = this.params;
            if (this.params && this.params.div) {
                ctrlParams.div = OpenLayers.Util.getElement(this.params.div);
            }
            var newControl = new OpenLayers.Control[this.type](ctrlParams);
            //console.log(newControl.id, newControl.div);
            map.addControl(newControl);
        });
    },
    
    
    /**
     * Creates a panel (toolBar) with all tools and add panel to the map
     * @param config {Object} configuration parameters passed during creation; usually defined in js_config.php->PM.toolBar
     */    
    addPanel: function(config) {
        if (!config || config.tools.length < 1) {
        	return false;
        }
    	var activeTool = null;
        var controlList = [];
        for (var i=0; i<config.tools.length; i++) {
            var tool = config.tools[i];
            if (tool.type == 'NavigationHistory') {
                var navHist = this.createHistoryControl(PM._p(tool.params.title));
                controlList.push(navHist.previous);
                controlList.push(navHist.next);
            } else {
                tool.params.title = PM._p(tool.params.title);
                var newControl = new OpenLayers.Control[tool.type](tool.params);
                if (tool.params.activated && tool.params.activated == true) {
                    var activeTool = newControl;
                }
                controlList.push(newControl);
            }
        }
        
        var panel = new OpenLayers.Control.PMPanel({defaultControl: activeTool});
        panel.addControls(controlList);
        panel.activateControl(activeTool);
        map.addControl(panel);
    },
    
    
    
    /**
     * Create control for navigation history (zoom previuos/next extent)
     * @returns {{OpenLayers.Control.NavigationHistory.next}, {OpenLayers.Control.NavigationHistory.previous} } 
     */
    createHistoryControl: function(titles) {
        var navHistory = new OpenLayers.Control.NavigationHistory();
        map.addControl(navHistory);  // must be added to map before adding next/previous controls
        var navPrevious = navHistory.previous;
        OpenLayers.Util.extend(navPrevious, {
            title: PM._p(titles[0])
        });
        var navNext = navHistory.next;
        OpenLayers.Util.extend(navNext, {
            title: PM._p(titles[1])
        });
        
        return {'next':navNext, 'previous':navPrevious};
    },
    
    
    
    /**
     * Create and add the overview map to main map
     */
    addOverviewMap: function() {
        var options = {};
        
        $.each(PM.overviewMapOptions, function(key, val) {
            if (key == 'size') {
                options[key] = new OpenLayers.Size(val[0], val[1]);
            } else if (key == 'div') {
                options[key] = OpenLayers.Util.getElement(val);
            } else if (key == 'olThemes') {
                var ovLayers = [];
                for (var i=0; i<val.length; i++) {
                	var olThm = PM.OL.Theme.olThemes[val[i][0]];
                	var msGroups =  val[i][1];
                	olThm.options.msGroups = msGroups;
                	olThm.options.msGroupsActive = msGroups;
                	//olThm.options.minScale = 1000000000;
                	
                	var ovTheme = PM.OL.Theme.make(olThm);
                	ovTheme.setIsBaseLayer(true);
                	//console.log('ovlay', ovTheme);
                	ovLayers.push(ovTheme);
                }
                options['layers'] = ovLayers;
            } else {
                options[key] = val;
            }
            
        });
        //console.log("OvMap options", options);
          
        //var olOverviewLayer = this.createOverviewLayer(PM.overviewMapOptions.olTheme);
        //options.layers = [olOverviewLayer];
        
        var overview = new OpenLayers.Control.OverviewMap(options);
        //console.log("ovoptions", options); 
        map.addControl(overview);
    }
    
    
    
    
    
    


});