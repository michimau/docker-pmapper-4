/******************************************************************************
 *
 * Purpose: Functions for UI elements
 * Author:  Armin Burger
 *
 ******************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/



/**
 * UI elements
 * Configuration via js_config.php 
 */
;(function($){ 
    $.fn.extend({  
        
        /**
         * PM-jQuery function for creating Tool links
         * @param tl
         */
        pmToolLinks: function(tl) {
            var container = $(this);     
            var ul = $('<ul/>').addClass('pm-tool-links');
            $.each(tl.links, function() {
                var linkName = _p(this.name); //;
                var target = this.target ? 'onclick="this.target = \'' + this.target + '\';"' : '';
                var a = '<a href="' + (this.run.substr(0,4) == 'http' ? this.run : 'javascript:' + this.run + '()') + '"' + target + '>';
                a += '<img style="background:transparent url(img/menus/' + this.imgsrc + ')' + ' no-repeat;height:16px;width:16px" src="img/transparent.png" alt="' + linkName +'" />';
                a += '<span>' + linkName + '</span></a>';
                $('<li/>').html(a).appendTo(ul);
            });
            
            $("<div />").attr('id', tl.containerid).append(ul).appendTo(container);  
        },
        
        /**
         * PM-jQuery function for creating Tool buttons
         * @param tb
         */ 
        pmTabs: function(tb) {
            var container = $(this);
            var options = tb.options;
            var ul = $('<ul/>').addClass(options.mainClass);
            var tabW = parseInt(100 / tb.tabs.length) -1 ;
            $.each(tb.tabs, function() {
                var tabName = _p(this.name); 
                var run = this.run; 
                var tab = $('<div>').html(tabName);
                if (this.active) tab.addClass('pm-tabs-selected');
                tab.bind('click', function() {  
                        tab.parent().parent().find('>li>div').each(function() {$(this).removeClass('pm-tabs-selected');});
                        tab.addClass('pm-tabs-selected');
                        eval(run + '()');
                });
                $('<li>').css({width:tabW+'%'}).append(tab).appendTo(ul);
            });
            ul.appendTo(container);
        },
        
        /**
         * PM-jQuery function for cerating search container
         * @param options
         */
        pmSearchContainer: function(options) {
        	var container = $(this);
            
            var scDiv = $("<div>").attr('id', 'pmSearchContainer');
            var scForm = $("<form>").attr({'id':'pmSearchForm'})
            						.submit(function(evt) {
            							evt.preventDefault();  // prevent page reload when ENTER pressed
            							PM.Search.submitSearch();
            						 })
            						.appendTo(scDiv);

            var sOptions = $("<td>").attr('id', 'pmSearchOptions')
            		 		        .addClass('pm-search-options');
            var sItems = $("<td>").attr('id', 'pmSearchItems')
		        				  .addClass('pm-search-' + options.style);
            $("<table>").addClass('pm-toolframe')
            			.append($("<tr>").append(sOptions).append(sItems))
                        .appendTo(scForm);
            scDiv.appendTo(container);
            
            PM.Search.setSearchOptions();
        },
        
        
        
        /**
         * Append a new element to another
         * @param el
         * @returns {object}
         */
        pmAppendElement: function(el, attributes) {
            var dom = $('<'+el+'/>');
            if (attributes) {
            	dom.attr(attributes);
            }
            $(this).append(dom); 
            return dom;
        },
        
        /**
         * Show Indicator
         * @param ind
         */
        pmShowIndicator: function(ind) {
            var container = $(this);   
            var defaults = {
                    imgSrc:'img/indicator.gif',
                    css:{position:'absolute', top:'0px', left:'0px'}
            };
            var options = $.extend(defaults, ind.options);
            //console.log(ind.options);
            
            var img = $('<img>').src(options.imgSrc);
            $('<div>').addClass('pm-indicator').css(options.css).append(img).appendTo(container);
        },
        
        /**
         * Hide indicator
         * @param ind
         */
        pmHideIndicator: function(ind) {
            var container = $(this);  
            var defaults = {
                    fadeOutSpeed: 500
            };
            var options = $.extend(defaults, ind.options);
            container.find('div.pm-indicator').each(function (i) {
                $(this).fadeOut(options.fadeOutSpeed, function () {
                    $(this).remove();
                });
            });
        }
            
    });
    
})(jQuery); 


$.extend(PM.UI,
{
    /**
     * Show div with link to current map
     */
    MapLink: {
    	/**
    	 * Show map link
    	 */
    	show: function() {
    		
    		var me = map.getExtent().toBBOX();
            //var urlPntStr = response.urlPntStr;
            var dg = PM.Map.getActiveGroups();
            var confpar = PM.config.length > 0 ? '&config=' + PM.config : '';
            var urlPntStrPar = ''; //urlPntStr.length > 1 ? '&up=' + urlPntStr.replace(/\%5C\%27/g, '%27') : '';
            var loc = window.location;
            var reqList = loc.search.substr(1).split('&');
            var defReqStr = "";
            $.each(reqList, function(index, value) {
                if (value.search(/(dg|me|language|config|up)=/) < 0) {
                    defReqStr += '&' + value;
                }
            });
            console.log(defReqStr);
            var port = loc.port > 0 ? ':' + loc.port : '';
            var linkhref = loc.protocol + '/' + '/' + loc.hostname + port + loc.pathname + '?dg=' + dg + '&me=' + me + '&language=' + PM.gLanguage + confpar + urlPntStrPar + defReqStr; 
            $('<div>').attr('id', 'pmMapLink')
                      .addClass('pm-map-link')
                      //.append($('<div>').text(_p('Press [CTRL-C] to copy link')))
                      .append($('<div>').text(_p('Link to current map')))
                      .append($('<input type="text" class="pm-map-link-url" />').val(linkhref).click(function() {$(this).select();})) 
                      .append($('<img src="img/close.gif" alt="close" />').click(function () {$(this).parent().remove();}))
                      .append($('<br /><a href="' + linkhref + '">' + _p('Load link in current window') + '</a>').click(function() {$(this).parent().remove();}))
                      .appendTo('.ui-layout-center')
                      //.find('input').each(function() {this.select()})
                      .show();
	    }
    },

    /**
     * Create the measure input elements
     */
    MeasureBox: {
	    
    	/**
    	 * Show (display) measure box
    	 * @param className
    	 */
    	show: function(className) {
	    	PM.UI.HelpMessage.show(PM._p('digitize_help'));
	        var ctrl = map.getControlsByClass(className)[0];
	        var measureType = ctrl.measureType;
	        
	        var md = $('<div>').attr('id', 'pmMeasureContainer')
	                           .addClass("pm-measure")
	                           .appendTo('#map');
	        $('<div>').html(PM._p(measureType))
	                  .addClass("pm-measure-label")
	                  .appendTo(md);
	        //$('<div>').attr('id', 'pmMeasureTotal').addClass("pm-measure-value").html('').width(150).appendTo(md);
	        $("<input>").attr({ type:'text', id:'pmMeasureTotal'})
	                    .addClass("pm-measure-value")
	                    .appendTo(md);
	        if (measureType != "Area") {
	            $('<div>').html(PM._p('Segment'))
	                      .addClass("pm-measure-label")
	                      .appendTo(md);
	            //$('<div>').attr('id', 'pmMeasureSegment').html('').addClass("pm-measure-value").appendTo(md);
	            $("<input>").attr({ type:'text', id:'pmMeasureSegment'})
	                        .addClass("pm-measure-value")
	                        .appendTo(md);
	        }
	        $("<input>").attr({ type:'button', id:'pmMeasureClear'})
	                    .val(PM._p('Clear'))
	                    .addClass("pm-measure-value")
	                    .width('auto')
	                    .bind('click', function() {ctrl.cancel()})
	                    .appendTo(md);
	        md.show();
	    },
	    
	    /**
	     * hide measure box
	     */
	    hide: function() {
	        $('#pmMeasureContainer').remove();
	        PM.UI.HelpMessage.hide();
	    },
	    
	    clear: function() {
	        $('#pmMeasureSegment, #pmMeasureTotal').empty();
	    }
    },
    
    /**
     * Help message displayed ober map
     */
    HelpMessage: {
	    /**
	     * Show help box with message
	     * @param msg
	     */
    	show: function(msg) {
	        var msgContainer = $('#pmHelpMessage');
	        if (msgContainer.length == 0) {
	            $('<div>').attr('id', 'pmHelpMessage').appendTo('#map');
	            msgContainer = $('#pmHelpMessage');
	        }
	        msgContainer.html(msg).show();
	    },
	    
	    /**
	     * Hide help box
	     */
	    hide: function() {
	        $('#pmHelpMessage').hide();
	    }
    },
    
    /**
     * Select box for query-select and iquery
     */
    QuerySelectBox: {
    	/**     	 */
    	selectedItem: null,
    	
    	/**
    	 * Show select box for query functions
    	 */
	    show: function() {
	    	var self = this;
	    	var selBox = $("<select>").attr({'id':'pmQuerySelectOptions'})
	    							  .change(function(){
				    						self.selectedItem = $(this).val();
				    				  });
	    	var msGroups = PM.Map.getActiveMsGroups();
	    	$.each(msGroups, function(idx, val) {
	    		var msGrp = PM.grouplist[val];
	    		if (msGrp.isQueryable) {
	    			var opt = $("<option>").attr('value', val)
	    						 		   .html(msGrp.description)
	    						 		   .attr("selected", val == self.selectedItem ? true : false)
	    						           .appendTo(selBox);
	    		}
	    		if (!self.selectedItem && idx == 0) self.selectedItem = val;
	    	});
	    	
	    	$('<div>').attr('id', 'pmQuerySelectBox')
	    	          .addClass('pm-query-selectbox')
	    	          .html(PM._p('Apply on Layer'))
	    	          .append(selBox)
	    	          .appendTo($('#map'))
	    	          .show();
	    	//console.log('sel', self.selectedItem);
	    },
	    
	    /**
	     * hide select box
	     */
	    hide: function() {
	    	 $('#pmQuerySelectBox').remove();
	    },
	    
	    redraw: function() {
	    	this.hide();
	    	this.show();
	    }
    },
    
    
    /**
     * Initialize all context menus reading config from "PM.contextMenuList"
     */
    contextMenus: function() {
        if (PM.contextMenuList) {
            $.each(PM.contextMenuList, function() {
                var cmdiv = '<div style="display:none" class="contextMenu" id="' + this.menuid + '">';
                var cmbindings = {};
                
                cmdiv += '<ul>';
                $.each(this.menulist, function() {
                    cmdiv += '<li id="' + this.id + '">';
                    if (this.imgsrc) cmdiv += '<img src="img/menus/' + this.imgsrc + '" />';
                    cmdiv += _p(this.text) + '</li>';
                    
                    var run = this.run;
                    cmbindings[this.id] = function(t) {eval(run + '("' + t.id + '")');};
                });
                
                $('body').append(cmdiv);
                $(this.bindto).contextMenu(this.menuid, {
                    bindings: cmbindings, 
                    menuStyle: this.styles.menuStyle,
                    itemStyle: this.styles.itemStyle,
                    itemHoverStyle: this.styles.itemHoverStyle
                });
            });
        }
    }
    
});




