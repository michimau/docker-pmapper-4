/**
 * @requires OpenLayers/Control.js
 */

/**
 * Class: OpenLayers.Control.PMClearMap 
 * Refresh map and clear highlights
 * 
 * Inherits from:
 *  - <OpenLayers.Control>
 */
OpenLayers.Control.PMZoomToSelected = OpenLayers.Class(OpenLayers.Control, {

    /**
     * Property: type
     * {String} The type of <OpenLayers.Control> -- When added to a 
     *     <Control.Panel>, 'type' is used by the panel to determine how to 
     *     handle our events.
     */
    type: OpenLayers.Control.TYPE_BUTTON,
    
    /*
     * Method: trigger
     * Do the zoom.
     */
    trigger: function() {
        if (this.map) {
        	PM.Map.zoomToSelected();
        }    
    },

    CLASS_NAME: "OpenLayers.Control.PMZoomToSelected"
});