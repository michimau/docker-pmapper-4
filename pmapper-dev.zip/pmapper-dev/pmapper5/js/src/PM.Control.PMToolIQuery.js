/* Copyright (c) 2006-2011 by OpenLayers Contributors (see authors.txt for 
 * full list of contributors). Published under the Clear BSD license.  
 * See http://svn.openlayers.org/trunk/openlayers/license.txt for the
 * full text of the license. */


/**
 * @requires OpenLayers/Control.js
 * @requires OpenLayers/Handler/Hover.js
 */

/**
 *
 */
OpenLayers.Control.PMIQuery = OpenLayers.Class(OpenLayers.Control, {
    
    
    delay: 600,
    
    /**
     * Property: handler
     * {Object} Reference to the <OpenLayers.Handler> for this control
     */
    handler: null,
    
    /**
     * Property: hoverRequest
     * {<OpenLayers.Request>} contains the currently running hover request
     *     (if any).
     */
    hoverRequest: null,
    


    /**
     * Constructor: <OpenLayers.Control.WMSGetFeatureInfo>
     *
     * Parameters:
     * options - {Object} 
     */
    initialize: function(options) {
        options = options || {};

        OpenLayers.Control.prototype.initialize.apply(this, [options]);

        this.handler = new OpenLayers.Handler.Hover(
            this, 
            {'move': this.cancelHover, 'pause': this.execute },
            {'delay': this.delay}
        );
    },

    /**
     * Method: activate
     * Activates the control.
     * 
     * Returns:
     * {Boolean} The control was effectively activated.
     */
    activate: function () {
    	PM.UI.QuerySelectBox.show();
    	if (!this.active) {
            this.handler.activate();
        }
        return OpenLayers.Control.prototype.activate.apply(
            this, arguments
        );
    },

    /**
     * Method: deactivate
     * Deactivates the control.
     * 
     * Returns:
     * {Boolean} The control was effectively deactivated.
     */
    deactivate: function () {
    	PM.UI.QuerySelectBox.hide();
    	return OpenLayers.Control.prototype.deactivate.apply(
            this, arguments
        );
    },
    
   
    /**
     * Method: getInfoForHover
     * Pause callback for the hover handler
     *
     * Parameters:
     * evt - {Object}
     */
    execute: function(evt) {
        var xyMap = map.getLonLatFromViewPortPx(evt.xy);
        var mouseXY = xyMap.lon + ',' + xyMap.lat ;
        //console.log(mouseXY);
        var query = new PM.QueryIQuery('point', mouseXY);

    },

    /**
     * Method: cancelHover
     * Cancel callback for the hover handler
     */
    cancelHover: function() {
        if (this.hoverRequest) {
            this.hoverRequest.abort();
            this.hoverRequest = null;
        }
    },




    CLASS_NAME: "OpenLayers.Control.PMIQuery"
});
