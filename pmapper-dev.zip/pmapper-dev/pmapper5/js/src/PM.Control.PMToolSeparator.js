OpenLayers.Control.PMToolSeparator = OpenLayers.Class(OpenLayers.Control, {                
    CLASS_NAME: "OpenLayers.Control.PMToolSeparator"
});


OpenLayers.Control.PMToolSpace = OpenLayers.Class(OpenLayers.Control, {                
    CLASS_NAME: "OpenLayers.Control.PMToolSpace"
});



