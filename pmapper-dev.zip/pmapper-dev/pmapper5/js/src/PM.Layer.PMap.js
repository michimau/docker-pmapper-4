/* Copyright (c) 2006-2011 by OpenLayers Contributors (see authors.txt for 
 * full list of contributors). Published under the Clear BSD license.  
 * See http://svn.openlayers.org/trunk/openlayers/license.txt for the
 * full text of the license. */

/**
 * @requires OpenLayers/Layer/Grid.js
 */

/**
 * Class: OpenLayers.Layer.MapServer
 * Instances of OpenLayers.Layer.MapServer are used to display
 * data from a MapServer CGI instance.
 *
 * Inherits from:
 *  - <OpenLayers.Layer.Grid>
 */
OpenLayers.Layer.PMap = OpenLayers.Class(OpenLayers.Layer.Grid, {

    crs: null,
    
    singleTile: true,
    
    msGroups: null,
    
    msGroupsActive: null,
    
    description: null,
    
    imgformat: null,
    
    preventCaching: false,
    
    mapResizeDelay: 300,

    mapResizeTimer: null,
    
    mapUrl: "lib/map/pmap?",
    
    
    
    /**
     * Constant: DEFAULT_PARAMS
     * {Object} Hashtable of default parameter key/value pairs 
     */
    DEFAULT_PARAMS: {
        mode: "map"
    },

    /**
     * Constructor: OpenLayers.Layer.MapServer
     * Create a new MapServer layer object
     *
     * Parameters:
     * name - {String} A name for the layer
     * options - {Object} Hashtable of extra options to tag onto the layer
     */
    initialize: function(name, options) {
        //this.setOptions(options);
        //console.log('PMap options', options);
        var newArguments = [];
        newArguments.push(name, null, {}, options);
        OpenLayers.Layer.Grid.prototype.initialize.apply(this, newArguments);

        this.params = OpenLayers.Util.applyDefaults(
            this.params, this.DEFAULT_PARAMS
        );
    },
    
    setOptions: function(options) {
        for (var key in options) {
            if (options.hasOwnProperty(key)) {
                var val = options[key];
                //consloe.log(key, val);
                this[key] = val;
            }
        }
    },

    /**
     * Method: clone
     * Create a clone of this layer
     *
     * Returns:
     * {<OpenLayers.Layer.MapServer>} An exact clone of this layer
     */
    clone: function (obj) {
        if (obj == null) {
            obj = new OpenLayers.Layer.PMap(this.name,
                                           this.url,
                                           this.params,
                                           this.getOptions());
        }
        //get all additions from superclasses
        obj = OpenLayers.Layer.Grid.prototype.clone.apply(this, [obj]);

        // copy/set any non-init, non-simple values here

        return obj;
    },
    
    /**
     * Method: getURL
     * Return a query string for this layer
     *
     * Parameters:
     * bounds - {<OpenLayers.Bounds>} A bounds representing the bbox 
     *                                for the request
     *
     * Returns:
     * {String} A string with the layer's url and parameters and also 
     *          the passed-in bounds and appropriate tile size specified 
     *          as parameters.
     */
    getURL: function (bounds) {
        bounds = this.adjustBounds(bounds);
        var extent = [bounds.left, bounds.bottom, bounds.right, bounds.top];
        var crs = this.map.projection.projCode;
        var imageSize = this.getImageSize(); 
        
        var newParams = { groups: this.msGroupsActive,
                          imgformat: this.imgFormat,
                          width:  imageSize.w,
                          height: imageSize.h,
                          bbox:   extent,
                          crs:    crs
                        };
        var allParams = newParams; //OpenLayers.Util.extend(newParams, this.params);
        var paramsString = OpenLayers.Util.getParameterString(allParams);       
        //console.log(this.params);
        var url = this.mapUrl + PM.SID + '&' + paramsString + this.getUrlParamsAdditional();
        
        return url;
    },
    
    getUrlParamsAdditional: function() {
    	if (this.preventCaching == 'true') { 
            return this.getTimestampParams();
        } else {
            return "";
        }
    },
    
    
    getTimestampParams: function() {
        var now = parseInt(new Date().getTime() / 100);
        return '&timestamp=' + now;
    },

    CLASS_NAME: "OpenLayers.Layer.PMap"
});


/**
 * Layer for highlight of results
 */
OpenLayers.Layer.PMHighlight = OpenLayers.Class(OpenLayers.Layer.PMap, {

    opacity: 0.3,
    
	mapUrl: "lib/map/pmhighlight?",
	
	getUrlParamsAdditional: function() {
        return this.getTimestampParams();
    },
    
    CLASS_NAME: "OpenLayers.Layer.PMHighlight"
});
  
