OpenLayers.Control.PMMeasureLength = OpenLayers.Class(OpenLayers.Control.Measure, {             

    type: OpenLayers.Control.TYPE_TOOL,
    
    persist: true,
    
    lastMeasure: 0,
    
    measureType: 'Distance',
    
    measureDecimals: 2,
    
    trigger: function() {
        //PM.UI.showHelpMessage(PM._p('digitize_help'));
    },
    
    eventListeners: {
        measure: function(evt) {
            this.showMeasureResults(evt);
            this.lastMeasure = 0;
        },
        
        measurepartial: function(evt) {
            this.showMeasureResults(evt);
        }
    },
    
    initialize: function(options) {
        var handler = OpenLayers.Handler.Path;
        OpenLayers.Control.Measure.prototype.initialize.apply(this, [handler, options]);
        
        var keyboardOptions = {
            keydown: this.handleKeypress
        };
        this.handlers = {
            keyboard: new OpenLayers.Handler.Keyboard(this, keyboardOptions)
        };
    },
    
    handleKeypress: function(evt) {
        var code = evt.keyCode;
        if (this.handler.line) {
        	// ESC pressed. Remove whole sketch
            if (code === 27) {
                this.cancel();
            }

            // DEL pressed. Remove last visible click point (last vertex - 3) 
            if (code === 46) {
                var index = this.handler.line.geometry.components.length - 2;        
                this.handler.line.geometry.removeComponent(this.handler.line.geometry.components[index]);
                this.handler.drawFeature();
            }
        }
        return true;
    },
    
    activate: function() {
        PM.UI.MeasureBox.show(this.CLASS_NAME);
        return this.handlers.keyboard.activate() &&
            OpenLayers.Control.Measure.prototype.activate.apply(this, arguments);
    },
    
    deactivate: function() {                                                     
        PM.UI.MeasureBox.hide();
        var deactivated = false;
        // the return from the controls is unimportant in this case
        if(OpenLayers.Control.Measure.prototype.deactivate.apply(this, arguments)) {
            this.handlers.keyboard.deactivate();
            deactivated = true;
        }
        return deactivated;
    },
    
    cancel: function() {
        OpenLayers.Control.Measure.prototype.cancel.apply(this);
        this.lastMeasure = 0;
        PM.UI.MeasureBox.clear();
    },

    
    showMeasureResults: function(evt) {
        var segment = evt.measure - this.lastMeasure;
        this.lastMeasure = evt.measure;
        $('#pmMeasureTotal').val(evt.measure.roundTo(this.measureDecimals) + " " + evt.units);
        $('#pmMeasureSegment').val(segment.roundTo(this.measureDecimals) + " " + evt.units);
    },
    
    
    CLASS_NAME: "OpenLayers.Control.PMMeasureLength"
});



/**
 * 
 * Keyboard handlers copyright (c) Xurxo M�ndez P�rez, http://www.sonxurxo.com
 * 
 */

OpenLayers.Control.PMMeasureArea = OpenLayers.Class(OpenLayers.Control.Measure, {             

    type: OpenLayers.Control.TYPE_TOOL,
    
    persist: true,
    
    measureType: 'Area',

    measureDecimals: 2,
    
    
    eventListeners: {
        measure: function(evt) {
            this.showMeasureResults(evt);
        },
        
        measurepartial: function(evt) {
            this.showMeasureResults(evt);
        }
    },
    
    initialize: function(options) {
        var handler = OpenLayers.Handler.Polygon;
        OpenLayers.Control.Measure.prototype.initialize.apply(this, [handler, options]);
            
        var keyboardOptions = {
            keydown: this.handleKeypress
        };
        this.handlers = {
            keyboard: new OpenLayers.Handler.Keyboard(this, keyboardOptions)
        };
            
    },
    
    handleKeypress: function(evt) {
        var code = evt.keyCode;
        if (this.handler.polygon) {
            // ESC pressed. Remove whole sketch
            if (code === 27) {
                this.cancel();
            }

            // DEL pressed. Remove last visible click point (last vertex - 3) 
            if (code === 46) {
                var index = this.handler.line.geometry.components.length - 3;        
                this.handler.line.geometry.removeComponent(this.handler.line.geometry.components[index]);
                this.handler.drawFeature();
            }
        }
        return true;
    },
    
    activate: function() {
        PM.UI.MeasureBox.show(this.CLASS_NAME);
        return this.handlers.keyboard.activate() &&
            OpenLayers.Control.Measure.prototype.activate.apply(this, arguments);
    },
    
    deactivate: function() {
        PM.UI.MeasureBox.hide();
        var deactivated = false;
        // the return from the controls is unimportant in this case
        if(OpenLayers.Control.Measure.prototype.deactivate.apply(this, arguments)) {
            this.handlers.keyboard.deactivate();
            deactivated = true;
        }
        return deactivated; 
    },
    
    cancel: function() {
        OpenLayers.Control.Measure.prototype.cancel.apply(this);
        PM.UI.MeasureBox.clear();
    },
    
    showMeasureResults: function(evt) {
        $('#pmMeasureTotal').val(evt.measure.roundTo(this.measureDecimals) + " " + evt.units + "²").css({width:'110px'});
    },
    
    
    CLASS_NAME: "OpenLayers.Control.PMMeasureArea"
});


