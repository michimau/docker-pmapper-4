/**
 * 
 * Keyboard handlers copyright (c) Xurxo M�ndez P�rez, http://www.sonxurxo.com
 * 
 */

OpenLayers.Control.PMSelectByShape = OpenLayers.Class(OpenLayers.Control.Measure, {             

    type: OpenLayers.Control.TYPE_TOOL,
    
    persist: false,
    
    measureType: 'Area',

    
    eventListeners: {
        measure: function(evt, params) {
        	var shpWkt = evt.geometry.toString();
        	var query = new PM.QueryShape("shape", shpWkt);
        },
        
        measurepartial: function(evt) {
            //this.showMeasureResults(evt);
        }
    },
    
    
    initialize: function(options) {
        var handler = OpenLayers.Handler.Polygon;
        OpenLayers.Control.Measure.prototype.initialize.apply(this, [handler, options]);
            
        var keyboardOptions = {
            keydown: this.handleKeypress
        };
        this.handlers = {
            keyboard: new OpenLayers.Handler.Keyboard(this, keyboardOptions)
        };
            
    },
    
    handleKeypress: function(evt) {
        var code = evt.keyCode;
        if (this.handler.polygon) {
            // ESC pressed. Remove drawing */
            if (code === 27) {
                this.cancel();
            }

            // DEL pressed. Remove third last vertex (actually the last drawn one) 
            if (code === 46) {
                var index = this.handler.line.geometry.components.length - 3;        
                this.handler.line.geometry.removeComponent(this.handler.line.geometry.components[index]);
                this.handler.drawFeature();
            }

        }
        return true;
    },
    
    activate: function() {
    	PM.UI.QuerySelectBox.show();
    	return this.handlers.keyboard.activate() &&
            OpenLayers.Control.Measure.prototype.activate.apply(this, arguments);
    },
    
    deactivate: function() {
    	PM.UI.QuerySelectBox.hide();
    	var deactivated = false;
        // the return from the controls is unimportant in this case
        if(OpenLayers.Control.Measure.prototype.deactivate.apply(this, arguments)) {
            this.handlers.keyboard.deactivate();
            deactivated = true;
        }
        return deactivated; 
    },
    

    CLASS_NAME: "OpenLayers.Control.PMSelectByShape"
});