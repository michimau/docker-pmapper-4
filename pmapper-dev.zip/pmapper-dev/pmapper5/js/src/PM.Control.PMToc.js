/** 
 * Class for TOC and layer management
 * 
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License, includes code of OpenLayers LayerSwitcher 
 * 
 * @class OpenLayers.Control.PMToc
 * @static 
 */

/* Copyright (c) 2006-2011 by OpenLayers Contributors (see authors.txt for 
 * full list of contributors). Published under the Clear BSD license.  
 * See http://svn.openlayers.org/trunk/openlayers/license.txt for the
 * full text of the license. */

/** 
 * @requires OpenLayers/Control.js
 */


OpenLayers.Control.PMToc = OpenLayers.Class(OpenLayers.Control, {

    
    /**  
     * Property: layerStates 
     * {Array(Object)} Basically a copy of the "state" of the map's layers 
     *     the last time the control was drawn. We have this in order to avoid
     *     unnecessarily redrawing the control.
     */
    layerStates: null,
    

  // DOM Elements
  
    /**
     * Property: layersDiv
     * {DOMElement} 
     */
    layersDiv: null,
    
    /** 
     * Property: baseLayersDiv
     * {DOMElement}
     */
    baseLayersDiv: null,

    /** 
     * Property: baseLayers
     * {Array(<OpenLayers.Layer>)}
     */
    baseLayers: null,
    
    
    /** 
     * Property: dataLbl
     * {DOMElement} 
     */
    dataLbl: null,
    
    /** 
     * Property: dataLayersDiv
     * {DOMElement} 
     */
    dataLayersDiv: null,

    /** 
     * Property: dataLayers
     * {Array(<OpenLayers.Layer>)} 
     */
    dataLayers: null,


    /** 
     * Property: minimizeDiv
     * {DOMElement} 
     */
    minimizeDiv: null,

    /** 
     * Property: maximizeDiv
     * {DOMElement} 
     */
    maximizeDiv: null,
    
 
    /**
     * Constructor: OpenLayers.Control.LayerSwitcher
     * 
     * Parameters:
     * options - {Object}
     */
    initialize: function(options) {
        OpenLayers.Control.prototype.initialize.apply(this, arguments);
        this.layerStates = [];
    },

    /**
     * APIMethod: destroy 
     */    
    destroy: function() {
        OpenLayers.Event.stopObservingElement(this.div);
        OpenLayers.Event.stopObservingElement(this.minimizeDiv);
        OpenLayers.Event.stopObservingElement(this.maximizeDiv);

        //clear out layers info and unregister their events 
        this.clearLayersArray("base");
        this.clearLayersArray("data");
        
        this.map.events.un({
            "addlayer": this.redraw,
            "removelayer": this.redraw,
            scope: this
        });
        
        OpenLayers.Control.prototype.destroy.apply(this, arguments);
    },

    /** 
     * Method: setMap
     *
     * Properties:
     * map - {<OpenLayers.Map>} 
     */
    setMap: function(map) {
        OpenLayers.Control.prototype.setMap.apply(this, arguments);
        //console.log('setMap called');
        var mapEvents = {
            //"addlayer": this.redraw,
            //"removelayer": this.redraw,
            scope: this
        }
        
        this.map.events.on(mapEvents);
    },

    /**
     * Method: draw
     *
     * Returns:
     * {DOMElement} A reference to the DIV DOMElement containing the 
     *     switcher tabs.
     */  
    draw: function() {
        OpenLayers.Control.prototype.draw.apply(this);
        //console.log("tocDiv", this.div);                    
        
        // set mode to minimize
        if(!this.outsideViewport) {
            this.minimizeControl();
        }

        // create toc and add layers
        this.createToc();   
        
        if ($.parseJSON(PM.ini.ui.legendDynamicUpdate)) {
        	this.map.events.register('moveend', this, this.updateLegend);
        } else {
        	this.map.events.register('zoomend', this, this.updateToScale);
        }
        
        return this.div;
    },
    
    
    /**
     * Create TOC and add all categories and layers
     */
    createToc: function() {
        //console.log("pmCategories", PM.OL.Theme.pmCategories);
        //console.log("olThemes", PM.OL.Theme.olThemes);   
        
        var categories = PM.OL.Theme.pmCategories;
        var catLen = categories.length;
        
        var catObjList = {};
        
        for (var ci=0; ci<catLen; ci++) {
            var cat = categories[ci];
            catName = cat.name;
            //console.log("catName", catName);

            if ($.parseJSON(PM.ini.ui.useCategories)) {
	            var catLi = $("<li>").attr("id", "pmlicat_" + catName);
	            if (PM.ini.ui.tocStyle == 'tree' && cat.state == "open") {
	                catLi.addClass("open");
	            }
	            var catInput = $("<input>").attr({'id': "pmcinput_" + catName, 'name': "catscbx", 'type': "checkbox", 'checked': true})
	                                       .val(catName);
	            var catSpan = $("<span>").attr('id', "pmspxc_" + catName)
	            						 .addClass("pm-toc-cat-label")
	            						 .html(PM._p(cat.description ? cat.description : catName));
            } else {
            	var catLi = $("<div>");
            }
                
            var groups = cat.groups;
            
            // Now add the groups
            var grpInputList = [];
            var grpUl = $("<ul>");
            for (grpName in groups) {
                var grp = groups[grpName];
                var olTheme = grp.olTheme;
                var olLayerObj = this.map.getLayer(olTheme);
                var msGroups = olLayerObj.msGroups ?  olLayerObj.msGroups : null;
                var msGroupsActive = olLayerObj.msGroupsActive ?  olLayerObj.msGroupsActive : null;
                var grpChecked = false;
                
                if (msGroupsActive) {
                    if ($.inArray(grpName, msGroupsActive) > -1) {
                        grpChecked = true;
                    }
                } else {
                    if (olLayerObj.getVisibility()) {
                        grpChecked = true;
                    }
                }
                
                var grpLi = $("<li>").attr('id', "pmligrp_" + grpName);
                if (PM.Toc.treeviewDefaultGroupLegendOpen && grpChecked) {
                	grpLi.addClass("open");
                }
                
                var grpInput = $("<input>").attr({'id':"pmginput_" + grpName, 'name':"grpsscbx", 'type':"checkbox", 'checked':grpChecked})
                                           .val(grpName)
                                           .appendTo(grpLi);
                // Add click binding to input
                var grpContext = {
                    'grpName': grpName,
                    'inputElem': grpInput,
                    'olTheme': olLayerObj,
                    'layerSwitcher': this,
                    'msGroups': msGroups,
                    'msGroupsActive': msGroupsActive
                };
                grpInput.bind("mouseup",  grpContext, this.grpOnInputClick);
                grpInputList.push(grpContext);
                
                var grpDescription = PM.grouplist[grpName] ? PM.grouplist[grpName].description :  grp.description ? grp.description : grpName;
                var grpSpan = $("<span>").attr('id', "pmspxg_" + grpName)
                						 .addClass("pm-toc-grp-label")
                						 .addClass("pm-toc-vis")
                						 .html(PM._p(grpDescription))
                						 .appendTo(grpLi);
                
                // add legend classes if configured 
                if (PM.ini.ui.legendStyle == 'attached' ) {
                    var legendClsList = this.getLegendClasses(grpName);
                    if (legendClsList) {
                        grpLi.append(legendClsList);
                    }
                }
                grpUl.append(grpLi); 
            }
            
            if ($.parseJSON(PM.ini.ui.catWithCheckbox) && $.parseJSON(PM.ini.ui.useCategories)) {
	            // Add click binding to input
	            var catContext = {
	                'grpInputList': grpInputList,
	                'msGroups': cat.groups,
	                'inputElem': catInput,
	                'layerSwitcher': this
	            };
	            catInput.bind("mouseup",  catContext, this.catOnInputClick);
	            catLi.append(catInput);
            }
            
            catLi.append(catSpan)
                 .append(grpUl);
                   
            catObjList[catName] = catLi;
        }
        
        this.addToDiv(catObjList);
        this.setStyle();
        
        this.tocPostLoading();
        
    },
    
    /**
     * Add TOC to docujent <div>
     * @param catObjList
     */
    addToDiv: function(catObjList){
    	var catUl = $("<ul>");
    	$.each(catObjList, function(catname, catObj){
    		catUl.append(catObj);
    	});
    	
    	var tocDiv = $("<div>").attr('id', "pmToc")
        					   .append(catUl)
        					   .appendTo($('#' + this.div.id));
    },
    
    /**
     * Set style according to config as tree or plain
     */
    setStyle: function() {
    	if (PM.ini.ui.tocStyle == 'tree') {
            $('#pmToc').treeview(PM.Toc.treeviewStyle);
        } else {
            $('#pmToc').addClass('treeview treeview-blank');
        }
    },
    
    
    /** 
     * Method: redraw
     * Goes through and takes the current state of the Map and rebuilds the
     *     control to display that state. Groups base layers into a 
     *     radio-button group and lists each data layer with a checkbox.
     *
     * Returns: 
     * {DOMElement} A reference to the DIV DOMElement containing the control
     */  
    redraw: function() {
        console.log("redraw called");
        $('#' + this.div.id)
    	this.createToc();
    },
    
    /**
     * Get classes for legend and create HTML structures for them
     * @param msGroup
     * @returns jQuery DOM element
     */
    getLegendClasses: function(msGroup) {
        var layerList = PM.grouplist[msGroup] ? PM.grouplist[msGroup].layerList : null;
        //console.log("layerList", layerList);
        if (layerList) {
            var grpUl = $("<ul>");
            for (var li=0; li<layerList.length; li++) {
                var classes = layerList[li].classes;
                if (classes.length > 0) {
                    for (var cli=0; cli<classes.length; cli++) {
                        var cls = classes[cli];
                        var clsLi = $("<li>").addClass("pm-toc-layer-classes")
                        					 .css({'backgroundImage': "url('" + PM.Toc.legendIconPath + cls.icon + "')"});
                        
                        var clsDiv = $("<div>").addClass("pm-toc-class-div");
                        var clsSpan = $("<span>").addClass("pm-toc-classlabel")
                                                 .addClass("pm-toc-vis")
                                                 .html(PM._p(cls.name))
                                                 .appendTo(clsDiv);
                        
                        clsLi.append(clsDiv)
                        	 .appendTo(grpUl);
                    }
                }
            }
        }
        return grpUl;
    },

    
    /**
     * Call function when clicked on category checkbox
     * @param evt
     */
    catOnInputClick: function(evt) {
    	var context = evt.data;
    	var catChecked = context.inputElem.is(":checked") ? false : true;
    	//console.log("CAT checked?", catChecked);
    	
    	var grpInputList = context.grpInputList;
    	for (var i=0; i<grpInputList.length; i++) {
    		//console.log(context.grpInputList);
    		var grpInput = grpInputList[i].inputElem;
    		//console.log(grpInput);
    		if (catChecked) {
    			grpInput.attr('disabled', false);
    			if (grpInput.is(":checked")) {
    				grpInput.trigger('mouseup');
    			}	
    		} else {
    			grpInput.attr('disabled', true);
    			if (grpInput.is(":checked")) {
    				grpInput.trigger('mouseup');
    				//console.log(grpInput);
    			}
    		}
    	}
        
    	evt.stopPropagation();  
    },
    
    
    /**
     * Call function when clicked on group checkbox
     * @param evt
     */
    grpOnInputClick: function(evt) {
    	var context = evt.data;
    	var isTrigger = evt.isTrigger ? evt.isTrigger : false;
        //console.log('this all', context);
        
    	// Check if layer is disabled due to scale-dependency
        var grpName = context.grpName;
        var grpIsScaleDisabled = false;
        context.inputElem.parent().find('#pmspxg_' + grpName).each(function() {
        	grpIsScaleDisabled = $(this).attr('class').replace(/pm-toc-grp-label /, '') == 'pm-toc-unvis' ? true : false; 
			//console.log(grpScaleDisabled);
		});
        
        
        if (isTrigger) {
        	var grpChecked = context.inputElem.is(":checked");
        	//console.log("triggered", context.inputElem);
        } else {
        	var grpChecked = context.inputElem.is(":checked") ? false : true;
        	
        	// Check mutually disabling groups; //  in #37 old function
        	if ($.isArray(PM.Map.mutualDisableList)) {
	        	if (PM.Map.mutualDisableList) {
	        		$.each(PM.Map.mutualDisableList, function(ids, mdlist) {
	        			if ($.inArray(grpName, mdlist) > -1) {
	        				$.each(mdlist, function(idx, val) {
	        					var mutualInput = $('#pmginput_' + val);
		        				if (val != grpName && grpChecked && mutualInput.is(':checked')) {
		        					mutualInput.attr('checked', false).trigger('mouseup');
		        				}
	        				});
	        			}
	        		});
        		} else {
	        		if (PM.Map.mutualDisableList.hasOwnProperty(grpName)) {
	        			$.each(PM.Map.mutualDisableList[grpName], function(key, val) {
	        				var mutualInput = $('#pmginput_' + val);
	        				if (grpChecked && mutualInput.is(':checked')) {
	        					mutualInput.attr('checked', false).trigger('mouseup');
	        				}
	        			});
	        		}
        		}
        	}
        }
        
        var disabled = context.inputElem.is(':disabled');
        if (disabled) grpChecked = false;
        //console.log("GRP checked?", grpChecked, 'disabled:', disabled);
        
        // MapServer-based layers/groups
        if (context.olTheme.msGroups) {
            var msGroupsActive = context.olTheme.msGroupsActive;

            if (grpChecked) {
            	context.olTheme.msGroupsActive.push(context.grpName);
            } else {
            	context.olTheme.msGroupsActive.splice( $.inArray(context.grpName, context.olTheme.msGroupsActive), 1 );
            }
            
            if (msGroupsActive.length < 1) {
            	context.olTheme.setVisibility(false);
            } else {
            	context.olTheme.setVisibility(true);
            	// redraw only when visible at current scale
            	if (! grpIsScaleDisabled) {
	            	context.olTheme.redraw();
            	}
            }
        } else {
        	context.olTheme.setVisibility(grpChecked);
        }
        
        
        // Check if querySelectBox needs to be updated
    	if ($('#pmQuerySelectBox').length > 0) {
    		var msGrp = PM.grouplist[grpName];
    		if (msGrp.isQueryable) {
    			PM.UI.QuerySelectBox.redraw();
    		}
    	}
    	
        //OpenLayers.Event.stop(e);
        evt.stopPropagation();
    },
    
    
    /**
     * Update TOC according to scale
     * Change class of group and legend classes
     */
    updateToScale: function() {
        var scale = map.getScale();
        PM.setSessionVar('mapscale', scale, false, null);
        var allGroups = PM.Map.getAllGroups();
        
        $.each(allGroups, function(idx, grpName) {
        	if (PM.grouplist.hasOwnProperty(grpName)) {
        		var grp = PM.grouplist[grpName];
        		var minScaleDenom = grp.minScaleDenom ? grp.minScaleDenom : 0;
        		var maxScaleDenom = grp.maxScaleDenom ? grp.maxScaleDenom : 900000000;
        	} else {
        		var grp = map.getLayer(grpName);
        		//console.log(grp);
        		var maxScaleDenom = 900000000;
        		var minScaleDenom = 0;
        		if (grp.hasOwnProperty('minScale')) {
        			maxScaleDenom = grp.minScale;
        		} 
        		if (grp.hasOwnProperty('maxScale')) {
        			var minScaleDenom = grp.maxScale;
        		} 
        	}
        		
        	var newCls = scale > minScaleDenom && scale < maxScaleDenom ? 'pm-toc-vis' : 'pm-toc-unvis';
        	$('#pmToc').find('#pmspxg_' + grpName).each(function() {
        		$(this).removeClass('pm-toc-unvis').removeClass('pm-toc-vis').addClass(newCls)
        			   .parent().find('span.pm-toc-classlabel').each(function() {
        				   $(this).removeClass('pm-toc-unvis').removeClass('pm-toc-vis').addClass(newCls); 
        		});
            });
        	//console.log(scale, grpName, minScaleDenom, maxScaleDenom, newCls);
        });  
    },
    
    /**
     * Update legend according to scale and extent changes
     */
    updateLegend: function() {
    	this.updateToScale();
    },
    
    
    /**
     * Run scripts defined for plugins after TOC has been created
     */
    tocPostLoading: function() {
        // enable all context menus
        //PM.Init.contextMenus();
        
        // execute all init scripts after TOC full loading
        for (var i=0; i<PM.pluginTocInit.length; i++) {
            eval(PM.pluginTocInit[i]);
        }
    },
    

    /** 
     * Method: maximizeControl
     * Set up the labels and divs for the control
     * 
     * Parameters:
     * e - {Event} 
     */
    maximizeControl: function(e) {

        // set the div's width and height to empty values, so
        // the div dimensions can be controlled by CSS
        this.div.style.width = "";
        this.div.style.height = "";

        this.showControls(false);

        if (e != null) {
            OpenLayers.Event.stop(e);                                            
        }
    },
    
    /** 
     * Method: minimizeControl
     * Hide all the contents of the control, shrink the size, 
     *     add the maximize icon
     *
     * Parameters:
     * e - {Event} 
     */
    minimizeControl: function(e) {

        // to minimize the control we set its div's width
        // and height to 0px, we cannot just set "display"
        // to "none" because it would hide the maximize
        // div
        this.div.style.width = "0px";
        this.div.style.height = "0px";

        this.showControls(true);

        if (e != null) {
            OpenLayers.Event.stop(e);                                            
        }
    },

    /**
     * Method: showControls
     * Hide/Show all LayerSwitcher controls depending on whether we are
     *     minimized or not
     * 
     * Parameters:
     * minimize - {Boolean}
     */
    showControls: function(minimize) {
        if (PM.Toc.showMinMaxButtons) {
            this.maximizeDiv.style.display = minimize ? "" : "none";
            this.minimizeDiv.style.display = minimize ? "none" : "";

            this.layersDiv.style.display = minimize ? "none" : "";
        }
    },
    
    
    addMinMaxButtons: function() {
        var imgLocation = OpenLayers.Util.getImagesLocation();
        var sz = new OpenLayers.Size(18,18);        

        // maximize button div
        var img = imgLocation + 'layer-switcher-maximize.png';
        this.maximizeDiv = OpenLayers.Util.createAlphaImageDiv(
                                    "OpenLayers_Control_MaximizeDiv", 
                                    null, 
                                    sz, 
                                    img, 
                                    "absolute");
        OpenLayers.Element.addClass(this.maximizeDiv, "maximizeDiv");
        this.maximizeDiv.style.display = "none";
        OpenLayers.Event.observe(this.maximizeDiv, "click", 
            OpenLayers.Function.bindAsEventListener(this.maximizeControl, this)
        );
        
        this.div.appendChild(this.maximizeDiv);

        // minimize button div
        var img = imgLocation + 'layer-switcher-minimize.png';
        var sz = new OpenLayers.Size(18,18);        
        this.minimizeDiv = OpenLayers.Util.createAlphaImageDiv(
                                    "OpenLayers_Control_MinimizeDiv", 
                                    null, 
                                    sz, 
                                    img, 
                                    "absolute");
        OpenLayers.Element.addClass(this.minimizeDiv, "minimizeDiv");
        this.minimizeDiv.style.display = "none";
        OpenLayers.Event.observe(this.minimizeDiv, "click", 
            OpenLayers.Function.bindAsEventListener(this.minimizeControl, this)
        );

        this.div.appendChild(this.minimizeDiv);    
        
    },
    
    
    
    /** 
     * Method: ignoreEvent
     * 
     * Parameters:
     * evt - {Event} 
     */
    ignoreEvent: function(evt) {
        OpenLayers.Event.stop(evt);
    },

    /** 
     * Method: mouseDown
     * Register a local 'mouseDown' flag so that we'll know whether or not
     *     to ignore a mouseUp event
     * 
     * Parameters:
     * evt - {Event}
     */
    mouseDown: function(evt) {
        this.isMouseDown = true;
        this.ignoreEvent(evt);
    },

    /** 
     * Method: mouseUp
     * If the 'isMouseDown' flag has been set, that means that the drag was 
     *     started from within the LayerSwitcher control, and thus we can 
     *     ignore the mouseup. Otherwise, let the Event continue.
     *  
     * Parameters:
     * evt - {Event} 
     */
    mouseUp: function(evt) {
        if (this.isMouseDown) {
            this.isMouseDown = false;
            this.ignoreEvent(evt);
        }
    },

    CLASS_NAME: "OpenLayers.Control.PMToc"
});



