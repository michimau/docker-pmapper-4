
/** 
 * Static class for managing the OL themes (= OL layers)
 * 
 * @author Armin Burger
 * @copyright Copyright (c) 2003-2012 Armin Burger
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * 
 * @package OL
 * @static 
 */

$.extend(PM.OL.Theme,
{
        
	applyGlobalNumZoomLevels: false,
	
	/** Theme dictionary for dreating OL Layer objects  */  
    olThemes: {},
        
    /** Theme dictionary for dreating OL Layer objects  */  
    olNativeThemes: {
        themeList: {},
            
        /**
         * Create custom native OL Themes
         * abstract function, to be extended with custom code, e.g. in custom.js
         */
        create: function() {
        }
    },
    
    /** Categories dictionary for TOC and legend  */            
    pmCategories: [],
    
    /**
     * Initialize OL themes
     */
    init: function() {
        this.getThemeList();
        //console.log('olThemes', this.olThemes);
        
        this.olNativeThemes.create();
        
        this.addThemesToMap();
        
        this.addHighlightTheme();
    },

    /**
     * Go through theme list, run the theme make() and it to the map
     */
    addThemesToMap: function() {
        // Check if olThemes defined in XML file
        if (PM.ini.map.olThemes) {
            var olThemeList = PM.ini.map.olThemes.theme;
        } else {
            var olThemeList = [];
            for (var th in this.olThemes) {
                olThemeList.push(th);
            }
        }
        
        //console.log("olThemeList", olThemeList);
        
        // Create OL themes and add them to map 
        // using the order defined by the XML config <olThemes> (if set)
        for (var ti=0; ti<olThemeList.length; ti++) {
            var olThm = this.olThemes[olThemeList[ti]];
            olThemeObj = this.make(olThm);
            map.addLayer(olThemeObj);
        }
    },
    
    /**
     * Make a theme using OL native functions
     * @param olThm
     * @returns {Object}
     */
    make: function(olThm) {
        var thmOptions = olThm.options;
        //console.log(thmOptions );
        thmOptions['isBaseLayer'] = false;
        var thmType = thmOptions.themeType;
        var thmName = thmOptions.olTheme;
        
        
        var additionalOptions = {'id': thmName};
        if (thmOptions.minScale) {
        	additionalOptions['minScale'] = thmOptions.minScale;
        }
        
        if (thmOptions.maxScale) {
        	additionalOptions['maxScale'] = thmOptions.maxScale;
        }
        
        if (thmType == "OSM") {
            thmOptions = null;
        } 
        
        if (thmType == "Google") {
            var gmapType = thmOptions.gmapType;
            thmOptions = null;
            thmOptions = {'type': google.maps.MapTypeId[gmapType]};
        } 
        
        // Create new OL Layer object
        if (thmType != "olnative") {
            var olThemeObj = new OpenLayers.Layer[thmType](thmName, thmOptions);
        
        } else {
            if (this.olNativeThemes.themeList.hasOwnProperty(thmName)) {
                var olThemeObj = this.olNativeThemes.themeList[thmName];
            }
        }
        
        
        if (this.applyGlobalNumZoomLevels && thmType != "OSM") {
            additionalOptions['numZoomLevels'] = map.getNumZoomLevels();
        }
        olThemeObj.addOptions(additionalOptions);
        
        
        if (thmOptions && thmOptions.hasOwnProperty('msGroups')) {
            //console.log("active length", thmOptions.msGroupsActive.length);
            if (thmOptions.msGroupsActive.length < 1) {
                olThemeObj.setVisibility(false);
            }
        } else {
            var defGroups = $.isArray(PM.ini.map.defGroups.group) ? PM.ini.map.defGroups.group : [PM.ini.map.defGroups.group];
            //console.log('defGroups', defGroups);
            if ($.inArray(thmName, defGroups) > -1) {
                try {
                    olThemeObj.setVisibility(true);
                } catch(e) { }
                
            } else {
                try {
                     olThemeObj.setVisibility(false);
                } catch(e) { }
            }
        }
        
        return olThemeObj;
    },
    
    parseThemeOptions: function(optionsIn) {
    	var outVal;
    	var optionsOut = {};
    	$.each(optionsIn, function(key, val) {
    		if ($.isNumeric(val)) {
    			outVal = parseFloat(val);
    		} else {
    			outVal = val
    		}
    		optionsOut[key] = outVal;
    	});
    	return optionsOut;
    },
    

    /**
     * Crate the list of OL themes
     */
    getThemeList: function() {
    	var iniMap = PM.ini.map;
        var categories = iniMap.categories.category;
        if (! $.isArray(categories)) {
            categories = [categories];
        }
        var defGroups = iniMap.defGroups.group;
        if (! $.isArray(defGroups)) {
            defGroups = [defGroups];
        }
        //console.log("defGroups", defGroups);
        
        var iniImgFormat = iniMap.imgFormat; 
        
        for (var ic=0; ic<categories.length; ic++) {
            var cat = categories[ic];
            var msGroups = [];
            var catGroups = [];
            var thmName = null;
            var thmOptions = cat['@attributes'];
            
            // check groups for cat; 
            // if is object (has 'olTheme' property) create new olTheme, else add to msGroups array
            if ($.isArray(cat.group)) {
                for (var ig=0; ig<cat.group.length; ig++) {
                    var grp = cat.group[ig];
                    //console.log(grp);
                    if ($.isPlainObject(grp)) {
                        if (grp.themeType && grp.themeType == 'OL') {
                            
                        } else {
                            this.addTheme(grp.olTheme, [grp.name], defGroups, grp['@attributes']);
                        }
                        var grpDescr = grp.description ? grp.description : null;
                        catGroups.push({'groupname':grp.name, 'theme': grp.olTheme, 'description': grpDescr});
                    } else {
                        msGroups.push(grp);
                        catGroups.push(grp);
                    }
                }
            } else {
                if (cat.group.olTheme) {
                    if (cat.group.themeType && cat.group.themeType == 'OL') {
                        
                    } else {
                        this.addTheme(cat.group.olTheme, [cat.group.name], defGroups, cat.group['@attributes']);
                    }
                    //catGroups.push(cat.group.name);
                    var grpDescr = cat.group.description ? cat.group.description : null;
                    catGroups.push({'groupname':cat.group.name, 'theme': cat.group.olTheme, 'description': grpDescr});
                } else {
                    msGroups = [cat.group];
                    catGroups.push(cat.group);
                }
            }
            
            
            
            if (cat.olTheme) {
                thmName = cat.olTheme;
            } else {
                //console.log(cat.group);
                if (cat.group.olTheme) {
                    thmName = cat.group.olTheme;
                } else {
                    thmName = 'defaultTheme';
                }
            }
            
            if (cat.themeType) {
                thmType = cat.themeType;
            } else {
                thmType = 'defaultTheme';
            }
            
            var catDescription = cat.description ? cat.description : null;
            var catState = cat.state ? cat.state : "open";
                
            this.addTheme(thmName, msGroups, defGroups, thmOptions); 
            this.addCategory(cat.name, catDescription, catState, catGroups, thmName);
        }
        //console.log(this.olThemes);
    },
    
    
    /**
     * Add an OL theme to theme list
     * @param thmName
     * @param msGroups
     * @param defGroups
     * @param thmOptions
     */
    addTheme: function(thmName, msGroups, defGroups, thmOptions) {
        // Check if group in msGroups are set as default, 
        // if yes add them to Active
        var crs = map.getProjection(); //.getCode();  ===> will need adaptation for OL 3.0 <====
    	var msGroupsActive = [];
        $.each(msGroups, function(idx, val) {
            if ($.inArray(val, defGroups)  > -1) {
                msGroupsActive.push(val);
            }
        });
        
        if (! this.olThemes[thmName]) {
            if (msGroups.length > 0) {
                var buffer = thmOptions.buffer ? parseInt(thmOptions.buffer) : 0;
                var themeType = thmOptions.themeType ? thmOptions.themeType : 'PMap';
                var options = $.extend(thmOptions, {'themeType':themeType, 'msGroups':msGroups, 'msGroupsActive':msGroupsActive, 'buffer':buffer, 'crs':crs});
                this.olThemes[thmName] = {'options':options};
            }
        } else {
            $.merge(this.olThemes[thmName].options.msGroups,  msGroups);
            $.merge(this.olThemes[thmName].options.msGroupsActive,  msGroupsActive);
        }
    },
    
    
    /**
     * Add category to list
     * @param catName
     * @param catDescription
     * @param catState
     * @param groups
     * @param thmName
     */
    addCategory: function(catName, catDescription, catState, groups, thmName) {
        //console.log("addCategory groups", groups);
        var groupDict = {};
        for (var i=0; i<groups.length; i++) {
            var grp = groups[i];
            
            // Check if grp is object (and hence a separate olTheme)
            if ($.isPlainObject(grp)) {
                groupDict[grp.groupname] = {'olTheme': grp.theme, 'description': grp.description};
            } else {
                groupDict[grp] = {'olTheme': thmName};
            }
        }
        var cat = {'name': catName, 'description': catDescription, 'state': catState, 'groups': groupDict};
        this.pmCategories.push(cat);
    },
    
    /**
     * Add highlight theme to map
     */
    addHighlightTheme: function() {
    	var thmOptions = PM.highlightOptions;
    	var thmName = "pmResultHighlight";
    	var hlTheme = new OpenLayers.Layer.PMHighlight(thmName, thmOptions);
    	hlTheme.addOptions({'id': thmName});
    	hlTheme.setVisibility(false);
    	map.addLayer(hlTheme);
    }
    
    





    


});