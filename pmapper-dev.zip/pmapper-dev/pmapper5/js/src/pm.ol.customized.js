/**
 * Customizations for various OL classes
 * See copyright info of referenced class files
 */

/**
 * Function to allow overwriting the "initialize" method of a class  
 */
OpenLayers.Util.overwrite = function (C, o) {
    if(typeof o.initialize === "function" &&
        C === C.prototype.initialize) {
        // OL 2.11

        var proto = C.prototype;
        var staticProps = OpenLayers.Util.extend({}, C);

        C = o.initialize;

        C.prototype = proto;
        OpenLayers.Util.extend(C, staticProps);
    }
    OpenLayers.Util.extend(C.prototype, o);
    return C;
}



/*****************************
 *             MAP
 *****************************/
/**
 * Add new function for returning minZoomLevel defined for map
 */
OpenLayers.Map.prototype.getMinZoomLevel = function() {
    var numZoomLevels = null;
    //return 14;
    if (this.restrictedZoomLevel) {
        return this.restrictedZoomLevel;
    } else {
        if (this.baseLayer != null) {
            numZoomLevels = this.getNumZoomLevels();
            //numZoomLevels = this.numZoomLevels;
            //return this.numZoomLevels;
        }
    }
    return numZoomLevels;
}

OpenLayers.Map.prototype.getNumZoomLevels = function() {
    if (PM.Map.getNumZoomLevelsFromMap) {
	  	return this.numZoomLevels;
    } else {
    	return this.baseLayer.numZoomLevels;
    }
}



/**
 * Zoom to max extent as default uses approximate level
 */
OpenLayers.Map.prototype.zoomToMaxExtent = function() {
    var maxExtent = this.maxExtent;
    //alert(maxExtent);
    this.zoomToExtent(maxExtent, true);
}

OpenLayers.Map.prototype.isValidZoomLevel = function(zoomLevel) {
    return ( (zoomLevel != null) && (zoomLevel >= this.restrictedMinZoom) &&  (zoomLevel < this.getNumZoomLevels()) );
}

OpenLayers.Map.prototype.restrictedMinZoom = 0;





/*****************************
 *         CONTROLS
 *****************************/

/**
 * Take into account minZoomLevel defined for map for reduced slider height
 */
OpenLayers.Control.PanZoomBar.prototype._addZoomBar = function(centered) {
    var imgLocation = OpenLayers.Util.getImagesLocation();
    
    var id = this.id + "_" + this.map.id;
    var zoomsToEnd = this.map.getNumZoomLevels() - 1 - this.map.getZoom();
    var slider = OpenLayers.Util.createAlphaImageDiv(id,
                   centered.add(-1, zoomsToEnd * this.zoomStopHeight), 
                   new OpenLayers.Size(20,9), 
                   imgLocation+"slider.png",
                   "absolute");
    slider.style.cursor = "move";
    this.slider = slider;
    
    this.sliderEvents = new OpenLayers.Events(this, slider, null, true,
                                        {includeXY: true});
    this.sliderEvents.on({
        "mousedown": this.zoomBarDown,
        "mousemove": this.zoomBarDrag,
        "mouseup": this.zoomBarUp,
        "dblclick": this.doubleClick,
        "click": this.doubleClick
    });
    
    var sz = new OpenLayers.Size();
    //~ sz.h = this.zoomStopHeight * this.map.getNumZoomLevels();
    sz.h = this.zoomStopHeight * this.map.getMinZoomLevel();
    sz.w = this.zoomStopWidth;
    var div = null;
    
    if (OpenLayers.Util.alphaHack()) {
        var id = this.id + "_" + this.map.id;
        div = OpenLayers.Util.createAlphaImageDiv(id, centered,
                                  new OpenLayers.Size(sz.w, 
                                          this.zoomStopHeight),
                                  imgLocation + "zoombar.png", 
                                  "absolute", null, "crop");
        div.style.height = sz.h + "px";
    } else {
        div = OpenLayers.Util.createDiv(
                    'OpenLayers_Control_PanZoomBar_Zoombar' + this.map.id,
                    centered,
                    sz,
                    imgLocation+"zoombar.png");
    }
    
    this.zoombarDiv = div;
    
    this.divEvents = new OpenLayers.Events(this, div, null, true, 
                                            {includeXY: true});
    this.divEvents.on({
        "mousedown": this.divClick,
        "mousemove": this.passEventToSlider,
        "dblclick": this.doubleClick,
        "click": this.doubleClick
    });
    
    this.div.appendChild(div);

    this.startTop = parseInt(div.style.top);
    this.div.appendChild(slider);

    this.map.events.register("zoomend", this, this.moveZoomBar);

    centered = centered.add(0, 
        this.zoomStopHeight * this.map.getMinZoomLevel());
        //~ this.zoomStopHeight * this.map.getNumZoomLevels());
    
    return centered; 
}


/**
 * Required to avoid errors when added to a DIV
 * @param boolean minimize
 */
OpenLayers.Control.OverviewMap.prototype.showToggle = function(minimize) {
    if (typeof(this.maximizeDiv) != 'undefined') {
        this.maximizeDiv.style.display = minimize ? '' : 'none';
        this.minimizeDiv.style.display = minimize ? 'none' : '';
    }
}

/**
 * Do not deactivate mouse wheel zoom and keep default dragpan for other controls than Navigation
 */
OpenLayers.Control.Navigation.prototype.deactivate = function() {
    if (this.pinchZoom) {
        this.pinchZoom.deactivate();
    }
    this.zoomBox.deactivate();
    //this.dragPan.deactivate();
    this.handlers.click.deactivate();
    //this.handlers.wheel.deactivate();
    return OpenLayers.Control.prototype.deactivate.apply(this,arguments);
}


