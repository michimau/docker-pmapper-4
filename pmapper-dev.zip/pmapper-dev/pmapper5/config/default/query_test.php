<?php
    

//==== ADAPT ================================================================
$mapFile = "pmapper_demo.map";
$layerName = "cities10000eu";

$msVersion = ms_GetVersionInt();
$map = ms_newMapObj($mapFile);
$qLayer = $map->getLayerByName($layerName);
$qLayer->set("status", MS_ON);
$qLayer->set("template", "something");

$cLayer = $map->getLayerByName("countries");
$cLayer->set("status", MS_ON);


$map->setExtent(1009852,6032697,1376749,6338445);
$map->setSize(900, 750);
$map->preparequery();


$selrect = ms_newrectObj();
$selrect->setextent(1048376.3078011,6033309.1858008,1334556.5416609,6268123.7366601); //1155388.1473854,6083451.8763485,1215926.2737789,6131148.5819918);
     
$query = $map->queryByRect($selrect);
//$query = $qLayer->queryByPoint($XY_geo, MS_MULTIPLE, 0.5);

$qLayer->open();
$numResults = $qLayer->getNumResults();
print("n. results: " . $numResults . "\n\n"); 
 
for ($iRes=0; $iRes < $numResults; $iRes++) {
    $qRes = $qLayer->getResult($iRes);
    
    if ($msVersion >= 60000) {
        $qShape = $qLayer->getShape($qRes);
    } else {
        $qShape = $qLayer->getShape($qRes->tileindex,$qRes->shapeindex);
    }
    $result = $qShape->values;
   
    print_r($result);
}
$qLayer->close();



?>