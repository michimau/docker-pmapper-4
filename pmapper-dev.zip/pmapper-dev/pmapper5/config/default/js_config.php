<?php

require_once("../../lib/pmsession.php");

header("Content-Type: text/javascript; charset=" . $_SESSION['defCharset']);

?>


//<script type="text/javascript">

/*************************************************************
 *                                                           *
 *          JavaScript configuration settings                *
 *                                                           *
 *************************************************************/


/**
 * Set to true if cursor shall change according to active tool (default: true)
 */
PM.useCustomCursor = true;


/**
 * Define scale selection list: 
 * ==> adapt to scale range of your data
 * ==> set empty array for disabling function 
 * values can be numbers or numbers containing 1000-separators [. , ' blank]
 */
//PM.scaleSelectList = []; 
//PM.scaleSelectList = [5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2500000]; 
//PM.scaleSelectList = [100000, 250000, 500000, 1000000, 2500000, 5000000, 10000000, 25000000]; 
//PM.scaleSelectList = ["100.000", "250.000", "500.000", "1.000.000", "2.500.000", "5.000.000", "10.000.000", "25.000.000"];
//PM.scaleSelectList = ["100,000", "250,000", "500,000", "1,000,000", "2,500,000", "5,000,000", "10,000,000", "25,000,000"];
//PM.scaleSelectList = ["100'000", "250'000", "500'000", "1'000'000", "2'500'000", "5'000'000", "10'000'000", "25'000'000"];
PM.scaleSelectList = ["100 000", "250 000", "500 000", "1 000 000", "2 500 000", "5 000 000", "10 000 000", "25 000 000"];



/**
 * Define query result layout: tree or table (default: table)
 */
//PM.Query.resultLayout = 'tree';
PM.QueryConfig.resultLayout = 'table';

/**
 * Define tree style for queryResultLayout = 'tree'
 * css: "red", "black", "gray"; default: none; styles defined in /templates/treeview.css
 * treeview:
 *   @option String|Number speed Speed of animation, see animate() for details. Default: none, no animation
 *   @option Boolean collapsed Start with all branches collapsed. Default: true
 *   @option Boolean unique Set to allow only one branch on one level to be open
 *         (closing siblings which opening). Default: true
 */
//PM.QueryConfig.treeStyle = {css: "red", treeview: {collapsed: true, unique: true}};
PM.QueryConfig.treeStyle = {treeview: {collapsed: true, unique: true, persist:false}};


/**
 * Define style of treeview for TOC 
 * default: {collapsed:true, persist:false} 
 */
PM.Toc.treeviewStyle = {collapsed:true, persist:false, animated:'fast'};

PM.Toc.treeviewDefaultGroupLegendOpen = true;
 

/**
 * Decide if auto-identify shall show pop-up element at mouse pointer (default: false)
 */
PM.QueryConfig.iqueryFollowMouse = false;


/**
 * Define if select a SUGGEST row will directly launch the search (default: true)
 */
PM.QueryConfig.suggestLaunchSearch = true;


/**
 * Timer to keep session alive. 
 * Set to value lower than life time of session in php.ini
 */
PM.Init.sessionTimer = "1800s";


/**
 * Definitions of context menus
 * parameters for styles are: menuStyle, itemStyle, itemHoverStyle
 * for details see http://www.trendskitchens.co.nz/jquery/contextmenu/
 */
 PM.contextMenuList = [     
   {bindto: 'span.pm-toc-grp-label',        
    menuid: 'cmenu_tocgroup',
    menulist: [   
       	{id:'info',   imgsrc:'info-b.png', text:'Layer Info',  run:'PM.Custom.showGroupInfo'}
    ], 
    styles: {menuStyle: {width:'auto'}}
   },
   {bindto: '#map',
    menuid: 'cmenu_toccat',
    menulist: [
	{id:'zoomfull',  imgsrc:'zoomfull-b.png', text:'Zoom To Full Extent',  run:'PM.Map.zoomToMaxExtent'},
       {id:'zoomselected',  imgsrc:'zoomtoselected-b.png', text:'Zoom To Selected',  run:'PM.Map.zoomToSelected'},
       {id:'clearselection', imgsrc:'clearselection-b.png', text:'Clear Selection',  run:'PM.Map.clearHighlight'}
      ], 
    styles: {menuStyle: {width:'auto'}}
   }
];

                                                                                

/**
 * Tool link elements
 */
PM.linksDefault = {
    containerid:'toolLinkContainer',
    links: [
        {linkid:'link', name:'Link', run:'PM.UI.MapLink.show', imgsrc:'link-w.png'},
        {linkid:'print', name:'Print', run:'PM.Dlg.openPrint', imgsrc:'print-w.png'},
        {linkid:'download', name:'Download', run:'PM.Dlg.openDownload', imgsrc:'download-w.png'},
        {linkid:'help', name:'Help', run:'PM.Dlg.openHelp', imgsrc:'help-w.png'},
        {linkid:'home', name:'Home', run:'http://www.pmapper.net', target:'_new', imgsrc:'home-w.png'}
        //{linkid:'layers', name:'Layers', run:'PM.Plugin.Layerselect.openDlg', imgsrc:'layers-bw.png'}
        
    ]
};


/**
 * Tabs used for swapping between TOC and legend (legStyle=swap)
 */
PM.tocTabs = {
    tabid: 'pmTocTabulators',
    options: {
        mainClass: 'pm-tabs'
    },
    tabs: [
        {tabid:'layers', name:'Layers', run:'PM.Toc.swapToLayerView', imgsrc:null, active:true},
        {tabid:'legend', name:'Legend', run:'PM.Toc.swapToLegendView', imgsrc:null}
    ]
};



/**
 * OpenLayer Controls 
 */
PM.controls = [
    //{type: 'Navigation'},  // should be added if not in toolbar or if no toolbar defined
    {type: 'Scale'},
    {type: 'ScaleLineMetric'},
    {type: 'KeyboardDefaults'},
    {type: 'PanZoomBar', params: {div: 'pmPanZoomBarContainer'}},
    {type: 'MousePosition', params: {numDigits:4, prefix:'x: ', separator:'&nbsp;  y: ', suffix:' &deg;'} },
    {type: 'Attribution', params: {separator: ';&nbsp;'} },
    {type: 'PMToc', params: {div: 'pmTocContainer'} },
    {type: 'LoadingPanel'}
];
    
    
/**
 * Toolbar elements
 */
PM.toolBar = {
    tools: [
        {type: 'ZoomToMaxExtent', params: {title:"Zoom To Full Extent"} },
        {type: 'NavigationHistory', params: {title:['Back', 'Forward']} },
        //{type: 'PMToolSpace', params: {title:''} }, // alternative to separator
        {type: 'PMToolSeparator', params: {title:''} }, 
        {type: 'ZoomBox', params: {title:"Zoom In"} },
        {type: 'Navigation', params: {title:'Pan', activated: true} },
        {type: 'PMToolSeparator', params: {title:''} }, 
        {type: 'PMIdentify', params: {title:"Identify"} }, 
        {type: 'PMSelect', params: {title:"Select"} },
        {type: 'PMSelectByShape', params: {title:"Select By Polygon"} },
        {type: 'PMIQuery', params: {title:"Tool Tip", delay:200} },
        {type: 'PMToolSeparator', params: {title:''} },
        {type: 'PMMeasureLength', params: {title:"Measure Distance"} },
        {type: 'PMMeasureArea', params: {title:"Measure Area"} }
    ]
};


/**
 * Configuration for tocdomains plugin
 * alternative definition to settings in XML config file (which has precedence)
 */
//PM.Plugin.TocDomains.domains = [           
//    {id: 'domain1', description:"First Domain", category: ['cat_admin', 'cat_infra', 'cat_nature'], state:"open" },
//    {id: 'domain2', description:"Second Domain", category: ['cat_raster', 'cat_osm'], state:"open"} 
//];
    
    
    
    
/**
 * OpenLayer map options
 */        
PM.mapOptions = {
    projection: new OpenLayers.Projection("EPSG:900913"),
    displayProjection: new OpenLayers.Projection("EPSG:4326"),
    units: "m",
    numZoomLevels: 20,        //
    restrictedZoomLevel: 16,  // settings should be: restrictedMinZoom + restrictedZoomLevel = numZoomLevels
    restrictedMinZoom: 3,     // 
    zoomMethod: null,
    //maxResolution: 4891.9698095703125,
    //maxExtent: new OpenLayers.Bounds(-20037508, -20037508, 20037508, 20037508.34)
    maxExtent: new OpenLayers.Bounds(-4000000, 3000000, 8000000, 12000000)
    //maxExtent: new OpenLayers.Bounds(800000,4500000,2500000,6200000)
};

/**
 * Options for overview map
 */
PM.overviewMapOptions = {
    div: 'pmOverviewMapContainer',
    olThemes: [ ['osmmapnik', ['osmmapnik']] ],
    maximized: false,
    size: [200, 150],
    minRatio: 10,
    mapOptions: {
        maxExtent: new OpenLayers.Bounds(-4000000, 3000000, 8000000, 12000000)
    }
};

/** Position of PanZoomBar */
OpenLayers.Control.PanZoom.X = 6;
OpenLayers.Control.PanZoom.Y = 20;


/**
 * Mutually disable layers
 */

//PM.Map.mutualDisableList_ = {
//	"countries": ['rivers'],
//	"rivers": ["countries"]
//};

//PM.Map.mutualDisableList = [ ["countries", "rivers", "roads"] ];

PM.Map.mutualDisableList = [
	['urban', 'cities10000eu'],
	['osmmapnik', 'gsat', 'bluemarble', 'shaded_relief']
];




PM.Plugin.Mapselect.settings = { 
    displayText:_p('Select Theme'),
    configList:{'default':"Map Default", 
                'singletile':"Map Singletile"
               }, 
    appendToDiv:"#uiLayoutNorth",
    cssDiv:{'position':'absolute', 'right':'300px', 'top':'5px'},
    cssSelect:{'margin-left':'5px'},
    resetSession:'groups'
};
	

/*
Zoom levels corresponding to scale and resolution
-----------------------------------------------
Zoom  Resolution           Scale 
1:    156543.03390625      443744272.74185663
2:    78271.516953125      221872136.37092832
3:    39135.7584765625     110936068.18546416
4:    19567.87923828125    55468034.09273208
5:    9783.939619140625    27734017.04636604
6:    4891.9698095703125   13867008.52318302
7:    2445.9849047851562   6933504.26159151
8:    1222.9924523925781   3466752.130795755
9:    611.4962261962891    1733376.0653978775
10:   305.74811309814453   866688.0326989387
11:   152.87405654907226   433344.01634946937
12:   76.43702827453613    216672.00817473468
13:   38.218514137268066   108336.00408736734
14:   19.109257068634033   54168.00204368367
15:   9.554628534317017    27084.001021841836
16:   4.777314267158508    13542.000510920918
17:   2.388657133579254    6771.000255460459
18:   1.194328566789627    3385.5001277302295
19:   0.5971642833948135   1692.7500638651147
----------------------------------------------
*/
 


//</script>
