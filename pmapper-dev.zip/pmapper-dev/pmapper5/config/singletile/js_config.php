<?php

require_once("../../lib/pmsession.php");

header("Content-Type: text/javascript; charset=" . $_SESSION['defCharset']);

?>


//<script type="text/javascript">

/*************************************************************
 *                                                           *
 *          JavaScript configuration settings                *
 *                                                           *
 *************************************************************/


/**
 * Set to true if cursor shall change according to active tool (default: true)
 */
PM.useCustomCursor = true;


/**
 * Define scale selection list: 
 * ==> adapt to scale range of your data
 * ==> set empty array for disabling function 
 * values can be numbers or numbers containing 1000-separators [. , ' blank]
 */
//PM.scaleSelectList = []; 
//PM.scaleSelectList = [5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2500000]; 
//PM.scaleSelectList = [100000, 250000, 500000, 1000000, 2500000, 5000000, 10000000, 25000000]; 
//PM.scaleSelectList = ["100.000", "250.000", "500.000", "1.000.000", "2.500.000", "5.000.000", "10.000.000", "25.000.000"];
//PM.scaleSelectList = ["100,000", "250,000", "500,000", "1,000,000", "2,500,000", "5,000,000", "10,000,000", "25,000,000"];
//PM.scaleSelectList = ["100'000", "250'000", "500'000", "1'000'000", "2'500'000", "5'000'000", "10'000'000", "25'000'000"];
PM.scaleSelectList = ["100 000", "250 000", "500 000", "1 000 000", "2 500 000", "5 000 000", "10 000 000", "25 000 000"];



/**
 * Define query result layout: tree or table (default: table)
 */
//PM.Query.resultLayout = 'tree';
PM.Query.resultLayout = 'table';

/**
 * Define tree style for queryResultLayout = 'tree'
 * css: "red", "black", "gray"; default: none; styles defined in /templates/treeview.css
 * treeview:
 *   @option String|Number speed Speed of animation, see animate() for details. Default: none, no animation
 *   @option Boolean collapsed Start with all branches collapsed. Default: true
 *   @option Boolean unique Set to allow only one branch on one level to be open
 *         (closing siblings which opening). Default: true
 */
//PM.queryTreeStyle = {css: "red", treeview: {collapsed: true, unique: true}};
PM.Query.treeStyle = {treeview: {collapsed: true, unique: true, persist:false}};


/**
 * Close categories tree in array on startup
 * (default: all categories open)
 */
PM.Toc.categoriesClosed = ['cat_infra'];


/**
 * Define style of treeview for TOC 
 * default: {collapsed:true, persist:false} 
 */
PM.Toc.treeviewStyle = {collapsed:true, persist:false, animated:'fast'};

 PM.Toc.treeviewDefaultGroupLegendOpen = true;
 

/**
 * Decide if auto-identify shall show pop-up element at mouse pointer (default: false)
 */
PM.Query.iqueryFollowMouse = false;


/**
 * Define if select a SUGGEST row will directly launch the search (default: true)
 */
PM.Query.suggestLaunchSearch = true;



/**
 * Definitions of context menus
 * parameters for styles are: menuStyle, itemStyle, itemHoverStyle
 * for details see http://www.trendskitchens.co.nz/jquery/contextmenu/
 */
PM.contextMenuList = [     
    {bindto: 'span.pm-toc-grp-label',        
     menuid: 'cmenu_tocgroup',
     menulist: [   
        {id:'info',   imgsrc:'info-b.png', text:'Layer Info',  run:'PM.Custom.showGroupInfo'}
     ], 
     styles: {menuStyle: {width:'auto'}}
    },
    
    {bindto: 'span.pm-toc-cat-label',        
        menuid: 'cmenu_toccat',
        menulist: [   
           {id:'info',   imgsrc:'info-b.png', text:'Category Info',  run:'PM.Custom.showCategoryInfo'}
        ], 
        styles: {menuStyle: {width:'auto'}}
    },
    
    {bindto: '#map',
     menuid: 'cmenu_toccat',
     menulist: [
		{id:'zoomfull',  imgsrc:'zoomfull-b.png', text:'Zoom To Full Extent',  run:'PM.Map.zoomToMaxExtent'},
        {id:'zoomselected',  imgsrc:'zoomtoselected-b.png', text:'Zoom To Selected',  run:'PM.Map.zoomToSelected'},
        {id:'clearselection', imgsrc:'clearselection-b.png', text:'Clear Selection',  run:'PM.Map.clearHighlight'}
       ], 
     styles: {menuStyle: {width:'auto'}}
    }
];

                                                                               

/**
 * Tool link elements
 */
PM.linksDefault = {
    containerid:'toolLinkContainer',
    links: [
        {linkid:'link', name:'Link', run:'PM.UI.MapLink.show', imgsrc:'link-w.png'},
        {linkid:'print', name:'Print', run:'PM.Dlg.openPrint', imgsrc:'print-w.png'},
        {linkid:'download', name:'Download', run:'PM.Dlg.openDownload', imgsrc:'download-w.png'},
        {linkid:'help', name:'Help', run:'PM.Dlg.openHelp', imgsrc:'help-w.png'},
        {linkid:'home', name:'Home', run:'http://www.pmapper.net', target:'_new', imgsrc:'home-w.png'}
        //{linkid:'layers', name:'Layers', run:'PM.Plugin.Layerselect.openDlg', imgsrc:'layers-bw.png'}
        
    ]
};


/**
 * Tabs used for swapping between TOC and legend (legStyle=swap)
 */
PM.tocTabs = {
    tabid: 'pmTocTabulators',
    options: {
        mainClass: 'pm-tabs'
    },
    tabs: [
        {tabid:'layers', name:'Layers', run:'PM.Toc.swapToLayerView', imgsrc:null, active:true},
        {tabid:'legend', name:'Legend', run:'PM.Toc.swapToLegendView', imgsrc:null}
    ]
};



/**
 * OpenLayer Controls 
 */
PM.controls = [
    //{type: 'Navigation'},  // should be added if not in toolbar
    {type: 'Scale'},
    {type: 'ScaleLineMetric'},
    {type: 'KeyboardDefaults'},
    {type: 'PanZoomBar', params: {div: 'pmPanZoomBarContainer'}},
    {type: 'MousePosition', params: {numDigits:4, prefix:'x: ', separator:'&nbsp;  y: ', suffix:' &deg;'} },
    {type: 'Attribution', params: {separator: ';&nbsp;'} },
    {type: 'PMToc', params: {div: 'pmTocContainer'} }
];
    
    
/**
 * Toolbar elements
 */
PM.toolBar = {
    tools: [
        {type: 'ZoomToMaxExtent', params: {title:"Zoom To Full Extent"} },
        {type: 'NavigationHistory', params: {title:['Back', 'Forward']} },
        //{type: 'PMToolSpace', params: {title:''} }, 
        {type: 'PMToolSeparator', params: {title:''} }, 
        {type: 'ZoomBox', params: {title:"Zoom In"} },
        {type: 'Navigation', params: {title:'Pan', activated: true} },
        {type: 'PMToolSeparator', params: {title:''} }, 
        {type: 'PMIdentify', params: {title:"Identify"} }, 
        {type: 'PMSelect', params: {title:"Select"} },
        {type: 'PMIQuery', params: {title:"Tool Tip", delay:200} },
        {type: 'PMToolSeparator', params: {title:''} },
        {type: 'PMMeasureLength', params: {title:"Measure Distance"} },
        {type: 'PMMeasureArea', params: {title:"Measure Area"} },
        {type: 'PMToolSeparator', params: {title:''} },
        {type: 'PMClearMap',  params: {title:"Reload Map"} },
        {type: 'PMZoomToSelected',  params: {title:"Zoom To Selected"} }
        
    ]
};
        
/**
 * Options for the highlight of search results
 */
PM.highlightOptions = {
	imgformat: "png8",
	opacity: 0.4
};

    
/**
 * OpenLayer map options
 */        
PM.mapOptions = {
    projection: new OpenLayers.Projection("EPSG:3035"),
    displayProjection: new OpenLayers.Projection("EPSG:4326"),
    units: "m",
    //maxResolution: 'auto',   // !!! IMPORTANT For projections other than 4326 or 900913 (Google) use this setting or "scales:[]"
    scales: [25000000,15000000,10000000,7500000,5000000,2500000,1000000,750000,500000,250000,100000,75000,50000,25000,10000],
    fractionalZoom: true,
    maxExtent: new OpenLayers.Bounds(1500000,500000,7800000,6530000)
};



/**
 * OpenLayer options for overview map control
 */
PM.overviewMapOptions = {
    div: 'pmOverviewMapContainer',
    olThemes: [ ['admin', ['bluemarble', 'countries']] ],
    size: [200, 150],
    //maximized: false,
    minRatio: 6,
    minRatio: 38,
    minRectSize: 10,
    autoPan: false,
    mapOptions: {
    	projection: PM.mapOptions.projection,
        units: "m",
        maxResolution: 'auto', 
        maxExtent: new OpenLayers.Bounds(1500000,500000,6700000,8030000)
    }
};

/** 
 * Position of PanZoomBar 
 */
OpenLayers.Control.PanZoom.X = 6;
OpenLayers.Control.PanZoom.Y = 20;


//</script>
