/*
 * This class inherits DrawFeature control. It adds a keyboard handler to manage ESCAPE
 * and DELETE key press.
 */
OpenLayers.Control.DrawFeatureOpt = OpenLayers.Class(OpenLayers.Control.DrawFeature, {
    handlers: null,
    initialize: function(layer, handler, options) {
        OpenLayers.Control.DrawFeature.prototype.initialize.apply(this, [layer, handler, options]);
        // configure the keyboard handler
        var keyboardOptions = {
            keydown: this.handleKeypress
        };
        this.handlers = {
            keyboard: new OpenLayers.Handler.Keyboard(this, keyboardOptions)
        };
    },
    handleKeypress: function(evt) {
        var code = evt.keyCode;
        if (this.handler.drawing) {
            /*
             * ESCAPE pressed. Remove second last vertix and finalize the drawing
             */
            if (code === 27) {
                var index = this.handler.line.geometry.components.length - 2;
                this.handler.line.geometry.removeComponent(this.handler.line.geometry.components[index]);
                this.handler.finalize();
            }
            /*
             * DELETE pressed. Remove third last vertix (actually the last drawn one) 
             * and redraw the feature
             */
            if (code === 46) {
                var index = this.handler.line.geometry.components.length - 3;        
                this.handler.line.geometry.removeComponent(this.handler.line.geometry.components[index]);
                this.handler.drawFeature();
            }
        }
        return true;
    },
    activate: function() {
        return this.handlers.keyboard.activate() &&
            OpenLayers.Control.DrawFeature.prototype.activate.apply(this, arguments);
    },
    deactivate: function() {
        var deactivated = false;
        // the return from the controls is unimportant in this case
        if(OpenLayers.Control.DrawFeature.prototype.deactivate.apply(this, arguments)) {
            this.handlers.keyboard.deactivate();
            deactivated = true;
        }
        return deactivated;
    },
    
    CLASS_NAME: "OpenLayers.Control.DrawFeatureOpt"
});