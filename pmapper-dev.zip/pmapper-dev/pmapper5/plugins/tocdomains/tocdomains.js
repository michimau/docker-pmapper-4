/******************************************************************************
 *
 * Purpose: add domains in TOC as additional level above categories
 * Author:  Armin Burger
 *
 ******************************************************************************
 *
 * Copyright (c) 2003-2012 Armin Burger
 *
 * This file is part of p.mapper.
 *
 * p.mapper is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version. See the COPYING file.
 *
 * p.mapper is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with p.mapper; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 ******************************************************************************/


/**
 * Overwrite PMToc function for adding domains
 * @param catObjList
 */
OpenLayers.Control.PMToc.prototype.addToDiv = function(catObjList) {
	var tocDiv = $("<div>").attr('id', "pmToc");
	var domUl = $("<ul>");
	try {
		var domains = PM.ini.pluginsConfig.tocdomains.domain;
	} catch(e) {
		var domains = PM.Plugin.TocDomains.domains;
	}
	
	if (typeof(domains) == 'undefined') {
		alert("PMAPPER-ERROR: undefined config variable 'PM.Plugin.TocDomains.domains' in js_config.php");
		$.each(catObjList, function(catname, catObj){
    		domUl.append(catObj);
    	});
		tocDiv.append(domUl)
              .appendTo($('#' + this.div.id));
		return false;
	}
	
    for (var i=0; i<domains.length; i++) {
		var domEl = domains[i];
		var domLi = $("<li>").addClass(domEl.state ? domEl.state : "open")
		                     .attr('id', "pmdomtoc_" + domEl.id);
		$("<span>").addClass("pm-toc-domain-label")
		           .html(PM._p(domEl.description))
		           .appendTo(domLi);
		var catUl = $("<ul>");
		var domCategories = domEl.category;
        
        if (typeof domCategories === 'string') {
            domCategories = [ domCategories ];
        }
        
		for (var ci=0; ci<domCategories.length; ci++) {
			var catName = domCategories[ci];
			catUl.append(catObjList[catName]);
		}
		domLi.append(catUl)
		     .appendTo(domUl);
	}
	
    tocDiv.append(domUl)
          .appendTo($('#' + this.div.id));
};



$.extend(PM.Plugin,
{
    TocDomains: {
    	
    }
});